using System;
using System.Collections.Generic;

namespace HotelEase.Helpers
{
    public static class NationalityHelper
    {
        private static readonly Dictionary<string, string> Flags = new(StringComparer.OrdinalIgnoreCase)
        {
            ["Filipino"] = "🇵🇭",
            ["American"] = "🇺🇸",
            ["Chinese"] = "🇨🇳",
            ["Japanese"] = "🇯🇵",
            ["Korean"] = "🇰🇷",
            ["Australian"] = "🇦🇺",
            ["British"] = "🇬🇧",
            ["Canadian"] = "🇨🇦",
            ["German"] = "🇩🇪",
            ["Indian"] = "🇮🇳",
            ["Indonesian"] = "🇮🇩",
            ["Malaysian"] = "🇲🇾",
            ["Singaporean"] = "🇸🇬",
            ["Thai"] = "🇹🇭",
            ["Vietnamese"] = "🇻🇳",
            ["French"] = "🇫🇷",
            ["Italian"] = "🇮🇹",
            ["Spanish"] = "🇪🇸",
            ["Saudi"] = "🇸🇦",
            ["Emirati"] = "🇦🇪",
            ["Other"] = "🌐",
        };

        public static string GetFlag(string? nationality)
        {
            if (string.IsNullOrWhiteSpace(nationality)) return "🌐";
            return Flags.TryGetValue(nationality.Trim(), out var f) ? f : "🌐";
        }

        public static string WithFlag(string? nationality)
        {
            if (string.IsNullOrWhiteSpace(nationality)) return "🌐 —";
            var n = nationality.Trim();
            return $"{GetFlag(n)} {n}";
        }
    }
}
