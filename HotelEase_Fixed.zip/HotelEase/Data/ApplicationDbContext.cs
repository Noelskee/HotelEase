using HotelEase.Models;
using Microsoft.EntityFrameworkCore;

namespace HotelEase.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) { }

        // ---- Original Room / RoomType / Guest management ----
        public DbSet<RoomType> RoomTypes { get; set; }
        public DbSet<Room> Rooms { get; set; }
        public DbSet<Amenity> Amenities { get; set; }
        public DbSet<Notification> Notifications { get; set; }
        public DbSet<RoomTypeAmenity> RoomTypeAmenities { get; set; }
        public DbSet<RoomNoEntry> RoomNos { get; set; }
        public DbSet<RoomTypeImage> RoomTypeImages { get; set; }
        public DbSet<Guest> Guests { get; set; }

        // ---- Added: Users / Reservations / Audit ----
        public DbSet<User> Users { get; set; }
        public DbSet<Reservation> Reservations { get; set; }
        public DbSet<Transaction> Transactions { get; set; }
        public DbSet<AuditLog> AuditLogs { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // ============ Original Room / RoomType / Guest configuration ============

            builder.Entity<RoomType>(e =>
            {
                e.HasIndex(rt => rt.Name).IsUnique();
            });

            builder.Entity<Room>(e =>
            {
                e.HasIndex(r => r.RoomNumber).IsUnique();
                // Walk-in / board filters: Status, and Status+RoomTypeId.
                e.HasIndex(r => r.Status);
                e.HasIndex(r => new { r.Status, r.RoomTypeId });
                e.HasOne(r => r.RoomType)
                    .WithMany(rt => rt.Rooms)
                    .HasForeignKey(r => r.RoomTypeId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            builder.Entity<Amenity>(e =>
            {
                e.HasIndex(a => a.Name).IsUnique();
            });

            // Hol_RoomAmenities: composite key (RoomTypeId, AmenityId).
            builder.Entity<RoomTypeAmenity>(e =>
            {
                e.HasKey(rta => new { rta.RoomTypeId, rta.AmenityId });
                e.HasOne(rta => rta.RoomType)
                    .WithMany(rt => rt.RoomTypeAmenities)
                    .HasForeignKey(rta => rta.RoomTypeId)
                    .OnDelete(DeleteBehavior.Cascade);
                e.HasOne(rta => rta.Amenity)
                    .WithMany(a => a.RoomTypeAmenities)
                    .HasForeignKey(rta => rta.AmenityId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            // tbl_RoomNo: composite PK (RoomTypeId, RoomNo).
            builder.Entity<RoomNoEntry>(e =>
            {
                e.HasKey(rn => new { rn.RoomTypeId, rn.RoomNo });
                e.HasIndex(rn => rn.RoomNo).IsUnique();
                e.HasOne(rn => rn.RoomType)
                    .WithMany(rt => rt.RoomNos)
                    .HasForeignKey(rn => rn.RoomTypeId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            // RoomTypeImage: each room type can have many images; cascade delete
            // when the room type is removed.
            builder.Entity<RoomTypeImage>(e =>
            {
                e.HasIndex(i => i.RoomTypeId);
                e.HasOne(i => i.RoomType)
                    .WithMany(rt => rt.Images)
                    .HasForeignKey(i => i.RoomTypeId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            // Guest: reservations are the authoritative stay-history source.
            builder.Entity<Guest>(e =>
            {
                e.HasIndex(g => g.IsArchived);
            });

            // ============ Added: Users / Reservations / Audit ============

            builder.Entity<User>(e =>
            {
                e.HasIndex(u => u.Username).IsUnique();
            });

            builder.Entity<Reservation>(e =>
            {
                e.HasOne(r => r.Guest)
                    .WithMany(g => g.Reservations)
                    .HasForeignKey(r => r.GuestId)
                    // Cascade: a guest's own reservations are part of their
                    // record. Normal flows never hard-delete a Guest (Archive
                    // is the soft-delete), but GuestController.DeletePermanently
                    // — reachable only from the Archived list, behind a
                    // confirmation dialog — is an explicit "erase everything"
                    // action, so it should be able to take the guest's
                    // Reservations/Transactions with it instead of failing
                    // with a FK violation.
                    .OnDelete(DeleteBehavior.Cascade);

                e.HasOne(r => r.Room)
                    .WithMany(rm => rm.Reservations)
                    .HasForeignKey(r => r.RoomId)
                    .IsRequired(false)
                    .OnDelete(DeleteBehavior.Restrict);

                e.HasOne(r => r.PreferredRoomType)
                    .WithMany()
                    .HasForeignKey(r => r.PreferredRoomTypeId)
                    .IsRequired(false)
                    .OnDelete(DeleteBehavior.Restrict);

                e.HasOne(r => r.CreatedByUser)
                    .WithMany()
                    .HasForeignKey(r => r.CreatedByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull);

                // ── Date / availability query indexes ─────────────────────
                // IsRoomAvailable + GetAvailableRoomsAsync:
                //   WHERE RoomId = ? AND Status NOT IN (...) AND date-overlap
                e.HasIndex(r => new { r.RoomId, r.Status, r.CheckInDate, r.CheckOutDate })
                    .HasDatabaseName("IX_Reservations_Room_Status_Dates");

                // TBA type holds (RoomId null) + capacity by PreferredRoomType:
                e.HasIndex(r => new { r.PreferredRoomTypeId, r.Status, r.CheckInDate, r.CheckOutDate })
                    .HasDatabaseName("IX_Reservations_PrefType_Status_Dates");

                // Front Desk arrivals / departures / in-house:
                e.HasIndex(r => new { r.Status, r.ExpectedCheckIn })
                    .HasDatabaseName("IX_Reservations_Status_ExpectedCheckIn");
                e.HasIndex(r => new { r.Status, r.ExpectedCheckOut })
                    .HasDatabaseName("IX_Reservations_Status_ExpectedCheckOut");
                e.HasIndex(r => new { r.Status, r.ActualCheckIn })
                    .HasDatabaseName("IX_Reservations_Status_ActualCheckIn");

                // Manage list filter by status + CreatedAt sort:
                e.HasIndex(r => new { r.Status, r.CreatedAt })
                    .HasDatabaseName("IX_Reservations_Status_CreatedAt");

                // Guest status lookup by reference number:
                e.HasIndex(r => r.ReferenceNumber)
                    .IsUnique()
                    .HasDatabaseName("IX_Reservations_ReferenceNumber");
            });

            builder.Entity<Transaction>(e =>
            {
                e.HasOne(t => t.Reservation)
                    .WithOne(r => r.Transaction)
                    .HasForeignKey<Transaction>(t => t.ReservationId)
                    .OnDelete(DeleteBehavior.Cascade);

                e.HasOne(t => t.CheckedInByUser)
                    .WithMany()
                    .HasForeignKey(t => t.CheckedInByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull);

                e.HasOne(t => t.CheckedOutByUser)
                    .WithMany()
                    .HasForeignKey(t => t.CheckedOutByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            // Notification → optional Reservation (staff feed)
            builder.Entity<Notification>(e =>
            {
                e.HasOne(n => n.Reservation)
                    .WithMany()
                    .HasForeignKey(n => n.ReservationId)
                    .OnDelete(DeleteBehavior.SetNull)
                    .IsRequired(false);
                e.HasIndex(n => n.ReservationId);
                e.HasIndex(n => new { n.IsRead, n.CreatedAt });
            });


            // AuditLog → User (optional FK; UserName is an intentional historical snapshot
            // kept for immutable audit trail readability even when a User is removed).
            builder.Entity<AuditLog>(e =>
            {
                e.HasOne(a => a.User)
                    .WithMany()
                    .HasForeignKey(a => a.UserId)
                    .OnDelete(DeleteBehavior.SetNull)
                    .IsRequired(false);

                e.HasIndex(a => a.UserId)
                    .HasDatabaseName("IX_AuditLogs_UserId");
            });

        }
    }
}
