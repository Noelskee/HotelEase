using HotelEase.Models;

namespace HotelEase.Data;

// Seeds staff accounts, Alemar Budgetel room types, and a default set of
// physical room numbers. Room numbers can still be edited in Room Management.
public static class DbSeeder
{
    public static void Seed(ApplicationDbContext db)
    {
        SeedUsers(db);
        SeedRoomTypes(db);
        SeedRoomTypeImages(db);
        SeedAmenities(db);
        SeedRoomTypeAmenities(db);
        SeedRooms(db);
    }

    /// <summary>
    /// Seeds staff accounts only when the Users table is empty.
    /// Priority:
    ///   1. Environment variables HOTELEASE_ADMIN_PASSWORD, HOTELEASE_FRONTDESK_PASSWORD, HOTELEASE_HOUSEKEEPING_PASSWORD
    ///   2. Demo fallbacks (Admin@123, Front@123, House@123) — used in both Development and Production
    ///      so login works after publish without extra setup (suitable for thesis/demo deployments).
    /// </summary>
    private static void SeedUsers(ApplicationDbContext db)
    {
        if (db.Users.Any()) return;

        static string ResolvePassword(string envKey, string fallback)
        {
            var fromEnv = Environment.GetEnvironmentVariable(envKey);
            if (!string.IsNullOrWhiteSpace(fromEnv) && fromEnv.Length >= 8)
                return fromEnv;
            return fallback;
        }

        var adminPw = ResolvePassword("HOTELEASE_ADMIN_PASSWORD", "Admin@123");
        var frontPw = ResolvePassword("HOTELEASE_FRONTDESK_PASSWORD", "Front@123");
        var housePw = ResolvePassword("HOTELEASE_HOUSEKEEPING_PASSWORD", "House@123");

        // Username mirrors email — staff sign in with email only.
        db.Users.AddRange(
            new User
            {
                Username = "admin@alemarbud.com",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(adminPw),
                FullName = "System Administrator",
                Email = "admin@alemarbud.com",
                Role = UserRole.Admin,
                IsActive = true
            },
            new User
            {
                Username = "frontdesk@alemarbud.com",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(frontPw),
                FullName = "Front Desk Staff",
                Email = "frontdesk@alemarbud.com",
                Role = UserRole.FrontDesk,
                IsActive = true
            },
            new User
            {
                Username = "housekeeping@alemarbud.com",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(housePw),
                FullName = "Housekeeping Staff",
                Email = "housekeeping@alemarbud.com",
                Role = UserRole.Housekeeping,
                IsActive = true
            }
        );
        db.SaveChanges();

        Console.WriteLine("============================================================");
        Console.WriteLine("HotelEase first-run user seed completed (login with EMAIL):");
        Console.WriteLine("  admin@alemarbud.com        / Admin@123");
        Console.WriteLine("  frontdesk@alemarbud.com    / Front@123");
        Console.WriteLine("  housekeeping@alemarbud.com / House@123");
        Console.WriteLine("  Override passwords via HOTELEASE_*_PASSWORD env vars if needed.");
        Console.WriteLine("============================================================");
    }

    private static void SeedRoomTypes(ApplicationDbContext db)
    {
        // Canonical Alemar Budgetel rate card (from front-desk interview).
        // 3-hour:  Single 250 | Standard/Double 300 | Deluxe 350 | Super Deluxe 380 | Super Duper 400
        // 24-hour: Single 800 | Standard/Double 1,200 | Deluxe 1,300 | Super Deluxe 1,400 | Super Duper 1,900
        // 12-hour: midpoint between 3h and 24h when not given on the recording.
        var defaults = new Dictionary<string, (decimal Base, decimal R3, decimal R12, decimal Extra, decimal Extra3, int MaxOcc, string Desc, string Img)>(StringComparer.OrdinalIgnoreCase)
        {
            ["SINGLE"]       = (800,  250, 525,  50, 50, 1, "Cozy single room ideal for solo travelers.", "/images/rooms/single.jpg"),
            ["STANDARD"]     = (1200, 300, 750,  50, 50, 2, "Comfortable standard room, one matrimonial bed, good for two guests.", "/images/rooms/standard.jpg"),
            ["DOUBLE"]       = (1200, 300, 750,  50, 50, 2, "Same rate as Standard, but with separate twin beds instead of one matrimonial bed.", "/images/rooms/double.jpg"),
            ["DELUXE"]       = (1300, 350, 825,  60, 60, 2, "Deluxe room with a queen-size bed and premium amenities.", "/images/rooms/deluxe.jpg"),
            ["SUPER DELUXE"] = (1400, 380, 890,  70, 70, 2, "Upscale super deluxe room, bigger floor area than Deluxe.", "/images/rooms/super-deluxe.jpg"),
            ["SUPER DUPER"]  = (1900, 400, 1150, 90, 90, 3, "Top-tier room, includes its own refrigerator.", "/images/rooms/super-duper.jpg")
        };

        // Existing DB: backfill missing image URLs AND zero hourly rates so
        // Walk-In / online booking no longer show ₱0.00 for 3h / 12h packages.
        if (db.RoomTypes.Any())
        {
            var updated = false;
            foreach (var rt in db.RoomTypes)
            {
                if (!defaults.TryGetValue(rt.Name, out var d)) continue;

                if (string.IsNullOrWhiteSpace(rt.ImageUrl))
                {
                    rt.ImageUrl = d.Img;
                    updated = true;
                }
                // Only fill rates that are still 0 — never overwrite staff edits.
                if (rt.BaseRate <= 0) { rt.BaseRate = d.Base; updated = true; }
                if (rt.Rate3Hours <= 0) { rt.Rate3Hours = d.R3; updated = true; }
                if (rt.Rate12Hours <= 0) { rt.Rate12Hours = d.R12; updated = true; }
                if (rt.ExtraHourRate <= 0) { rt.ExtraHourRate = d.Extra; updated = true; }
                if (rt.ExtraHourRate3Hours <= 0) { rt.ExtraHourRate3Hours = d.Extra3; updated = true; }
            }
            if (updated) db.SaveChanges();
            return;
        }

        var roomTypes = defaults.Select(kv => new RoomType
        {
            Name = kv.Key,
            MaxOccupancy = kv.Value.MaxOcc,
            BaseRate = kv.Value.Base,
            Rate3Hours = kv.Value.R3,
            Rate12Hours = kv.Value.R12,
            ExtraHourRate = kv.Value.Extra,
            ExtraHourRate3Hours = kv.Value.Extra3,
            Description = kv.Value.Desc,
            ImageUrl = kv.Value.Img
        }).ToArray();

        db.RoomTypes.AddRange(roomTypes);
        db.SaveChanges();
    }

    private static void SeedAmenities(ApplicationDbContext db)
    {
        if (db.Amenities.Any()) return;

        var amenityNames = new[]
        {
            "WiFi",
            "TV",
            "Air Conditioning",
            "Hot Shower",
            "Mini Fridge",
            "Towels",
            "Safety Box"
        };

        db.Amenities.AddRange(amenityNames.Select(name => new Amenity { Name = name }));
        db.SaveChanges();
    }

    private static void SeedRoomTypeAmenities(ApplicationDbContext db)
    {
        if (db.RoomTypeAmenities.Any()) return;

        var amenities = db.Amenities.ToList();
        var roomTypes = db.RoomTypes.ToList();

        var typeAmenityMap = new Dictionary<string, string[]>
        {
            ["SINGLE"] = new[] { "WiFi", "TV", "Air Conditioning", "Hot Shower", "Towels" },
            ["STANDARD"] = new[] { "WiFi", "TV", "Air Conditioning", "Hot Shower", "Towels" },
            ["DOUBLE"] = new[] { "WiFi", "TV", "Air Conditioning", "Hot Shower", "Towels", "Mini Fridge" },
            ["DELUXE"] = new[] { "WiFi", "TV", "Air Conditioning", "Hot Shower", "Towels", "Mini Fridge", "Safety Box" },
            ["SUPER DELUXE"] = new[] { "WiFi", "TV", "Air Conditioning", "Hot Shower", "Towels", "Mini Fridge", "Safety Box" },
            ["SUPER DUPER"] = new[] { "WiFi", "TV", "Air Conditioning", "Hot Shower", "Towels", "Mini Fridge", "Safety Box" }
        };

        var links = new List<RoomTypeAmenity>();
        foreach (var (typeName, names) in typeAmenityMap)
        {
            var roomType = roomTypes.FirstOrDefault(rt => rt.Name == typeName);
            if (roomType == null) continue;

            foreach (var name in names)
            {
                var amenity = amenities.FirstOrDefault(a => a.Name == name);
                if (amenity == null) continue;

                links.Add(new RoomTypeAmenity
                {
                    RoomTypeId = roomType.Id,
                    AmenityId = amenity.Id,
                    Name = amenity.Name
                });
            }
        }

        if (links.Count > 0)
        {
            db.RoomTypeAmenities.AddRange(links);
            db.SaveChanges();
        }
    }

    private static void SeedRooms(ApplicationDbContext db)
    {
        if (db.Rooms.Any()) return;

        // 69 rooms across three floors, numbered 101–123 (Floor 1),
        // 201–223 (Floor 2), 301–323 (Floor 3) — 23 rooms per floor.
        // Room type blocks are grouped by consecutive number ranges so a
        // whole floor is easy to scan in Room Management.
        var roomTypeRanges = new (string TypeName, int Start, int End)[]
        {
            ("SINGLE",       101, 112), // Floor 1: 12 rooms
            ("STANDARD",     113, 123), // Floor 1: 11 rooms
            ("DOUBLE",       201, 212), // Floor 2: 12 rooms
            ("DELUXE",       213, 223), // Floor 2: 11 rooms
            ("SUPER DELUXE", 301, 311), // Floor 3: 11 rooms
            ("SUPER DUPER",  312, 323)  // Floor 3: 12 rooms
        };

        var seededTypes = db.RoomTypes.ToList();
        var rooms = new List<Room>();

        foreach (var (typeName, start, end) in roomTypeRanges)
        {
            var roomType = seededTypes.FirstOrDefault(rt => rt.Name == typeName);
            if (roomType == null) continue;

            for (var number = start; number <= end; number++)
            {
                var roomNumber = number.ToString();
                rooms.Add(new Room
                {
                    RoomTypeId = roomType.Id,
                    RoomNumber = roomNumber,
                    Floor = roomNumber[0] + "F",
                    Status = RoomStatus.Available,
                    Description = $"{roomType.Name} room {roomNumber}."
                });
            }
        }

        if (rooms.Count > 0)
        {
            db.Rooms.AddRange(rooms);
            db.SaveChanges();
        }
    }

    private static void SeedRoomTypeImages(ApplicationDbContext db)
    {
        if (db.RoomTypeImages.Any()) return;

        var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            ["SINGLE"] = "/images/rooms/single.jpg",
            ["STANDARD"] = "/images/rooms/standard.jpg",
            ["DOUBLE"] = "/images/rooms/double.jpg",
            ["DELUXE"] = "/images/rooms/deluxe.jpg",
            ["SUPER DELUXE"] = "/images/rooms/super-deluxe.jpg",
            ["SUPER DUPER"] = "/images/rooms/super-duper.jpg"
        };

        var roomTypes = db.RoomTypes.ToList();
        var images = new List<RoomTypeImage>();

        // Extra gallery shots (shared) so Room Details can show more than one photo
        var galleryExtras = new[]
        {
            "/images/rooms/gallery_1.jpg",
            "/images/rooms/gallery_2.jpg",
            "/images/rooms/gallery_3.jpg"
        };

        foreach (var rt in roomTypes)
        {
            if (!map.TryGetValue(rt.Name, out var url)) continue;

            // Keep RoomType.ImageUrl in sync for legacy reads
            if (string.IsNullOrWhiteSpace(rt.ImageUrl))
                rt.ImageUrl = url;

            images.Add(new RoomTypeImage
            {
                RoomTypeId = rt.Id,
                ImageUrl = url,
                FileName = Path.GetFileName(url),
                Caption = rt.Name + " room",
                IsPrimary = true,
                DisplayOrder = 0,
                UploadedAt = DateTime.UtcNow
            });

            // Attach 1–2 extra gallery images so online Room Details shows a small gallery
            for (var g = 0; g < galleryExtras.Length && g < 2; g++)
            {
                images.Add(new RoomTypeImage
                {
                    RoomTypeId = rt.Id,
                    ImageUrl = galleryExtras[g],
                    FileName = Path.GetFileName(galleryExtras[g]),
                    Caption = rt.Name + " view",
                    IsPrimary = false,
                    DisplayOrder = g + 1,
                    UploadedAt = DateTime.UtcNow
                });
            }
        }

        if (images.Count > 0)
        {
            db.RoomTypeImages.AddRange(images);
            db.SaveChanges();
        }
    }
}
