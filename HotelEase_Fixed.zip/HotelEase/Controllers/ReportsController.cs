using HotelEase.Data;
using HotelEase.Filters;
using HotelEase.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HotelEase.Controllers;

/// <summary>
/// Read-only operational reports. Data is pulled from existing Reservation,
/// Room, Transaction, and Payment records — no separate report tables.
/// </summary>
[RequireRole(UserRole.Admin, UserRole.FrontDesk)]
public class ReportsController : Controller
{
    private readonly ApplicationDbContext _db;
    public ReportsController(ApplicationDbContext db) => _db = db;

    /// <summary>
    /// Single Reports page. Report types:
    ///   arrivals | departures | roomstatus | transactions
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Index(
        string? reportType = null,
        DateTime? date = null,
        DateTime? start = null,
        DateTime? end = null,
        string? status = null,
        string? roomType = null,
        string? roomStatus = null,
        string? txType = null)
    {
        var type = (reportType ?? "arrivals").Trim().ToLowerInvariant();
        if (type is not ("arrivals" or "departures" or "roomstatus" or "transactions"))
            type = "arrivals";

        ViewBag.ReportType = type;
        ViewBag.ReportDate = (date ?? DateTime.Today).Date;
        ViewBag.StartDate = (start ?? DateTime.Today.AddDays(-7)).Date;
        ViewBag.EndDate = (end ?? DateTime.Today).Date;
        ViewBag.StatusFilter = status;
        ViewBag.RoomTypeFilter = roomType;
        ViewBag.RoomStatusFilter = roomStatus;
        ViewBag.TxTypeFilter = txType;

        // Room types for filter dropdowns
        ViewBag.RoomTypes = await _db.RoomTypes
            .OrderBy(rt => rt.Name)
            .Select(rt => rt.Name)
            .ToListAsync();

        switch (type)
        {
            case "arrivals":
                await LoadArrivalsAsync(ViewBag.ReportDate, status);
                break;
            case "departures":
                await LoadDeparturesAsync(ViewBag.ReportDate, status);
                break;
            case "roomstatus":
                await LoadRoomStatusAsync(roomType, roomStatus);
                break;
            case "transactions":
                await LoadTransactionsAsync(ViewBag.StartDate, ViewBag.EndDate, txType);
                break;
        }

        return View();
    }

    private async Task LoadArrivalsAsync(DateTime d, string? statusFilter)
    {
        var q = _db.Reservations
            .Include(r => r.Guest)
            .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
            .Include(r => r.PreferredRoomType)
            .Where(r => r.Status != ReservationStatus.Cancelled
                     && r.Status != ReservationStatus.NoShow
                     && (
                         (r.ActualCheckIn.HasValue && r.ActualCheckIn.Value.Date == d)
                         || (!r.ActualCheckIn.HasValue
                             && ((r.ExpectedCheckIn.HasValue && r.ExpectedCheckIn.Value.Date == d)
                                 || (r.CheckInDate.HasValue && r.CheckInDate.Value.Date == d)))
                     ));

        if (!string.IsNullOrWhiteSpace(statusFilter)
            && Enum.TryParse<ReservationStatus>(statusFilter, true, out var st))
        {
            q = q.Where(r => r.Status == st);
        }

        var list = await q
            .OrderBy(r => r.ActualCheckIn ?? r.ExpectedCheckIn ?? r.CheckInDate)
            .ThenBy(r => r.ReferenceNumber)
            .ToListAsync();

        ViewBag.Arrivals = list;
        ViewBag.ReportTitle = "Daily Arrivals";
    }

    private async Task LoadDeparturesAsync(DateTime d, string? statusFilter)
    {
        var q = _db.Reservations
            .Include(r => r.Guest)
            .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
            .Include(r => r.PreferredRoomType)
            .Where(r => r.Status != ReservationStatus.Cancelled
                     && r.Status != ReservationStatus.NoShow
                     && (
                         (r.ActualCheckOut.HasValue && r.ActualCheckOut.Value.Date == d)
                         || (!r.ActualCheckOut.HasValue
                             && r.ExpectedCheckOut.HasValue
                             && r.ExpectedCheckOut.Value.Date == d)
                     ));

        if (!string.IsNullOrWhiteSpace(statusFilter)
            && Enum.TryParse<ReservationStatus>(statusFilter, true, out var st))
        {
            q = q.Where(r => r.Status == st);
        }

        var list = await q
            .OrderBy(r => r.ActualCheckOut ?? r.ExpectedCheckOut)
            .ThenBy(r => r.ReferenceNumber)
            .ToListAsync();

        ViewBag.Departures = list;
        ViewBag.ReportTitle = "Daily Departures";
    }

    private async Task LoadRoomStatusAsync(string? roomTypeFilter, string? roomStatusFilter)
    {
        var rooms = await _db.Rooms
            .Include(r => r.RoomType)
            .Include(r => r.Reservations.Where(res => res.Status == ReservationStatus.CheckedIn
                                                   || res.Status == ReservationStatus.Reserved
                                                   || res.Status == ReservationStatus.Confirmed))
                .ThenInclude(res => res.Guest)
            .OrderBy(r => r.RoomNumber)
            .ToListAsync();

        if (!string.IsNullOrWhiteSpace(roomTypeFilter))
            rooms = rooms.Where(r => string.Equals(r.RoomType?.Name, roomTypeFilter, StringComparison.OrdinalIgnoreCase)).ToList();

        if (!string.IsNullOrWhiteSpace(roomStatusFilter)
            && Enum.TryParse<RoomStatus>(roomStatusFilter, true, out var rs))
            rooms = rooms.Where(r => r.Status == rs).ToList();

        // Summary cards from full inventory (unfiltered counts for KPIs use all rooms)
        var allRooms = await _db.Rooms.ToListAsync();
        ViewBag.TotalRooms = allRooms.Count;
        ViewBag.OccupiedCount = allRooms.Count(r => r.Status == RoomStatus.Occupied);
        ViewBag.AvailableCount = allRooms.Count(r => r.Status == RoomStatus.Available);
        ViewBag.ReservedCount = allRooms.Count(r => r.Status == RoomStatus.Reserved);
        ViewBag.ForCleaningCount = allRooms.Count(r => r.Status == RoomStatus.ForCleaning);
        ViewBag.MaintenanceCount = allRooms.Count(r => r.Status == RoomStatus.Maintenance);

        // Guest name for occupied/reserved rooms
        var rows = rooms.Select(r =>
        {
            var active = r.Reservations
                .OrderByDescending(res => res.ActualCheckIn ?? res.ExpectedCheckIn ?? res.CreatedAt)
                .FirstOrDefault();
            return new RoomStatusRow
            {
                RoomNumber = r.RoomNumber,
                RoomType = r.RoomType?.Name ?? "—",
                Status = r.Status.ToString(),
                GuestName = (r.Status is RoomStatus.Occupied or RoomStatus.Reserved)
                    ? (active?.Guest?.FullName ?? "—")
                    : "—"
            };
        }).ToList();

        ViewBag.RoomStatusRows = rows;
        ViewBag.ReportTitle = "Room Status Summary";
    }

    private async Task LoadTransactionsAsync(DateTime start, DateTime end, string? txTypeFilter)
    {
        if (end < start) end = start;

        var rows = new List<TransactionRecordRow>();

        // Check-in / Check-out / Payment from Transaction table
        var txs = await _db.Transactions
            .Include(t => t.Reservation).ThenInclude(r => r!.Guest)
            .Include(t => t.Reservation).ThenInclude(r => r!.Room)
            .Where(t => t.CreatedAt.Date >= start && t.CreatedAt.Date <= end
                     || (t.ActualCheckIn.Date >= start && t.ActualCheckIn.Date <= end)
                     || (t.ActualCheckOut.HasValue && t.ActualCheckOut.Value.Date >= start && t.ActualCheckOut.Value.Date <= end))
            .ToListAsync();

        foreach (var t in txs)
        {
            var guest = t.Reservation?.Guest?.FullName ?? "—";
            var room = t.Reservation?.Room?.RoomNumber ?? "—";
            var payStatus = t.IsPaid ? "Paid" : (t.InvoiceStatus == InvoiceStatus.Paid ? "Paid" : t.InvoiceStatus.ToString());

            // Check-in event
            if (t.ActualCheckIn.Date >= start && t.ActualCheckIn.Date <= end)
            {
                var bill = t.TotalAmount > 0 ? t.TotalAmount : t.FinalAmount;
                var paid = Math.Max(0m, t.AmountPaidAtCheckIn);
                var bal = Math.Max(0m, bill - paid);
                rows.Add(new TransactionRecordRow
                {
                    TransactionId = $"TX-{t.Id}-IN",
                    DateTime = t.ActualCheckIn,
                    GuestName = guest,
                    RoomNumber = room,
                    TransactionType = "Check-in",
                    TotalBill = bill,
                    AmountPaid = paid,
                    Balance = bal,
                    Amount = paid,
                    PaymentMethod = t.PaymentMethod ?? "—",
                    PaymentStatus = payStatus
                });
            }

            // Check-out event
            if (t.ActualCheckOut.HasValue
                && t.ActualCheckOut.Value.Date >= start
                && t.ActualCheckOut.Value.Date <= end)
            {
                var bill = t.FinalAmount > 0 ? t.FinalAmount : t.TotalAmount;
                var isFullyPaid = t.IsPaid || t.InvoiceStatus == InvoiceStatus.Paid;
                var paid = isFullyPaid ? bill : Math.Max(0m, t.AmountPaidAtCheckIn);
                var bal = Math.Max(0m, bill - paid);
                rows.Add(new TransactionRecordRow
                {
                    TransactionId = $"TX-{t.Id}-OUT",
                    DateTime = t.ActualCheckOut.Value,
                    GuestName = guest,
                    RoomNumber = room,
                    TransactionType = "Check-out",
                    TotalBill = bill,
                    AmountPaid = paid,
                    Balance = bal,
                    Amount = paid,
                    PaymentMethod = t.CheckOutPaymentMethod ?? t.PaymentMethod ?? "—",
                    PaymentStatus = payStatus
                });
            }

            // Standalone payment row when paid at check-in with amount
            if (t.AmountPaidAtCheckIn > 0
                && t.ActualCheckIn.Date >= start
                && t.ActualCheckIn.Date <= end)
            {
                // Already covered under Check-in amount; optional extra Payment row skipped
                // to avoid double-counting. Use explicit Payment only if no check-in overlap
                // is desired — keep single rows per event type.
            }
        }

        // Reservations created in range (new bookings)
        var newRes = await _db.Reservations
            .Include(r => r.Guest)
            .Include(r => r.Room)
            .Where(r => r.CreatedAt.Date >= start && r.CreatedAt.Date <= end
                     && r.Status != ReservationStatus.Cancelled)
            .ToListAsync();

        foreach (var r in newRes)
        {
            var bill = r.Transaction?.TotalAmount ?? 0;
            var paid = r.Transaction?.AmountPaidAtCheckIn ?? 0;
            var bal = Math.Max(0m, bill - paid);
            rows.Add(new TransactionRecordRow
            {
                TransactionId = r.ReferenceNumber,
                DateTime = r.CreatedAt,
                GuestName = r.Guest?.FullName ?? "—",
                RoomNumber = r.Room?.RoomNumber ?? "—",
                TransactionType = "Reservation",
                TotalBill = bill,
                AmountPaid = paid,
                Balance = bal,
                Amount = paid,
                PaymentMethod = r.Transaction?.PaymentMethod ?? "—",
                PaymentStatus = r.PaymentStatus.ToString()
            });
        }

        // Cancellations: prefer audit log date; fall back to reservations marked Cancelled
        var cancelAudits = await _db.AuditLogs
            .Where(a => a.Action.ToLower().Contains("cancel")
                     && a.CreatedAt.Date >= start && a.CreatedAt.Date <= end)
            .ToListAsync();

        var cancelResIds = cancelAudits.Where(a => a.EntityId.HasValue).Select(a => a.EntityId!.Value).Distinct().ToList();
        var cancelledRes = cancelResIds.Count > 0
            ? await _db.Reservations.Include(r => r.Guest).Include(r => r.Room)
                .Where(r => cancelResIds.Contains(r.Id)).ToListAsync()
            : new List<Reservation>();

        foreach (var audit in cancelAudits)
        {
            var r = cancelledRes.FirstOrDefault(x => x.Id == audit.EntityId);
            rows.Add(new TransactionRecordRow
            {
                TransactionId = r?.ReferenceNumber ?? $"CXL-{audit.EntityId}",
                DateTime = audit.CreatedAt.ToLocalTime(),
                GuestName = r?.Guest?.FullName ?? "—",
                RoomNumber = r?.Room?.RoomNumber ?? "—",
                TransactionType = "Cancellation",
                TotalBill = 0,
                AmountPaid = 0,
                Balance = 0,
                Amount = 0,
                PaymentMethod = "—",
                PaymentStatus = r?.PaymentStatus.ToString() ?? "—"
            });
        }

        // Also include cancelled reservations whose CreatedAt falls in range but have no audit entry
        var already = new HashSet<int>(cancelResIds);
        var cancelledExtra = await _db.Reservations
            .Include(r => r.Guest)
            .Include(r => r.Room)
            .Where(r => r.Status == ReservationStatus.Cancelled
                     && r.CreatedAt.Date >= start && r.CreatedAt.Date <= end
                     && !already.Contains(r.Id))
            .ToListAsync();

        foreach (var r in cancelledExtra)
        {
            rows.Add(new TransactionRecordRow
            {
                TransactionId = r.ReferenceNumber,
                DateTime = r.CreatedAt,
                GuestName = r.Guest?.FullName ?? "—",
                RoomNumber = r.Room?.RoomNumber ?? "—",
                TransactionType = "Cancellation",
                Amount = 0,
                PaymentMethod = "—",
                PaymentStatus = r.PaymentStatus.ToString()
            });
        }

        // Filter by transaction type if requested
        if (!string.IsNullOrWhiteSpace(txTypeFilter))
        {
            var filter = txTypeFilter.Trim();
            rows = rows
                .Where(x => string.Equals(x.TransactionType, filter, StringComparison.OrdinalIgnoreCase))
                .ToList();
        }

        ViewBag.TransactionRows = rows
            .OrderByDescending(x => x.DateTime)
            .ThenBy(x => x.TransactionId)
            .ToList();
        ViewBag.ReportTitle = "Transaction Records";
    }

    // Legacy URLs → unified page
    [HttpGet]
    public IActionResult Arrivals(DateTime? date)
        => RedirectToAction(nameof(Index), new { reportType = "arrivals", date = (date ?? DateTime.Today).ToString("yyyy-MM-dd") });

    [HttpGet]
    public IActionResult Departures(DateTime? date)
        => RedirectToAction(nameof(Index), new { reportType = "departures", date = (date ?? DateTime.Today).ToString("yyyy-MM-dd") });

    /// <summary>CSV export of the currently selected report.</summary>
    [HttpGet]
    public async Task<IActionResult> Export(
        string? reportType = null,
        DateTime? date = null,
        DateTime? start = null,
        DateTime? end = null,
        string? status = null,
        string? roomType = null,
        string? roomStatus = null,
        string? txType = null)
    {
        // Reuse Index data loading
        await Index(reportType, date, start, end, status, roomType, roomStatus, txType);
        var type = (string)(ViewBag.ReportType ?? "arrivals");
        var sb = new System.Text.StringBuilder();

        switch (type)
        {
            case "arrivals":
            {
                sb.AppendLine("Booking ID,Guest Name,Room Number,Room Type,Arrival/Check-in Time,Booking Source,Payment Status,Reservation/Check-in Status");
                var list = ViewBag.Arrivals as List<Reservation> ?? new();
                foreach (var r in list)
                {
                    var cin = r.ActualCheckIn ?? r.ExpectedCheckIn ?? r.CheckInDate;
                    var roomNo = r.Room?.RoomNumber ?? "";
                    var roomTypeName = r.Room?.RoomType?.Name ?? r.PreferredRoomType?.Name ?? "";
                    sb.AppendLine(string.Join(",",
                        Csv(r.ReferenceNumber),
                        Csv(r.Guest?.FullName),
                        Csv(roomNo),
                        Csv(roomTypeName),
                        Csv(cin?.ToString("yyyy-MM-dd h:mm tt")),
                        Csv(r.Type.BookingSourceLabel()),
                        Csv(r.PaymentStatus.ToString()),
                        Csv(r.Status.ToString())));
                }
                break;
            }
            case "departures":
            {
                sb.AppendLine("Booking ID,Guest Name,Room Number,Room Type,Check-in Time,Checkout Time,Payment Status,Check-out Status");
                var list = ViewBag.Departures as List<Reservation> ?? new();
                foreach (var r in list)
                {
                    var cin = r.ActualCheckIn ?? r.ExpectedCheckIn ?? r.CheckInDate;
                    var cout = r.ActualCheckOut ?? r.ExpectedCheckOut;
                    var roomNo = r.Room?.RoomNumber ?? "";
                    var roomTypeName = r.Room?.RoomType?.Name ?? r.PreferredRoomType?.Name ?? "";
                    sb.AppendLine(string.Join(",",
                        Csv(r.ReferenceNumber),
                        Csv(r.Guest?.FullName),
                        Csv(roomNo),
                        Csv(roomTypeName),
                        Csv(cin?.ToString("yyyy-MM-dd h:mm tt")),
                        Csv(cout?.ToString("yyyy-MM-dd h:mm tt")),
                        Csv(r.PaymentStatus.ToString()),
                        Csv(r.Status.ToString())));
                }
                break;
            }
            case "roomstatus":
            {
                sb.AppendLine("Room,Room Type,Status,Guest");
                var list = ViewBag.RoomStatusRows as List<RoomStatusRow> ?? new();
                foreach (var row in list)
                    sb.AppendLine($"{Csv(row.RoomNumber)},{Csv(row.RoomType)},{Csv(row.Status)},{Csv(row.GuestName)}");
                break;
            }
            case "transactions":
            {
                sb.AppendLine("Transaction ID,Date/Time,Guest Name,Room Number,Transaction Type,Total Bill,Amount Paid,Balance,Payment Method,Payment Status");
                var list = ViewBag.TransactionRows as List<TransactionRecordRow> ?? new();
                foreach (var row in list)
                    sb.AppendLine(string.Join(",",
                        Csv(row.TransactionId),
                        Csv(row.DateTime.ToString("yyyy-MM-dd h:mm tt")),
                        Csv(row.GuestName),
                        Csv(row.RoomNumber),
                        Csv(row.TransactionType),
                        row.TotalBill.ToString("F2", System.Globalization.CultureInfo.InvariantCulture),
                        row.AmountPaid.ToString("F2", System.Globalization.CultureInfo.InvariantCulture),
                        row.Balance.ToString("F2", System.Globalization.CultureInfo.InvariantCulture),
                        Csv(row.PaymentMethod),
                        Csv(row.PaymentStatus)));
                break;
            }
        }

        var bytes = System.Text.Encoding.UTF8.GetBytes(sb.ToString());
        var d = (date ?? DateTime.Today).ToString("yyyyMMdd");
        return File(bytes, "text/csv", $"HotelEase_{type}_{d}.csv");
    }

    private static string Csv(string? value)
    {
        var v = (value ?? "").Replace("\"", "\"\"");
        if (v.Contains(',') || v.Contains('"') || v.Contains('\n'))
            return $"\"{v}\"";
        return v;
    }
}

public class RoomStatusRow
{
    public string RoomNumber { get; set; } = "";
    public string RoomType { get; set; } = "";
    public string Status { get; set; } = "";
    public string GuestName { get; set; } = "";
}

public class TransactionRecordRow
{
    public string TransactionId { get; set; } = "";
    public DateTime DateTime { get; set; }
    public string GuestName { get; set; } = "";
    public string RoomNumber { get; set; } = "";
    public string TransactionType { get; set; } = "";
    public decimal TotalBill { get; set; }
    public decimal AmountPaid { get; set; }
    public decimal Balance { get; set; }
    public decimal Amount { get; set; }
    public string PaymentMethod { get; set; } = "";
    public string PaymentStatus { get; set; } = "";
}
