using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HotelEase.Controllers
{
    // Public — no login required, preserving this module's original (pre-auth) behavior.
    [AllowAnonymous]
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            // The room-grid dashboard that used to live here has been merged
            // into the single Dashboard (DashboardController) to avoid two
            // separate "Dashboard" nav items. This redirect keeps old links
            // and bookmarks to /Home/Index working.
            return RedirectToAction("Index", "Dashboard");
        }

        public IActionResult Error() => View();
    }
}
