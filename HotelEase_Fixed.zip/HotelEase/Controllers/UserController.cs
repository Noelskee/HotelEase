using HotelEase.Data;
using HotelEase.Filters;
using HotelEase.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HotelEase.Controllers;

[RequireRole(UserRole.Admin)]
public class UserController : Controller
{
    private readonly ApplicationDbContext _db;
    public UserController(ApplicationDbContext db) => _db = db;

    private bool IsAdmin() =>
        string.Equals(HttpContext.Session.GetString("UserRole"), "Admin", StringComparison.OrdinalIgnoreCase);

    public async Task<IActionResult> Index()
    {
        if (!IsAdmin()) return RedirectToAction("AccessDenied", "Account");
        var users = await _db.Users.OrderBy(u => u.FullName).ToListAsync();
        return View(users);
    }

    /// <summary>
    /// Admin creates staff account. Default password = username (email).
    /// Staff must change their own password after first login (Account → Change password).
    /// Admin never sets or edits another user's password.
    /// </summary>
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(string fullName, string email, string role)
    {
        if (!IsAdmin()) return RedirectToAction("AccessDenied", "Account");

        fullName = (fullName ?? "").Trim();
        email = (email ?? "").Trim();

        if (string.IsNullOrWhiteSpace(fullName) || string.IsNullOrWhiteSpace(email))
        {
            TempData["Error"] = "Full name and email are required.";
            return RedirectToAction(nameof(Index));
        }

        if (email.Length < 6)
        {
            TempData["Error"] = "Email must be at least 6 characters (used as default password).";
            return RedirectToAction(nameof(Index));
        }

        if (await _db.Users.AnyAsync(u => u.Email == email || u.Username == email))
        {
            TempData["Error"] = "A user with that email already exists.";
            return RedirectToAction(nameof(Index));
        }

        if (!Enum.TryParse<UserRole>(role, true, out var userRole))
            userRole = UserRole.FrontDesk;

        // Default password = username (email), same pattern as school portal accounts.
        var defaultPassword = email;

        var user = new User
        {
            FullName = fullName,
            Email = email,
            Username = email,
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(defaultPassword),
            Role = userRole,
            IsActive = true,
            MustChangePassword = true, // force change on first login
            CreatedAt = DateTime.Now
        };
        _db.Users.Add(user);
        await _db.SaveChangesAsync();

        _db.AuditLogs.Add(new AuditLog
        {
            Action = "create_user",
            EntityType = "User",
            EntityId = user.Id,
            Details = $"Created {user.FullName} ({user.Role}); default password = username",
            UserId = HttpContext.Session.GetInt32("UserId"),
            UserName = HttpContext.Session.GetString("UserFullName"),
            CreatedAt = DateTime.UtcNow
        });
        await _db.SaveChangesAsync();

        TempData["Success"] =
            $"Account for {fullName} created. Login: {email}. Temporary password is the same as the email — staff should change it after first login.";
        return RedirectToAction(nameof(Index));
    }

    /// <summary>
    /// Edit staff profile only: name, email, role, active.
    /// Password is never set or changed here — only the staff member may change their own password.
    /// </summary>
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, string fullName, string email, string role, bool isActive)
    {
        if (!IsAdmin()) return RedirectToAction("AccessDenied", "Account");

        fullName = (fullName ?? "").Trim();
        email = (email ?? "").Trim();

        if (string.IsNullOrWhiteSpace(fullName) || string.IsNullOrWhiteSpace(email))
        {
            TempData["Error"] = "Full name and email are required.";
            return RedirectToAction(nameof(Index));
        }

        var user = await _db.Users.FindAsync(id);
        if (user == null)
        {
            TempData["Error"] = "User not found.";
            return RedirectToAction(nameof(Index));
        }

        if (await _db.Users.AnyAsync(u => u.Id != id && (u.Email == email || u.Username == email)))
        {
            TempData["Error"] = "Another user already uses that email.";
            return RedirectToAction(nameof(Index));
        }

        if (!Enum.TryParse<UserRole>(role, true, out var userRole))
            userRole = user.Role;

        var currentId = HttpContext.Session.GetInt32("UserId");
        if (currentId == user.Id && !isActive)
        {
            TempData["Error"] = "You cannot deactivate your own account.";
            return RedirectToAction(nameof(Index));
        }

        user.FullName = fullName;
        user.Email = email;
        user.Username = email;
        user.Role = userRole;
        user.IsActive = isActive;
        // PasswordHash intentionally not touched.

        if (currentId == user.Id)
        {
            HttpContext.Session.SetString("UserFullName", user.FullName);
            HttpContext.Session.SetString("UserRole", user.Role.ToString());
            HttpContext.Session.SetString("Username", user.Username);
        }

        _db.AuditLogs.Add(new AuditLog
        {
            Action = "edit_user",
            EntityType = "User",
            EntityId = user.Id,
            Details = $"Updated {user.FullName} ({user.Role}, active={user.IsActive})",
            UserId = currentId,
            UserName = HttpContext.Session.GetString("UserFullName"),
            CreatedAt = DateTime.UtcNow
        });
        await _db.SaveChangesAsync();

        TempData["Success"] = $"Account for {fullName} updated.";
        return RedirectToAction(nameof(Index));
    }

    /// <summary>
    /// Admin may only reset a forgotten password back to the default (username/email).
    /// Admin does not choose or see a custom password — same idea as school portal reset.
    /// </summary>
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> ResetPassword(int id)
    {
        if (!IsAdmin()) return RedirectToAction("AccessDenied", "Account");

        var user = await _db.Users.FindAsync(id);
        if (user == null)
        {
            TempData["Error"] = "User not found.";
            return RedirectToAction(nameof(Index));
        }

        var defaultPassword = user.Username;
        if (string.IsNullOrWhiteSpace(defaultPassword) || defaultPassword.Length < 6)
            defaultPassword = user.Email ?? "changeme";

        user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(defaultPassword);
        _db.AuditLogs.Add(new AuditLog
        {
            Action = "reset_password_to_default",
            EntityType = "User",
            EntityId = user.Id,
            Details = $"Admin reset password for {user.FullName} to default (username)",
            UserId = HttpContext.Session.GetInt32("UserId"),
            UserName = HttpContext.Session.GetString("UserFullName"),
            CreatedAt = DateTime.UtcNow
        });
        await _db.SaveChangesAsync();

        TempData["Success"] =
            $"Password for {user.FullName} was reset to their username/email. They should change it after login.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id)
    {
        if (!IsAdmin()) return RedirectToAction("AccessDenied", "Account");
        var user = await _db.Users.FindAsync(id);
        if (user == null) return RedirectToAction(nameof(Index));

        var currentId = HttpContext.Session.GetInt32("UserId");
        if (currentId == user.Id)
        {
            TempData["Error"] = "You cannot delete your own account.";
            return RedirectToAction(nameof(Index));
        }

        _db.Users.Remove(user);
        _db.AuditLogs.Add(new AuditLog
        {
            Action = "delete_user",
            EntityType = "User",
            EntityId = id,
            Details = $"Deleted {user.FullName}",
            UserId = currentId,
            UserName = HttpContext.Session.GetString("UserFullName"),
            CreatedAt = DateTime.UtcNow
        });
        await _db.SaveChangesAsync();
        TempData["Success"] = "User deleted.";
        return RedirectToAction(nameof(Index));
    }
}
