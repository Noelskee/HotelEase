using HotelEase.Data;
using HotelEase.Filters;
using HotelEase.Models;
using HotelEase.Services;
using HotelEase.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HotelEase.Controllers;

public class AccountController : Controller
{
    private readonly ApplicationDbContext _db;
    private readonly IAuditService _audit;

    public AccountController(ApplicationDbContext db, IAuditService audit)
    {
        _db = db;
        _audit = audit;
    }

    [AllowAnonymous]
    [HttpGet]
    public IActionResult Login(string? returnUrl = null)
    {
        if (HttpContext.Session.GetInt32("UserId") != null)
        {
            var role = HttpContext.Session.GetString("UserRole") ?? "";
            if (string.Equals(role, "Housekeeping", StringComparison.OrdinalIgnoreCase))
                return RedirectToAction("Board", "Room");
            return RedirectToAction("Index", "Dashboard");
        }

        return View(new LoginViewModel { ReturnUrl = returnUrl });
    }

    [AllowAnonymous]
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        // Staff login is email-only (Admin / Front Desk / Housekeeping).
        var email = (model.Username ?? string.Empty).Trim();
        var user = await _db.Users
            .FirstOrDefaultAsync(u =>
                u.IsActive
                && u.Email != null
                && u.Email.ToLower() == email.ToLower());

        if (user == null || !BCrypt.Net.BCrypt.Verify(model.Password, user.PasswordHash))
        {
            model.ErrorMessage = "Invalid email or password.";
            return View(model);
        }

        user.LastLoginAt = DateTime.Now;
        await _db.SaveChangesAsync();

        HttpContext.Session.SetInt32("UserId", user.Id);
        HttpContext.Session.SetString("UserFullName", user.FullName);
        HttpContext.Session.SetString("UserRole", user.Role.ToString());
        HttpContext.Session.SetString("Username", user.Username);

        // Force password change: block dashboard until staff updates password.
        if (user.MustChangePassword)
        {
            HttpContext.Session.SetString("MustChangePassword", "1");
            await _audit.LogAsync("login", "user", user.Id, user.Username + " (must change password)", user.Id, user.FullName);
            TempData["Info"] = "For security, please change your default password before continuing.";
            return RedirectToAction(nameof(ChangePassword));
        }

        HttpContext.Session.Remove("MustChangePassword");
        await _audit.LogAsync("login", "user", user.Id, user.Username, user.Id, user.FullName);

        if (!string.IsNullOrEmpty(model.ReturnUrl) && Url.IsLocalUrl(model.ReturnUrl))
            return Redirect(model.ReturnUrl);

        // Housekeeping lands on Room Board (status + Mark Cleaned only).
        if (user.Role == UserRole.Housekeeping)
            return RedirectToAction("Board", "Room");

        return RedirectToAction("Index", "Dashboard");
    }

    [AllowAnonymous]
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        var uid = HttpContext.Session.GetInt32("UserId");
        var name = HttpContext.Session.GetString("UserFullName")
                   ?? HttpContext.Session.GetString("Username");
        if (uid != null)
            await _audit.LogAsync("logout", "user", uid, name, uid, name);
        HttpContext.Session.Clear();
        return RedirectToAction("Login");
    }

    [AllowAnonymous]
    public IActionResult AccessDenied() => View();

    /// <summary>
    /// Staff change-password form (any logged-in role).
    /// </summary>
    [HttpGet]
    public IActionResult ChangePassword()
    {
        if (HttpContext.Session.GetInt32("UserId") == null)
            return RedirectToAction(nameof(Login));
        return View(new ChangePasswordViewModel());
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> ChangePassword(ChangePasswordViewModel model)
    {
        var uid = HttpContext.Session.GetInt32("UserId");
        if (uid == null)
            return RedirectToAction(nameof(Login));

        if (!ModelState.IsValid)
            return View(model);

        var user = await _db.Users.FindAsync(uid.Value);
        if (user == null || !user.IsActive)
        {
            HttpContext.Session.Clear();
            return RedirectToAction(nameof(Login));
        }

        if (!BCrypt.Net.BCrypt.Verify(model.CurrentPassword, user.PasswordHash))
        {
            ModelState.AddModelError(nameof(model.CurrentPassword), "Current password is incorrect.");
            return View(model);
        }

        if (string.Equals(model.CurrentPassword, model.NewPassword, StringComparison.Ordinal))
        {
            ModelState.AddModelError(nameof(model.NewPassword), "New password must be different from the current password.");
            return View(model);
        }

        user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(model.NewPassword);
        user.MustChangePassword = false;
        await _db.SaveChangesAsync();
        HttpContext.Session.Remove("MustChangePassword");
        await _audit.LogAsync("change_password", "user", user.Id, "Staff changed own password", user.Id, user.FullName);

        TempData["Success"] = "Password changed successfully. You can now use the system.";

        // After forced change, send them to their normal home page.
        var role = HttpContext.Session.GetString("UserRole") ?? "";
        if (string.Equals(role, "Housekeeping", StringComparison.OrdinalIgnoreCase))
            return RedirectToAction("Board", "Room");
        return RedirectToAction("Index", "Dashboard");
    }
}
