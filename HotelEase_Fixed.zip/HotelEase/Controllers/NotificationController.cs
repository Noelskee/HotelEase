using HotelEase.Data;
using HotelEase.Models;
using HotelEase.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HotelEase.Controllers;

// Staff-only endpoints for the top-bar notification bell.
[RequireRole(UserRole.Admin, UserRole.FrontDesk, UserRole.Housekeeping)]
public class NotificationController : Controller
{
    private readonly ApplicationDbContext _db;

    public NotificationController(ApplicationDbContext db) => _db = db;

    [HttpGet]
    public async Task<IActionResult> Recent(int take = 20)
    {
        if (HttpContext.Session.GetInt32("UserId") == null)
            return Unauthorized();

        take = Math.Clamp(take, 1, 50);
        var raw = await _db.Notifications
            .OrderByDescending(n => n.CreatedAt)
            .Take(take)
            .Select(n => new
            {
                id = n.Id,
                type = n.Type,
                text = n.Message,
                link = n.Link,
                isRead = n.IsRead,
                createdAt = n.CreatedAt
            })
            .ToListAsync();

        // Emit ISO-8601 UTC with trailing Z so the browser treats the stamp as UTC
        // (avoids double local-offset / wrong "x min ago" in the staff bell).
        var items = raw.Select(n => new
        {
            n.id,
            n.type,
            n.text,
            n.link,
            n.isRead,
            createdAt = (n.createdAt.Kind == DateTimeKind.Unspecified
                    ? DateTime.SpecifyKind(n.createdAt, DateTimeKind.Utc)
                    : n.createdAt.ToUniversalTime()
                ).ToString("o")
        }).ToList();

        var unread = await _db.Notifications.CountAsync(n => !n.IsRead);
        return Json(new { unread, items });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> MarkRead(int id)
    {
        if (HttpContext.Session.GetInt32("UserId") == null)
            return Unauthorized();

        var n = await _db.Notifications.FindAsync(id);
        if (n == null) return NotFound();
        n.IsRead = true;
        await _db.SaveChangesAsync();
        return Ok();
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> MarkAllRead()
    {
        if (HttpContext.Session.GetInt32("UserId") == null)
            return Unauthorized();

        var unread = await _db.Notifications.Where(n => !n.IsRead).ToListAsync();
        foreach (var n in unread) n.IsRead = true;
        await _db.SaveChangesAsync();
        return Ok();
    }

    /// <summary>
    /// Live counts for sidebar badges.
    /// pendingArrivals = arrivals still awaiting check-in (on/before today)
    /// inHouse = currently CheckedIn guests (managed under Check-In nav)
    /// todayCheckOuts = guests who completed check-out today (Check-Out nav)
    /// dirtyRooms = rooms with ForCleaning status
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> SidebarCounts()
    {
        if (HttpContext.Session.GetInt32("UserId") == null)
            return Unauthorized();

        var today = DateTime.Today;

        var pendingArrivals = await _db.Reservations.CountAsync(r =>
            (r.Status == Models.ReservationStatus.Reserved
             || r.Status == Models.ReservationStatus.Confirmed
             || r.Status == Models.ReservationStatus.Pending)
            && ((r.ExpectedCheckIn.HasValue && r.ExpectedCheckIn.Value.Date <= today)
                || (!r.ExpectedCheckIn.HasValue && r.CheckInDate.HasValue && r.CheckInDate.Value.Date <= today)));

        var inHouse = await _db.Reservations.CountAsync(r =>
            r.Status == Models.ReservationStatus.CheckedIn);

        var todayCheckOuts = await _db.Reservations.CountAsync(r =>
            (r.Status == Models.ReservationStatus.CheckedOut
             || r.Status == Models.ReservationStatus.Completed)
            && r.ActualCheckOut.HasValue
            && r.ActualCheckOut.Value.Date == today);

        var dirtyRooms = await _db.Rooms.CountAsync(r =>
            r.Status == Models.RoomStatus.ForCleaning);

        return Json(new { pendingArrivals, inHouse, todayCheckOuts, dirtyRooms });
    }
}
