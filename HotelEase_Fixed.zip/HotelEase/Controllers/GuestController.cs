using HotelEase.Data;
using HotelEase.Filters;
using HotelEase.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HotelEase.Controllers
{
    // Staff-only: guest PII must never be anonymous. Admin + FrontDesk manage guests.
    [RequireRole(UserRole.Admin, UserRole.FrontDesk)]
    public class GuestController : Controller
    {
        private readonly ApplicationDbContext _context;
        public GuestController(ApplicationDbContext ctx) => _context = ctx;

        // GET: /Guest
        // Shows only active (non-archived) guests. New guests are created
        // through the Walk-In Reservation flow.
        public async Task<IActionResult> Index(string? search)
        {
            var query = _context.Guests
                .Include(g => g.Reservations).ThenInclude(r => r.Room).ThenInclude(rm => rm!.RoomType)
                .Include(g => g.Reservations).ThenInclude(r => r.Transaction)
                .Where(g => !g.IsArchived && !g.IsSystemRecord);

            if (!string.IsNullOrWhiteSpace(search))
            {
                var s = search.Trim();
                query = query.Where(g =>
                    g.FullName.Contains(s) ||
                    (g.ContactNumber != null && g.ContactNumber.Contains(s)) ||
                    (g.Email != null && g.Email.Contains(s)));
            }

            var guests = await query.OrderBy(g => g.FullName).ToListAsync();
            ViewBag.Search = search;
            return View(guests);
        }

        // GET: /Guest/SearchJson?q=... — autocomplete for booking guest lookup
        [HttpGet]
        public async Task<IActionResult> SearchJson(string? q)
        {
            if (string.IsNullOrWhiteSpace(q) || q.Trim().Length < 1)
                return Json(Array.Empty<object>());

            var s = q.Trim();
            var guests = await _context.Guests
                .Where(g => !g.IsArchived && !g.IsSystemRecord &&
                    (g.FullName.Contains(s) ||
                     (g.ContactNumber != null && g.ContactNumber.Contains(s)) ||
                     (g.Email != null && g.Email.Contains(s))))
                .OrderBy(g => g.FullName)
                .Take(8)
                .Select(g => new {
                    id = g.Id,
                    fullName = g.FullName,
                    phone = g.ContactNumber,
                    email = g.Email,
                    nationality = g.Nationality,
                    // ID numbers omitted from autocomplete JSON (privacy).
                    isSenior = g.IsSeniorCitizen,
                    isPwd = g.IsPwd
                })
                .ToListAsync();

            return Json(guests);
        }


        // GET: /Guest/Details/{id} — profile + stay history (Emergent-style)
        public async Task<IActionResult> Details(int id)
        {
            var guest = await _context.Guests
                .Include(g => g.Reservations).ThenInclude(r => r.Room)
                .Include(g => g.Reservations).ThenInclude(r => r.Transaction)
                .FirstOrDefaultAsync(g => g.Id == id && !g.IsSystemRecord);
            if (guest == null) return NotFound();
            return View(guest);
        }

        // GET: /Guest/Archived
        // Guests that have been soft-deleted / archived. Their records and
        // reservation and transaction history remain attached and can be restored at any time.
        public async Task<IActionResult> Archived()
        {
            var guests = await _context.Guests
                .Include(g => g.Reservations).ThenInclude(r => r.Room).ThenInclude(rm => rm!.RoomType)
                .Include(g => g.Reservations).ThenInclude(r => r.Transaction)
                .Where(g => g.IsArchived && !g.IsSystemRecord)
                .OrderByDescending(g => g.ArchivedAt)
                .ToListAsync();
            return View(guests);
        }

        // POST: /Guest/Edit
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guest guest)
        {
            guest.FullName = guest.FullName?.Trim() ?? string.Empty;
            guest.ContactNumber = guest.ContactNumber?.Trim() ?? string.Empty;
            guest.Nationality = guest.Nationality?.Trim() ?? string.Empty;

            if (!ModelState.IsValid)
            {
                TempData["Error"] = "Please fill in all required fields correctly.";
                return RedirectToAction(nameof(Index));
            }

            var existing = await _context.Guests.FindAsync(guest.Id);
            if (existing == null)
            {
                TempData["Error"] = "Guest not found.";
                return RedirectToAction(nameof(Index));
            }

            // Contact numbers are no longer treated as a unique guest identifier —
            // different people (e.g. family members sharing one phone) can be
            // registered under the same contact number as separate guest records,
            // each keeping their own stay history under their own name.
            existing.FullName = guest.FullName;
            existing.ContactNumber = guest.ContactNumber;
            existing.Nationality = guest.Nationality;
            existing.NumberOfGuests = guest.NumberOfGuests;

            await _context.SaveChangesAsync();
            TempData["Success"] = $"Guest \"{guest.FullName}\" has been updated successfully.";
            return RedirectToAction(nameof(Index));
        }

        // POST: /Guest/Archive
        // Soft-deletes a guest: hides them from Guest Management while
        // keeping their record and stay history intact, so nothing is lost.
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Archive(int id)
        {
            var guest = await _context.Guests.FindAsync(id);
            if (guest == null)
            {
                TempData["Error"] = "Guest not found.";
                return RedirectToAction(nameof(Index));
            }

            guest.IsArchived = true;
            guest.ArchivedAt = DateTime.UtcNow;
            await _context.SaveChangesAsync();
            TempData["Success"] = $"Guest \"{guest.FullName}\" has been archived.";
            return RedirectToAction(nameof(Index));
        }

        // POST: /Guest/Restore
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Restore(int id)
        {
            var guest = await _context.Guests.FindAsync(id);
            if (guest == null)
            {
                TempData["Error"] = "Guest not found.";
                return RedirectToAction(nameof(Archived));
            }

            guest.IsArchived = false;
            guest.ArchivedAt = null;
            await _context.SaveChangesAsync();
            TempData["Success"] = $"Guest \"{guest.FullName}\" has been restored.";
            return RedirectToAction(nameof(Archived));
        }

        // POST: /Guest/DeletePermanently
        // Only reachable from the Archived view — a true, irreversible
        // delete of the guest's personal record. Reservations that never
        // produced a Transaction (no revenue impact — e.g. cancelled/no-show
        // with nothing billed) are deleted along with the guest. Reservations
        // that DID produce a Transaction are revenue history: instead of being
        // deleted, they're reassigned to a single hidden "Deleted Guest"
        // placeholder record so the Dashboard's revenue totals are never
        // reduced by deleting a guest.
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> DeletePermanently(int id)
        {
            var guest = await _context.Guests
                .Include(g => g.Reservations).ThenInclude(r => r.Transaction)
                .FirstOrDefaultAsync(g => g.Id == id && g.IsArchived);

            if (guest == null)
            {
                TempData["Error"] = "Archived guest not found.";
                return RedirectToAction(nameof(Archived));
            }

            var revenueReservations = guest.Reservations.Where(r => r.Transaction != null).ToList();
            var noRevenueReservations = guest.Reservations.Where(r => r.Transaction == null).ToList();

            if (revenueReservations.Any())
            {
                var placeholder = await _context.Guests
                    .FirstOrDefaultAsync(g => g.IsSystemRecord);

                if (placeholder == null)
                {
                    placeholder = new Guest
                    {
                        FullName = "Deleted Guest",
                        ContactNumber = "N/A",
                        Nationality = "N/A",
                        NumberOfGuests = 1,
                        IsArchived = true,
                        ArchivedAt = DateTime.UtcNow,
                        IsSystemRecord = true,
                        CreatedAt = DateTime.UtcNow
                    };
                    _context.Guests.Add(placeholder);
                    await _context.SaveChangesAsync();
                }

                foreach (var reservation in revenueReservations)
                {
                    reservation.GuestId = placeholder.Id;
                }

            }

            _context.Reservations.RemoveRange(noRevenueReservations);
            _context.Guests.Remove(guest);
            await _context.SaveChangesAsync();
            TempData["Success"] = $"Guest \"{guest.FullName}\" has been permanently deleted. Revenue already recorded from this guest's past stays is kept intact.";
            return RedirectToAction(nameof(Archived));
        }

    }
}
