using HotelEase.Data;
using HotelEase.Filters;
using HotelEase.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HotelEase.Controllers;

[RequireRole(UserRole.Admin)]
public class RoomTypeImageController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly IWebHostEnvironment _env;

    private static readonly string[] AllowedExtensions = { ".jpg", ".jpeg", ".png", ".webp" };
    private const long MaxFileSize = 5 * 1024 * 1024; // 5 MB

    public RoomTypeImageController(ApplicationDbContext context, IWebHostEnvironment env)
    {
        _context = context;
        _env = env;
    }

    [HttpGet]
    public async Task<IActionResult> List(int roomTypeId)
    {
        var images = await _context.RoomTypeImages
            .Where(i => i.RoomTypeId == roomTypeId)
            .OrderBy(i => i.DisplayOrder)
            .ThenBy(i => i.Id)
            .Select(i => new {
                i.Id,
                i.ImageUrl,
                i.FileName,
                i.Caption,
                i.IsPrimary,
                i.DisplayOrder
            })
            .ToListAsync();
        return Json(images);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Upload(int roomTypeId, List<IFormFile> files)
    {
        var roomType = await _context.RoomTypes.FindAsync(roomTypeId);
        if (roomType == null) return NotFound();
        if (files == null || files.Count == 0)
            return Json(new { success = false, message = "No files selected." });

        var uploadPath = Path.Combine(_env.WebRootPath, "uploads", "roomtypes", roomTypeId.ToString());
        Directory.CreateDirectory(uploadPath);

        var existingCount = await _context.RoomTypeImages.CountAsync(i => i.RoomTypeId == roomTypeId);
        var uploaded = new List<object>();

        foreach (var file in files)
        {
            if (file.Length == 0) continue;
            if (file.Length > MaxFileSize)
            {
                uploaded.Add(new { fileName = file.FileName, success = false, message = "File exceeds 5 MB." });
                continue;
            }

            var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
            if (!AllowedExtensions.Contains(ext))
            {
                uploaded.Add(new { fileName = file.FileName, success = false, message = "Only JPG, PNG, and WEBP images are allowed." });
                continue;
            }

            var fileName = $"{Guid.NewGuid():N}{ext}";
            var filePath = Path.Combine(uploadPath, fileName);
            await using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            var image = new RoomTypeImage
            {
                RoomTypeId = roomTypeId,
                ImageUrl = $"/uploads/roomtypes/{roomTypeId}/{fileName}",
                FileName = file.FileName,
                DisplayOrder = existingCount + uploaded.Count,
                IsPrimary = existingCount == 0 && uploaded.Count == 0
            };
            _context.RoomTypeImages.Add(image);
            await _context.SaveChangesAsync();

            uploaded.Add(new
            {
                fileName = file.FileName,
                success = true,
                image = new
                {
                    image.Id,
                    image.ImageUrl,
                    image.FileName,
                    image.Caption,
                    image.IsPrimary,
                    image.DisplayOrder
                }
            });
        }

        return Json(new { success = true, uploaded });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> SetPrimary(int id)
    {
        var image = await _context.RoomTypeImages.FindAsync(id);
        if (image == null) return NotFound();

        var siblings = await _context.RoomTypeImages
            .Where(i => i.RoomTypeId == image.RoomTypeId && i.Id != id)
            .ToListAsync();
        foreach (var s in siblings) s.IsPrimary = false;
        image.IsPrimary = true;

        await _context.SaveChangesAsync();
        return Json(new { success = true });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> UpdateCaption(int id, string? caption)
    {
        var image = await _context.RoomTypeImages.FindAsync(id);
        if (image == null) return NotFound();
        image.Caption = caption;
        await _context.SaveChangesAsync();
        return Json(new { success = true });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id)
    {
        var image = await _context.RoomTypeImages.FindAsync(id);
        if (image == null) return NotFound();

        var physicalPath = Path.Combine(_env.WebRootPath, image.ImageUrl.TrimStart('/').Replace('/', Path.DirectorySeparatorChar));
        if (System.IO.File.Exists(physicalPath))
        {
            try { System.IO.File.Delete(physicalPath); } catch { /* best effort */ }
        }

        var roomTypeId = image.RoomTypeId;
        var wasPrimary = image.IsPrimary;
        _context.RoomTypeImages.Remove(image);
        await _context.SaveChangesAsync();

        if (wasPrimary)
        {
            var next = await _context.RoomTypeImages
                .Where(i => i.RoomTypeId == roomTypeId)
                .OrderBy(i => i.DisplayOrder)
                .ThenBy(i => i.Id)
                .FirstOrDefaultAsync();
            if (next != null)
            {
                next.IsPrimary = true;
                await _context.SaveChangesAsync();
            }
        }

        return Json(new { success = true });
    }
}