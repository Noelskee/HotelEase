using System.Text.Json;
using HotelEase.Data;
using HotelEase.Filters;
using HotelEase.Models;
using HotelEase.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HotelEase.Controllers
{
    // Analytics dashboard (occupancy, arrivals/departures, revenue trend),
    // built on top of the Reservation/Transaction modules added alongside
    // Reservations/Billing/Housekeeping. Kept as its own controller/route
    // (rather than folded into HomeController.Index) so the original
    // Home/Index room-overview page keeps behaving exactly as before.
    [RequireRole(UserRole.Admin, UserRole.FrontDesk, UserRole.Housekeeping)]
    public class DashboardController : Controller
    {
        private readonly ApplicationDbContext _db;
        public DashboardController(ApplicationDbContext db) => _db = db;

        public async Task<IActionResult> Index()
        {
            // Housekeeping: operational dashboard is out of scope — room board only.
            var role = HttpContext.Session.GetString("UserRole") ?? "";
            if (string.Equals(role, "Housekeeping", StringComparison.OrdinalIgnoreCase))
                return RedirectToAction("Board", "Room");

            var today = DateTime.Today;

            var vm = new DashboardViewModel
            {
                TotalRooms = await _db.Rooms.CountAsync(),
                AvailableRooms = await _db.Rooms.CountAsync(r => r.Status == RoomStatus.Available),
                OccupiedRooms = await _db.Rooms.CountAsync(r => r.Status == RoomStatus.Occupied),
                ReservedRooms = await _db.Rooms.CountAsync(r => r.Status == RoomStatus.Reserved),
                ForCleaningRooms = await _db.Rooms.CountAsync(r => r.Status == RoomStatus.ForCleaning),

                // Confirmed + Reserved = active pre-check-in bookings (Save Booking creates Confirmed)
                TodayArrivals = await _db.Reservations.CountAsync(r =>
                    (r.Status == ReservationStatus.Reserved || r.Status == ReservationStatus.Confirmed)
                    && r.CheckInDate.HasValue
                    && r.CheckInDate.Value.Date == today),

                TodayDepartures = await _db.Reservations.CountAsync(r =>
                    r.Status == ReservationStatus.CheckedIn
                    && r.ExpectedCheckOut.HasValue
                    && r.ExpectedCheckOut.Value.Date == today),

                PendingReservations = await _db.Reservations.CountAsync(r =>
                    r.Status == ReservationStatus.Pending),

                // Revenue must reflect the FULL amount charged for the stay
                // (TotalAmount / RoomChargesTotal), not FinalAmount — at
                // Check-Out, FinalAmount is recomputed as the remaining
                // balance still owed AFTER subtracting whatever was already
                // collected at Check-In (AmountPaidAtCheckIn). Summing
                // FinalAmount here would silently drop the Check-In payment
                // from reported revenue whenever a stay was already paid in
                // full and Check-Out only settled a small extra charge.
                TodayRevenue = await _db.Transactions
                    .Where(t => t.ActualCheckOut.HasValue && t.ActualCheckOut.Value.Date == today)
                    .SumAsync(t => (decimal?)t.TotalAmount) ?? 0,

                // Bookings only — CheckedIn belongs under Check-In / Check-Out, not Reservations.
                RecentReservations = await _db.Reservations
                    .Include(r => r.Guest)
                    .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
                    .Where(r => r.Status != ReservationStatus.CheckedIn)
                    .OrderByDescending(r => r.CreatedAt)
                    .Take(10)
                    .ToListAsync(),

                RoomsForCleaning = await _db.Rooms
                    .Include(r => r.RoomType)
                    .Where(r => r.Status == RoomStatus.ForCleaning)
                    .ToListAsync(),

                TodayArrivalsList = await _db.Reservations
                    .Include(r => r.Guest)
                    .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
                    .Where(r => (r.Status == ReservationStatus.Reserved || r.Status == ReservationStatus.Confirmed)
                        && r.CheckInDate.HasValue
                        && r.CheckInDate.Value.Date == today)
                    .OrderBy(r => r.CreatedAt)
                    .ToListAsync(),

                TodayArrivalsAlreadyCheckedIn = await _db.Reservations
                    .CountAsync(r => r.Status == ReservationStatus.CheckedIn
                        && r.ActualCheckIn.HasValue
                        && r.ActualCheckIn.Value.Date == today),

                TodayDeparturesList = await _db.Reservations
                    .Include(r => r.Guest)
                    .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
                    .Where(r => r.Status == ReservationStatus.CheckedIn
                        && r.ExpectedCheckOut.HasValue
                        && r.ExpectedCheckOut.Value.Date == today)
                    .OrderBy(r => r.ExpectedCheckOut)
                    .ToListAsync(),

                // All currently in-house (after Check-In) — shown on Dashboard
                InHouseGuests = await _db.Reservations
                    .Include(r => r.Guest)
                    .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
                    .Include(r => r.Transaction)
                    .Where(r => r.Status == ReservationStatus.CheckedIn)
                    .OrderByDescending(r => r.ActualCheckIn)
                    .ToListAsync(),

                // Advance / awaiting arrival — all pre-check-in bookings (not today-only)
                AdvanceReservations = await _db.Reservations
                    .Include(r => r.Guest)
                    .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
                    .Include(r => r.PreferredRoomType)
                    .Where(r => r.Status == ReservationStatus.Pending
                             || r.Status == ReservationStatus.Confirmed
                             || r.Status == ReservationStatus.Reserved)
                    .OrderBy(r => r.ExpectedCheckIn ?? r.CheckInDate ?? r.CreatedAt)
                    .ThenByDescending(r => r.CreatedAt)
                    .Take(50)
                    .ToListAsync()
            };

            // 7-day trend: for each of the last 7 days, work out how many rooms
            // were actually checked in that day (occupancy) and how much
            // revenue was collected (from transactions closed that day).
            var totalRooms = vm.TotalRooms;
            for (var i = 6; i >= 0; i--)
            {
                var day = today.AddDays(-i);

                var occupiedThatDay = await _db.Reservations.CountAsync(r =>
                    r.ActualCheckIn.HasValue && r.ExpectedCheckOut.HasValue
                    && r.ActualCheckIn.Value.Date <= day
                    && r.ExpectedCheckOut.Value.Date > day
                    && (r.Status == ReservationStatus.CheckedIn || r.Status == ReservationStatus.CheckedOut || r.Status == ReservationStatus.Completed));

                // Same reasoning as TodayRevenue above: use TotalAmount (the
                // full charge for the stay), not FinalAmount (the remaining
                // balance after Check-In payment is subtracted).
                var revenueThatDay = await _db.Transactions
                    .Where(t => t.ActualCheckOut.HasValue && t.ActualCheckOut.Value.Date == day)
                    .SumAsync(t => (decimal?)t.TotalAmount) ?? 0;

                vm.WeeklyTrend.Add(new DashboardTrendPoint
                {
                    Date = day,
                    OccupancyRate = totalRooms > 0 ? Math.Round(occupiedThatDay * 100.0 / totalRooms, 0) : 0,
                    Revenue = revenueThatDay
                });
            }

            vm.WeeklyTrendLabelsJson = JsonSerializer.Serialize(vm.WeeklyTrend.Select(t => t.Date.ToString("MMM d")));
            vm.WeeklyTrendOccupancyJson = JsonSerializer.Serialize(vm.WeeklyTrend.Select(t => t.OccupancyRate));
            vm.WeeklyTrendRevenueJson = JsonSerializer.Serialize(vm.WeeklyTrend.Select(t => t.Revenue));
            vm.TrendRangeLabel = vm.WeeklyTrend.Count > 0
                ? $"{vm.WeeklyTrend[0].Date:MMM d} - {vm.WeeklyTrend[^1].Date:MMM d, yyyy}"
                : "";

            vm.TodayDeparturesAlreadyCheckedOut = vm.TodayDeparturesList.Count(d => d.Status == ReservationStatus.CheckedOut || d.Status == ReservationStatus.Completed);

                        // In-House Guests = total people checked in, not occupied room count
            vm.InHouseGuestCount = vm.InHouseGuests?.Sum(r => Math.Max(1, r.GuestCount > 0 ? r.GuestCount : (r.Adults + r.Children))) ?? 0;

            return View(vm);
        }
    }
}
