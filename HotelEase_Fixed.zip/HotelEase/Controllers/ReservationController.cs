using HotelEase.Data;
using HotelEase.Filters;
using HotelEase.Models;
using HotelEase.Services;
using HotelEase.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace HotelEase.Controllers;

// Staff-only: create, manage, confirm/pay, and cancel reservations, and
// record pre-check-in extra hours. Requires login like every other staff
// module — RequireLoginFilter applies here since there's no
// [AllowAnonymous] on this controller.
//
// This controller covers the two "guest is not at the desk yet" transaction
// scenarios (Normal Reservation — pay later, and Advance/Prepaid
// Reservation — pay now). The third scenario, Walk-In (guest physically at
// the desk, pays and is checked in immediately), lives entirely in
// FrontDeskController and never routes through here.
[RequireRole(UserRole.Admin, UserRole.FrontDesk)]
public class ReservationController : Controller
{
    private readonly ApplicationDbContext _db;
    private readonly IBillingService _billingSvc;
    private readonly IReservationService _reservationSvc;
    public ReservationController(ApplicationDbContext db, IBillingService billingSvc,
        IReservationService reservationSvc)
    {
        _db = db;
        _billingSvc = billingSvc;
        _reservationSvc = reservationSvc;
    }

    // No maximum advance-booking limit — staff may reserve any future date.

    // Staff: manage reservations
    public async Task<IActionResult> Manage(string? status, string? search, DateTime? date)
    {
        // Status counts for the summary cards (always global, not filtered).
        var pendingCount = await _db.Reservations.CountAsync(r => r.Status == ReservationStatus.Pending);
        var confirmedCount = await _db.Reservations.CountAsync(r =>
            r.Status == ReservationStatus.Confirmed || r.Status == ReservationStatus.Reserved);
        var checkedInCount = await _db.Reservations.CountAsync(r => r.Status == ReservationStatus.CheckedIn);
        var checkedOutCount = await _db.Reservations.CountAsync(r =>
            r.Status == ReservationStatus.CheckedOut || r.Status == ReservationStatus.Completed);
        var cancelledCount = await _db.Reservations.CountAsync(r =>
            r.Status == ReservationStatus.Cancelled || r.Status == ReservationStatus.NoShow);

        var query = _db.Reservations
            .Include(r => r.Guest)
            .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
            .Include(r => r.PreferredRoomType)
            .Include(r => r.Transaction)
            .AsQueryable();

        // Booking is strictly a pre-arrival module: no matter what status value is
        // requested (including a hand-typed querystring), CheckedIn / CheckedOut /
        // Completed records must never be reachable here. Once a guest is checked
        // in, that guest can only be found under Check-In / Check-Out.
        ReservationStatus s = default;
        var allowedExplicitStatus = !string.IsNullOrEmpty(status)
            && Enum.TryParse<ReservationStatus>(status, out s)
            && s != ReservationStatus.CheckedIn
            && s != ReservationStatus.CheckedOut
            && s != ReservationStatus.Completed;

        if (allowedExplicitStatus)
        {
            // Card filters group related statuses for a cleaner summary.
            if (status!.Equals("Confirmed", StringComparison.OrdinalIgnoreCase))
                query = query.Where(r => r.Status == ReservationStatus.Confirmed || r.Status == ReservationStatus.Reserved);
            else if (status.Equals("Cancelled", StringComparison.OrdinalIgnoreCase))
                query = query.Where(r => r.Status == ReservationStatus.Cancelled || r.Status == ReservationStatus.NoShow);
            else
                query = query.Where(r => r.Status == s);
        }
        else
        {
            // Default "Active bookings" view: Booking page is for pre-arrival
            // bookings only. Once CheckedIn the guest is managed under Front Desk.
            query = query.Where(r => r.Status == ReservationStatus.Pending
                                  || r.Status == ReservationStatus.Confirmed
                                  || r.Status == ReservationStatus.Reserved);
        }

        if (!string.IsNullOrEmpty(search))
            query = query.Where(r => r.ReferenceNumber.Contains(search)
                || r.Guest.FullName.Contains(search)
                || (r.Guest.ContactNumber != null && r.Guest.ContactNumber.Contains(search))
                || (r.Room != null && r.Room.RoomNumber.Contains(search))
                || (r.PreferredRoomType != null && r.PreferredRoomType.Name.Contains(search)));

        // Date filter kept optional via query string only (no input on the page).
        if (date.HasValue)
            query = query.Where(r => r.ActualCheckIn.HasValue && r.ActualCheckIn.Value.Date == date.Value.Date
                || (r.ExpectedCheckIn.HasValue && r.ExpectedCheckIn.Value.Date == date.Value.Date)
                || (r.CheckInDate.HasValue && r.CheckInDate.Value.Date == date.Value.Date));

        var vm = new ReservationListViewModel
        {
            Reservations = await query.OrderByDescending(r => r.CreatedAt).ToListAsync(),
            StatusFilter = status,
            Search = search,
            DateFilter = date,
            PendingCount = pendingCount,
            ConfirmedCount = confirmedCount,
            CheckedInCount = checkedInCount,
            CheckedOutCount = checkedOutCount,
            CancelledCount = cancelledCount
        };
        return View(vm);
    }

    public async Task<IActionResult> Details(int id)
    {
        var res = await _db.Reservations
            .Include(r => r.Guest)
            .Include(r => r.PreferredRoomType)
            .Include(r => r.Room)
                .ThenInclude(rm => rm!.RoomType)
                    .ThenInclude(rt => rt!.RoomTypeAmenities)
                        .ThenInclude(rta => rta.Amenity)
            .Include(r => r.Room)
                .ThenInclude(rm => rm!.RoomType)
                    .ThenInclude(rt => rt!.Images)
            .Include(r => r.Transaction)
            .Include(r => r.CreatedByUser)
            .FirstOrDefaultAsync(r => r.Id == id);
        if (res == null) return NotFound();
        // Rooms offered for a mid-stay transfer come from the central availability
        // rule, using the guest's remaining stay window (now -> check-out).
        var transferFrom = DateTime.Now;
        var transferTo = res.ExpectedCheckOut ?? res.CheckOutDate ?? transferFrom.AddDays(1);
        if (transferTo <= transferFrom) transferTo = transferFrom.AddHours(1);
        ViewBag.AvailableRooms = await _reservationSvc.GetAvailableRoomsAsync(transferFrom, transferTo, res.Id);

        // Group siblings: multi-room booking shares base ref (REF, REF-1, REF-2…)
        var baseRef = System.Text.RegularExpressions.Regex.Replace(
            res.ReferenceNumber ?? "", @"-R?\d+$", "");
        var siblings = await _db.Reservations
            .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
            .Include(r => r.Transaction)
            .Include(r => r.Guest)
            .Where(r => r.ReferenceNumber == baseRef
                     || r.ReferenceNumber.StartsWith(baseRef + "-")
                     || (r.SpecialRequests != null && r.SpecialRequests.Contains(baseRef)))
            .OrderBy(r => r.ReferenceNumber)
            .ToListAsync();
        if (!siblings.Any(s => s.Id == res.Id))
            siblings.Insert(0, res);
        ViewBag.GroupReservations = siblings;
        ViewBag.IsGroupFolio = siblings.Count > 1;
        return View(res);
    }

    // Confirm Reservation. This ONLY moves the reservation from
    // Pending → Confirmed and reserves the room — it never touches
    // PaymentStatus. A reservation can be, and often is, Confirmed +
    // Unpaid: the guest simply pays later, at Check-In (see
    // FrontDeskController.CheckIn, which already asks for payment only when
    // PaymentStatus != Paid). To collect payment now instead — the
    // Advance/Prepaid scenario — use Pay(), not this action.
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Confirm(int id)
    {
        var res = await _db.Reservations
            .Include(r => r.Guest)
            .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
            .FirstOrDefaultAsync(r => r.Id == id);
        if (res == null) return NotFound();

        if (res.Status != ReservationStatus.Pending && res.Status != ReservationStatus.Reserved)
        {
            TempData["Error"] = $"Reservation cannot be confirmed from status '{res.Status}'.";
            return RedirectToAction("Details", new { id });
        }

        // Walk-ins are handled by the FrontDesk walk-in payment flow, not by
        // the advance-reservation confirmation screen.
        if (res.Type == ReservationType.WalkIn)
        {
            TempData["Error"] = "Walk-in reservations must be checked in via the Walk-In payment screen.";
            return RedirectToAction("Details", new { id });
        }

        if (res.Room != null && res.Room.Status != RoomStatus.Available && res.Room.Status != RoomStatus.Reserved)
        {
            TempData["Error"] = $"Room {res.Room.RoomNumber} is not available.";
            return RedirectToAction("Details", new { id });
        }

        // Re-check the room isn't double-booked for this reservation's dates
        // before confirming (server-side, not just at creation time).
        // Only re-check a physical room when one was already assigned (legacy
        // bookings). New reservations leave RoomId null until check-in.
        if (res.RoomId.HasValue
            && res.CheckInDate.HasValue && res.CheckOutDate.HasValue
            && !_reservationSvc.IsRoomAvailable(res.RoomId.Value, res.CheckInDate.Value, res.CheckOutDate.Value, res.Id))
        {
            TempData["Error"] = $"Room {res.Room!.RoomNumber} is no longer available for the requested dates.";
            return RedirectToAction("Details", new { id });
        }

        // Confirm this reservation and any multi-room siblings that share the
        // same base reference (e.g. REF, REF-1, REF-2). Online multi-room
        // bookings create one Pending row per room; confirming any member must
        // clear the whole group from Pending Reserves.
        var baseRef = System.Text.RegularExpressions.Regex.Replace(
            res.ReferenceNumber ?? "", @"-R?\d+$", "");
        var toConfirm = await _db.Reservations
            .Include(r => r.Room)
            .Where(r => (r.ReferenceNumber == baseRef
                      || r.ReferenceNumber.StartsWith(baseRef + "-"))
                     && (r.Status == ReservationStatus.Pending
                      || r.Status == ReservationStatus.Reserved
                      || r.Id == res.Id))
            .ToListAsync();
        if (!toConfirm.Any(r => r.Id == res.Id))
            toConfirm.Add(res);

        var userId = HttpContext.Session.GetInt32("UserId") ?? 0;
        var userName = HttpContext.Session.GetString("UserFullName");

        foreach (var item in toConfirm)
        {
            // PaymentStatus is deliberately left exactly as it was: if it was
            // Unpaid it remains Unpaid (Confirmed + Unpaid is a valid, expected
            // state — see business rule §8); if it was already Paid (e.g. the
            // guest paid first via Pay()), it remains Paid.
            if (item.Status == ReservationStatus.Pending || item.Status == ReservationStatus.Reserved)
                item.Status = ReservationStatus.Confirmed;

            if (item.Room != null
                && (item.Room.Status == RoomStatus.Available || item.Room.Status == RoomStatus.Reserved))
            {
                var oldRoomStatus = item.Room.Status;
                item.Room.Status = RoomStatus.Reserved;
                if (oldRoomStatus != RoomStatus.Reserved)
                {
                    _db.AuditLogs.Add(new AuditLog
                    {
                        Action = "update_room_status",
                        EntityType = "Room",
                        EntityId = item.Room.Id,
                        UserId = userId > 0 ? userId : null,
                        UserName = userName,
                        Details = $"{oldRoomStatus} → Reserved | Reserved for reservation {item.ReferenceNumber}",
                        CreatedAt = DateTime.UtcNow
                    });
                }
            }

            WriteAudit("confirm_reservation", "reservation", item.Id, item.ReferenceNumber);
        }

        await _db.SaveChangesAsync();

        var confirmedCount = toConfirm.Count;
        var anyPaid = toConfirm.Any(r => r.PaymentStatus == PaymentStatus.Paid);
        if (confirmedCount > 1)
        {
            TempData["Success"] = anyPaid
                ? $"Group reservation confirmed ({confirmedCount} rooms). Payment already on file for at least one room."
                : $"Group reservation confirmed ({confirmedCount} rooms). Payment has not been collected yet — guest can pay at Check-In, or collect advance payment now via Pay.";
        }
        else
        {
            TempData["Success"] = res.PaymentStatus == PaymentStatus.Paid
                ? "Reservation confirmed. Payment is already on file — no further payment is needed at check-in."
                : "Reservation confirmed. Payment has not been collected yet — the guest can pay at Check-In, or collect advance payment now via Pay.";
        }
        // Prefer returnUrl (Dashboard / Manage) so staff stay on the page they confirmed from.
        var returnUrl = (Request.Form["returnUrl"].ToString() ?? "").Trim();
        if (!string.IsNullOrEmpty(returnUrl)
            && (returnUrl.StartsWith("/Dashboard", StringComparison.OrdinalIgnoreCase)
                || returnUrl.StartsWith("/Reservation/Manage", StringComparison.OrdinalIgnoreCase)
                || returnUrl.StartsWith("/Reservation/Details", StringComparison.OrdinalIgnoreCase)))
            return Redirect(returnUrl);
        return Redirect("/Reservation/Manage");
    }

    // Pay Now — collects an advance/prepaid payment on a reservation that
    // is not yet fully paid (the Advance/Prepaid Reservation scenario).
    // Marks PaymentStatus = Paid (records the Transaction) and, if the
    // reservation was still Pending, also confirms it — matching business
    // rule §3's diagram (Payment → Confirmed/Paid). Once paid here,
    // FrontDeskController.CheckIn will not ask the guest to pay again.
    [HttpGet]
    public async Task<IActionResult> Pay(int id)
    {
        var res = await _db.Reservations
            .Include(r => r.Guest)
            .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
            .FirstOrDefaultAsync(r => r.Id == id);
        if (res == null) return NotFound();

        if (!CanPay(res, out var error))
        {
            TempData["Error"] = error;
            return RedirectToAction("Details", new { id });
        }

        var group = await GetGroupSiblingsAsync(res);
        var unpaid = group.Where(r => r.PaymentStatus != PaymentStatus.Paid).ToList();
        if (!unpaid.Any()) unpaid = new List<Reservation> { res };
        var totalDue = unpaid.Sum(ComputeTotalDue);
        var vm = new PayReservationViewModel
        {
            ReservationId = res.Id,
            Reservation = res,
            AmountDue = totalDue,
            AmountPaid = totalDue
        };
        ViewBag.GroupRooms = string.Join(", ", group.Select(g => g.Room?.RoomNumber).Where(n => n != null));
        ViewBag.IsGroupPay = group.Count > 1;
        return View(vm);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Pay(PayReservationViewModel vm)
    {
        var res = await _db.Reservations
            .Include(r => r.Guest)
            .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
            .Include(r => r.Transaction)
            .FirstOrDefaultAsync(r => r.Id == vm.ReservationId);
        if (res == null) return NotFound();

        if (!CanPay(res, out var error))
        {
            TempData["Error"] = error;
            return RedirectToAction("Details", new { id = vm.ReservationId });
        }

        var group = await GetGroupSiblingsAsync(res);
        foreach (var g in group)
        {
            if (g.Transaction == null)
                await _db.Entry(g).Reference(r => r.Transaction).LoadAsync();
        }

        // Rooms with remaining balance (supports in-house extension top-up)
        decimal RemainingOf(Reservation r)
        {
            if (r.Transaction == null) return ComputeTotalDue(r);
            return Math.Max(0m, r.Transaction.TotalAmount - r.Transaction.AmountPaidAtCheckIn);
        }

        var unpaid = group.Where(r => RemainingOf(r) > 0).ToList();
        var totalDue = unpaid.Sum(RemainingOf);
        if (!unpaid.Any() || totalDue <= 0)
        {
            TempData["Error"] = "No remaining balance to collect for this folio/group.";
            return RedirectToAction("Details", new { id = vm.ReservationId });
        }

        if (string.IsNullOrWhiteSpace(vm.PaymentMethod))
        {
            ModelState.AddModelError(nameof(vm.PaymentMethod), "Please select a payment method.");
        }
        else if (!string.Equals(vm.PaymentMethod, "Cash", StringComparison.OrdinalIgnoreCase)
            && !string.Equals(vm.PaymentMethod, "GCash", StringComparison.OrdinalIgnoreCase)
            && string.IsNullOrWhiteSpace(vm.PaymentReference))
        {
            ModelState.AddModelError(nameof(vm.PaymentReference), "Reference number is required for non-cash payments.");
        }

        if (!ModelState.IsValid)
        {
            vm.Reservation = res;
            vm.AmountDue = totalDue;
            ViewBag.GroupRooms = string.Join(", ", group.Select(g => g.Room?.RoomNumber).Where(n => n != null));
            ViewBag.IsGroupPay = group.Count > 1;
            TempData["Error"] = "Please correct the highlighted fields.";
            return RedirectToAction("Details", new { id = vm.ReservationId });
        }

        var paid = vm.AmountPaid ?? totalDue;
        var change = paid > totalDue ? paid - totalDue : (decimal?)null;
        var userId = HttpContext.Session.GetInt32("UserId") ?? 0;
        // Prefer updating existing transactions (in-house / already billed rooms)
        var isInHouseTopUp = unpaid.Any(r => r.Transaction != null);

        if (isInHouseTopUp)
        {
            // Apply payment against remaining balance on existing transactions
            var remainingPool = paid;
            foreach (var item in unpaid.OrderBy(r => r.Id))
            {
                var due = RemainingOf(item);
                if (due <= 0 || item.Transaction == null) continue;
                var apply = Math.Min(due, remainingPool);
                if (apply <= 0) break;
                item.Transaction.AmountPaidAtCheckIn += apply;
                if (item.Transaction.AmountPaidAtCheckIn >= item.Transaction.TotalAmount - 0.009m)
                {
                    item.Transaction.IsPaid = true;
                    item.Transaction.InvoiceStatus = InvoiceStatus.Paid;
                    item.PaymentStatus = PaymentStatus.Paid;
                }
                else if (item.Transaction.AmountPaidAtCheckIn > 0)
                {
                    item.Transaction.IsPaid = false;
                    item.Transaction.InvoiceStatus = InvoiceStatus.Issued;
                    item.PaymentStatus = PaymentStatus.PartiallyPaid;
                }
                else
                {
                    item.Transaction.IsPaid = false;
                    item.PaymentStatus = PaymentStatus.Unpaid;
                }
                remainingPool -= apply;
            }
            await _db.SaveChangesAsync();
            WriteAudit("add_payment", "reservation", res.Id,
                $"{vm.PaymentMethod?.ToLower() ?? "payment"} {paid:0.0}");
            await _db.SaveChangesAsync();
            TempData["Success"] = change.HasValue && change.Value > 0
                ? $"Payment recorded (₱{paid:N2}). Change ₱{change.Value:N2}."
                : $"Payment of ₱{paid:N2} recorded against outstanding balance.";
            return RedirectToAction("Details", new { id = res.Id });
        }

        var discountType = res.Guest.IsSeniorCitizen ? DiscountType.SeniorCitizen
            : res.Guest.IsPwd ? DiscountType.PWD : DiscountType.None;
        var discountRatePercent = FrontDeskController.GetDiscountRatePercent(discountType);

        // Advance payment (pre check-in) — allocate actual amount paid across rooms.
        // Never overwrite partial payment with the full invoice amount.
        var advancePool = paid;
        foreach (var item in unpaid.OrderBy(r => r.Id))
        {
            var (baseRoomCharge, ratePerNight, numberOfNights, durationHours) = FrontDeskController.ComputeBaseRoomCharge(item);
            var breakdown = _billingSvc.ComputeBreakdown(
                baseRoomCharge,
                discountRatePercent,
                extraPersons: item.ExtraPersons,
                extraBeds: item.ExtraBeds);
            var itemDue = breakdown.RoomChargesTotal;
            var apply = Math.Min(itemDue, advancePool);
            // Last unpaid room absorbs rounding remainder only if fully covering group.
            if (item == unpaid.OrderBy(r => r.Id).Last() && advancePool > apply && advancePool <= itemDue + 0.01m)
                apply = advancePool;

            var fullyPaid = apply >= itemDue - 0.009m;
            var transaction = new Transaction
            {
                ReservationId = item.Id,
                ActualCheckIn = item.ExpectedCheckIn ?? DateTime.Now,
                RatePerNight = ratePerNight,
                NumberOfNights = numberOfNights,
                DurationHours = durationHours,
                Subtotal = breakdown.BaseRoomCharge,
                DiscountType = discountType,
                DiscountRate = breakdown.DiscountRate,
                DiscountAmount = breakdown.DiscountAmount,
                ExtensionCharge = 0,
                AdditionalCharges = 0,
                TotalAmount = itemDue,
                FinalAmount = itemDue,
                PaymentMethod = vm.PaymentMethod,
                PaymentReference = vm.PaymentReference,
                AmountTendered = item == unpaid.OrderBy(r => r.Id).First() ? paid : apply,
                ChangeAmount = item == unpaid.OrderBy(r => r.Id).First() ? change : null,
                IsPaid = fullyPaid,
                AmountPaidAtCheckIn = apply, // actual money received for this room
                InvoiceStatus = fullyPaid ? InvoiceStatus.Paid : (apply > 0 ? InvoiceStatus.Issued : InvoiceStatus.Draft),
                CheckedInByUserId = null
            };
            _db.Transactions.Add(transaction);

            item.PaymentStatus = fullyPaid
                ? PaymentStatus.Paid
                : (apply > 0 ? PaymentStatus.PartiallyPaid : PaymentStatus.Unpaid);
            item.IsPaymentVerified = apply > 0;
            if (item.Status == ReservationStatus.Pending && apply > 0)
                item.Status = ReservationStatus.Confirmed;

            advancePool = Math.Max(0m, advancePool - apply);
        }

        foreach (var item in unpaid)
        {
            if (item.Room != null && item.Room.Status == RoomStatus.Available)
            {
                var oldStatus = item.Room.Status;
                item.Room.Status = RoomStatus.Reserved;
                _db.AuditLogs.Add(new AuditLog
                {
                    Action = "update_room_status",
                    EntityType = "Room",
                    EntityId = item.Room.Id,
                    UserId = userId > 0 ? userId : null,
                    UserName = HttpContext.Session.GetString("UserFullName"),
                    Details = $"{oldStatus} → Reserved | Reserved for reservation {item.ReferenceNumber}",
                    CreatedAt = DateTime.UtcNow
                });
            }
        }

        await _db.SaveChangesAsync();
        var anyPartial = unpaid.Any(r => r.PaymentStatus == PaymentStatus.PartiallyPaid);
        if (anyPartial)
            TempData["Success"] = $"Partial payment of ₱{paid:N2} recorded. Remaining balance is due at Check-In.";
        else if (unpaid.Count > 1)
            TempData["Success"] = $"Group payment recorded for {unpaid.Count} rooms. Guest will not be asked to pay again at Check-In.";
        else
            TempData["Success"] = "Advance payment recorded. The guest will not be asked to pay again at Check-In.";
        return RedirectToAction("Details", new { id = res.Id });
    }

    private static bool CanPay(Reservation res, out string? error)
    {
        error = null;
        // Walk-in initial payment is on Walk-In screen; once in-house, folio Record Payment
        // (extension / remaining balance) and Check-Out payment are both allowed.
        if (res.Type == ReservationType.WalkIn
            && res.Status != ReservationStatus.CheckedIn)
        {
            error = "Walk-in reservations are paid via the Walk-In payment screen.";
            return false;
        }
        // CheckedIn (incl. walk-in extension top-up), advance / partial group balance
        if (res.Status == ReservationStatus.CheckedIn
            || res.Status == ReservationStatus.Pending
            || res.Status == ReservationStatus.Confirmed
            || res.Status == ReservationStatus.Reserved)
        {
            return true;
        }
        error = $"Payment cannot be collected for a reservation with status '{res.Status}'.";
        return false;
    }

    private decimal ComputeTotalDue(Reservation res)
    {
        var (baseRoomCharge, _, _, _) = FrontDeskController.ComputeBaseRoomCharge(res);
        var discountType = res.Guest.IsSeniorCitizen ? DiscountType.SeniorCitizen
            : res.Guest.IsPwd ? DiscountType.PWD : DiscountType.None;
        var discountRatePercent = FrontDeskController.GetDiscountRatePercent(discountType);
        var breakdown = _billingSvc.ComputeBreakdown(
            baseRoomCharge,
            discountRatePercent,
            extraPersons: res.ExtraPersons,
            extraBeds: res.ExtraBeds);
        return breakdown.TotalDue;
    }

    // ── Create Reservation (Normal or Advance — guest not at the desk) ──
    [HttpGet]
    public async Task<IActionResult> Create()
    {
        var vm = new CreateReservationViewModel
        {
            // Default check-in to today (no advance-booking minimum)
            CheckInDate = DateTime.Today
        };
        await PopulateCreateOptionsAsync(vm);
        return View(vm);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(CreateReservationViewModel vm)
    {
        vm.GuestFullName = vm.GuestFullName?.Trim() ?? string.Empty;
        vm.GuestContactNumber = vm.GuestContactNumber?.Trim() ?? string.Empty;
        vm.GuestNationality = string.IsNullOrWhiteSpace(vm.GuestNationality) ? "Filipino" : vm.GuestNationality.Trim();
        vm.GuestEmail = string.IsNullOrWhiteSpace(vm.GuestEmail) ? null : vm.GuestEmail.Trim();
        // Government ID is collected at check-in only — never block booking save.
        vm.GuestIdType = vm.GuestIdType?.Trim() ?? string.Empty;
        vm.GuestIdNumber = vm.GuestIdNumber?.Trim() ?? string.Empty;
        ModelState.Remove(nameof(vm.GuestIdType));
        ModelState.Remove(nameof(vm.GuestIdNumber));
        // Guest count is no longer collected on New Reservation; keep the legacy database field at 1.
        // GuestCount rolled up from per-room adults/children after selection parse.

        // Staff Reservation Type: Phone or Walk-In only.
        // Online is created via OnlineReservation module.
        if (vm.BookingSource == ReservationType.Online || vm.BookingSource == ReservationType.TravelAgency || vm.BookingSource == ReservationType.FrontDesk)
            vm.BookingSource = ReservationType.Phone;
        // Allow Phone and WalkIn as chosen by staff.

        var isNightly = vm.StayType == StayType.Nightly;
        // Clamp nights so Range validation + availability never receive 0.
        // Nights come from the UI (check-out date − check-in date); same-day is invalid.
        if (isNightly)
            vm.NumberOfNights = Math.Max(1, Math.Min(30, vm.NumberOfNights));
        var checkIn = vm.CheckInDate.Date;
        // Nightly: departure date is check-in + nights; ExpectedCheckOut uses standard 12:00 checkout time.
        // Hourly: check-in + duration hours.
        var checkOutDate = isNightly ? checkIn.AddDays(vm.NumberOfNights) : checkIn;
        var checkOut = isNightly
            ? checkOutDate.Add(Reservation.NightlyCheckoutTime)
            : checkIn.AddHours(vm.DurationHours is 3 or 12 ? vm.DurationHours : 3);

        // Check-in cannot be in the past.
        var today = DateTime.Today;
        if (checkIn < today)
        {
            ModelState.AddModelError(nameof(vm.CheckInDate),
                "Check-in date cannot be in the past.");
        }

        if (isNightly && vm.NumberOfNights < 1)
        {
            ModelState.AddModelError(nameof(vm.NumberOfNights), "Number of nights must be at least 1.");
        }
        if (!isNightly && vm.DurationHours is not (3 or 12))
        {
            ModelState.AddModelError(nameof(vm.DurationHours), "Duration must be 3 or 12 hours (use Overnight for full-day stays).");
        }

        // Multi-room selection (same pattern as Walk-In).
        var selectedList = vm.SelectedRooms.ToList();
        if (!selectedList.Any() && vm.RoomId is > 0)
        {
            selectedList.Add(new CreateRoomSelection { RoomId = vm.RoomId.Value });
        }
        if (!selectedList.Any())
        {
            ModelState.AddModelError("", "Please select at least one room number.");
        }
        if (selectedList.Count > 5)
        {
            ModelState.AddModelError("", "Maximum of 5 rooms per reservation.");
        }
        if (selectedList.Count > 0 && selectedList.Select(s => s.RoomId).Distinct().Count() != selectedList.Count)
        {
            ModelState.AddModelError("", "Duplicate rooms in selection.");
        }

        // Roll up occupancy from each selected room card
        if (selectedList.Any())
        {
            vm.Adults = Math.Max(1, selectedList.Sum(s => s.Adults > 0 ? s.Adults : 1));
            vm.Children = Math.Max(0, selectedList.Sum(s => s.Children));
            vm.GuestCount = Math.Max(1, vm.Adults + vm.Children);
        }
        else
        {
            vm.GuestCount = Math.Max(1, vm.Adults + vm.Children);
        }

        var roomsById = new Dictionary<int, Room>();
        foreach (var sel in selectedList)
        {
            var room = await _db.Rooms.Include(r => r.RoomType).FirstOrDefaultAsync(r => r.Id == sel.RoomId);
            if (room?.RoomType == null)
            {
                ModelState.AddModelError("", "One of the selected rooms is invalid.");
                break;
            }
            // Final server-side conflict check: an active reservation that
            // overlaps the requested stay makes this room unavailable. This
            // prevents a booking even if the browser displayed stale room data.
            if (!_reservationSvc.IsRoomAvailable(room.Id, checkIn, checkOut))
            {
                ModelState.AddModelError("", $"Room {room.RoomNumber} is not available for those dates because it has an existing reservation that overlaps the selected stay.");
                break;
            }
            roomsById[sel.RoomId] = room;
            if (string.IsNullOrWhiteSpace(sel.RoomNumber)) sel.RoomNumber = room.RoomNumber;
            if (string.IsNullOrWhiteSpace(sel.RoomTypeName)) sel.RoomTypeName = room.RoomType.Name;
        }

        var roomsRequested = Math.Max(1, selectedList.Count);
        RoomType? roomType = roomsById.Values.FirstOrDefault()?.RoomType;

        if (!ModelState.IsValid)
        {
            await PopulateCreateOptionsAsync(vm);
            return View(vm);
        }

        // ── Guest upsert ─────────────────────────────────────────────────
        var existingGuest = await _db.Guests
            .FirstOrDefaultAsync(g => g.ContactNumber == vm.GuestContactNumber
                && g.FullName.ToLower() == vm.GuestFullName.ToLower());

        var guest = existingGuest;
        if (guest != null)
        {
            guest.Nationality = vm.GuestNationality;
            guest.Email = vm.GuestEmail;
            guest.IdType = vm.GuestIdType;
            guest.IdNumber = vm.GuestIdNumber;
            // Senior/PWD discount is applied only at check-in (Front Desk), not at booking.
            guest.NumberOfGuests = vm.GuestCount;
            if (guest.IsArchived) { guest.IsArchived = false; guest.ArchivedAt = null; }
        }
        else
        {
            guest = new Guest
            {
                FullName = vm.GuestFullName,
                ContactNumber = vm.GuestContactNumber,
                Email = vm.GuestEmail,
                Nationality = vm.GuestNationality,
                IdType = vm.GuestIdType,
                IdNumber = vm.GuestIdNumber,
                IsSeniorCitizen = false,
                IsPwd = false,
                NumberOfGuests = vm.GuestCount,
                CreatedAt = DateTime.UtcNow
            };
            _db.Guests.Add(guest);
        }

        await _db.SaveChangesAsync(); // flush guest FK

        var userId = HttpContext.Session.GetInt32("UserId");
        var refGroup = _reservationSvc.GenerateReferenceNumber();

        // One reservation per selected physical room (Walk-In style).
        // Serializable transaction + final availability check prevents two concurrent
        // bookings from claiming the same physical room for overlapping dates.
        int? firstReservationId = null;
        using (var dbTx = await _db.Database.BeginTransactionAsync(System.Data.IsolationLevel.Serializable))
        {
            try
            {
                foreach (var sel in selectedList)
                {
                    if (!_reservationSvc.IsRoomAvailable(sel.RoomId, checkIn, checkOut))
                    {
                        var rn = roomsById.TryGetValue(sel.RoomId, out var r) ? r.RoomNumber : sel.RoomId.ToString();
                        await dbTx.RollbackAsync();
                        ModelState.AddModelError("", $"Room {rn} is no longer available for those dates. Please select another room.");
                        await PopulateCreateOptionsAsync(vm);
                        return View(vm);
                    }
                }

                for (var i = 0; i < selectedList.Count; i++)
                {
                    var sel = selectedList[i];
                    var room = roomsById[sel.RoomId];
                    var rt = room.RoomType!;
                    var roomGuests = Math.Max(1, (sel.Adults > 0 ? sel.Adults : 1) + Math.Max(0, sel.Children));
                    var reservation = new Reservation
                    {
                        ReferenceNumber = selectedList.Count == 1
                            ? refGroup
                            : $"{refGroup}-{(i + 1)}",
                        GuestId = guest.Id,
                        Guest = guest,
                        RoomId = room.Id,
                        PreferredRoomTypeId = rt.Id,
                        PreferredRoomType = rt,
                        StayType = vm.StayType,
                        GuestCount = roomGuests,
                        Adults = Math.Max(1, sel.Adults > 0 ? sel.Adults : 1),
                        Children = Math.Max(0, sel.Children),
                        ChildrenAges = string.IsNullOrWhiteSpace(sel.ChildrenAges) ? null : sel.ChildrenAges.Trim(),
                        DurationHours = isNightly ? 24 : vm.DurationHours,
                        NumberOfNights = isNightly ? vm.NumberOfNights : 1,
                        RoomsRequested = 1,
                        CheckInDate = checkIn,
                        CheckOutDate = checkOutDate,
                        ExpectedCheckIn = ParseExpectedArrival(checkIn, vm.ExpectedCheckInTime),
                        ExpectedCheckOut = checkOut,
                        SpecialRequests = i == 0 ? vm.SpecialRequests : $"Part of multi-room group {refGroup}",
                        Type = vm.BookingSource,
                        Status = ReservationStatus.Confirmed,
                        PaymentStatus = PaymentStatus.Unpaid,
                        IsPaymentVerified = false,
                        CreatedByUserId = userId
                    };

                    // Booking only — check-in is always done from Front Desk after arrival.
                    reservation.Status = ReservationStatus.Confirmed;
                    room.Status = RoomStatus.Reserved;

                    _db.Reservations.Add(reservation);
                    await _db.SaveChangesAsync();
                    firstReservationId ??= reservation.Id;
                }

                await dbTx.CommitAsync();
            }
            catch
            {
                await dbTx.RollbackAsync();
                throw;
            }
        }

        // ── Optional downpayment / full payment at booking time ──────────
        var payMode = (vm.PayMode ?? "50").Trim();
        var created = await _db.Reservations
            .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
            .Include(r => r.Guest)
            .Where(r => r.ReferenceNumber == refGroup
                     || r.ReferenceNumber.StartsWith(refGroup + "-"))
            .ToListAsync();

        decimal groupRoomCharges = 0m;
        foreach (var item in created)
        {
            var (baseCharge, _, _, _) = FrontDeskController.ComputeBaseRoomCharge(item);
            groupRoomCharges += baseCharge;
        }
        if (groupRoomCharges <= 0 && created.Count > 0)
        {
            // Prevent zero-price bookings (usually means RoomType rates are missing/zero
            // or PreferredRoomType / Room.RoomType was not loaded).
            ModelState.AddModelError("", "Room rate is ₱0.00. Please set Base Rate / duration rates under Room Type Management, then try again.");
            await PopulateCreateOptionsAsync(vm);
            return View(vm);
        }
        // No Senior/PWD discount at booking — applied only at check-in (Front Desk).

        decimal amountNow = 0m;
        if (payMode == "100") amountNow = groupRoomCharges;
        else if (payMode == "50") amountNow = Math.Round(groupRoomCharges * 0.5m, 2);
        else if (payMode == "custom") amountNow = Math.Max(0m, vm.CustomDownpayment ?? 0m);
        // "0" = pay at check-in → amountNow stays 0

        if (amountNow > 0 && created.Count > 0)
        {
            var method = string.IsNullOrWhiteSpace(vm.PaymentMethod) ? "Cash" : vm.PaymentMethod.Trim();
            var remainingToAllocate = amountNow;
            for (var i = 0; i < created.Count; i++)
            {
                var item = created[i];
                var (baseCharge, ratePerNight, numberOfNights, durationHours) =
                    FrontDeskController.ComputeBaseRoomCharge(item);
                var itemDue = baseCharge;
                // Last room gets remainder so totals match exactly
                var payThis = i == created.Count - 1
                    ? remainingToAllocate
                    : Math.Min(remainingToAllocate, itemDue);
                remainingToAllocate = Math.Max(0m, remainingToAllocate - payThis);

                var tx = new Transaction
                {
                    ReservationId = item.Id,
                    ActualCheckIn = item.ExpectedCheckIn ?? DateTime.Now,
                    RatePerNight = ratePerNight,
                    NumberOfNights = numberOfNights,
                    DurationHours = durationHours,
                    Subtotal = baseCharge,
                    DiscountType = DiscountType.None,
                    DiscountRate = 0m,
                    DiscountAmount = 0m,
                    ExtensionCharge = 0,
                    AdditionalCharges = 0,
                    TotalAmount = itemDue,
                    FinalAmount = itemDue,
                    PaymentMethod = method,
                    PaymentReference = vm.PaymentReference,
                    AmountTendered = i == 0 ? amountNow : payThis,
                    IsPaid = payThis >= itemDue - 0.009m,
                    AmountPaidAtCheckIn = payThis,
                    // InvoiceStatus enum is Draft | Issued | Paid (no Unpaid)
                    InvoiceStatus = payThis >= itemDue - 0.009m ? InvoiceStatus.Paid : InvoiceStatus.Issued,
                    CheckedInByUserId = null
                };
                _db.Transactions.Add(tx);
                item.PaymentStatus = payThis >= itemDue - 0.009m
                    ? PaymentStatus.Paid
                    : (payThis > 0 ? PaymentStatus.PartiallyPaid : PaymentStatus.Unpaid);
                item.IsPaymentVerified = payThis > 0;
            }
            await _db.SaveChangesAsync();
        }

        var roomLabel = string.Join(", ", selectedList.Select(s => s.RoomNumber));
        // Audit: create_reservation
        WriteAudit("create_reservation", "reservation", firstReservationId,
            $"{refGroup} rooms=[{string.Join(",", selectedList.Select(s => $"'{s.RoomNumber}'"))}] payMode={payMode} paid={amountNow:N2}");
        await _db.SaveChangesAsync();

        // Staff notification so booking appears on dashboard / bell
        _db.Notifications.Add(new Notification
        {
            Type = "NewOnlineReservation",
            Message = $"New reservation {refGroup} — {guest.FullName}"
                      + (selectedList.Count > 1 ? $", {selectedList.Count} rooms" : "")
                      + (amountNow > 0 ? $", paid ₱{amountNow:N2}" : ""),
            Link = firstReservationId.HasValue ? $"/Reservation/Details/{firstReservationId}" : "/Reservation/Manage",
            ReservationId = firstReservationId,
            CreatedAt = DateTime.UtcNow
        });
        await _db.SaveChangesAsync();

        TempData["Success"] = selectedList.Count == 1
            ? (amountNow > 0
                ? $"Reservation {refGroup} saved. Room {roomLabel}. Down payment ₱{amountNow:N2} recorded."
                : $"Reservation {refGroup} reserved. Room {roomLabel}.")
            : (amountNow > 0
                ? $"{selectedList.Count} reservations saved for {refGroup}. Rooms: {roomLabel}. Down payment ₱{amountNow:N2} recorded."
                : $"{selectedList.Count} reservations reserved for {refGroup}. Rooms: {roomLabel}.");
        return RedirectToAction("Manage");
    }

    private async Task PopulateCreateOptionsAsync(CreateReservationViewModel vm)
    {
        var isNightly = vm.StayType == StayType.Nightly;
        var nights = isNightly ? Math.Max(1, vm.NumberOfNights) : 1;
        var dur = vm.DurationHours is 3 or 12 ? vm.DurationHours : 3;
        // Availability is date-aware: a room is unavailable when an active
        // reservation overlaps the requested stay window.
        // Nightly ends at the standard checkout time on the departure date.
        var checkInOpt = vm.CheckInDate.Date;
        var checkOutOpt = isNightly
            ? checkInOpt.AddDays(nights).Add(Reservation.NightlyCheckoutTime)
            : checkInOpt.AddHours(dur);
        var selectableRooms = await _reservationSvc.GetAvailableRoomsAsync(checkInOpt, checkOutOpt);
        // Only rooms returned by the central availability rule are offered.
        // Reserved / Occupied / For Cleaning / Maintenance rooms are NOT shown at
        // all (the backend still re-validates on Save as a second safety layer).
        var allRooms = selectableRooms;

        vm.AvailableRooms = selectableRooms.Select(r => new SelectListItem(
            $"Room {r.RoomNumber} — {r.RoomType?.Name ?? "Unknown"} (₱{r.RoomType?.BaseRate ?? 0:N0}/night)",
            r.Id.ToString())).ToList();

        vm.AvailableRoomCards = allRooms.Select(r =>
        {
            var rt = r.RoomType;
            var amenities = rt?.RoomTypeAmenities?
                .Select(rta => rta.Amenity?.Name ?? "")
                .Where(a => !string.IsNullOrWhiteSpace(a))
                .ToList() ?? new List<string>();

            return new AvailableRoomCardOption
            {
                Id = r.Id,
                RoomNumber = r.RoomNumber,
                RoomTypeId = r.RoomTypeId,
                RoomTypeName = rt?.Name ?? "Unknown",
                Description = r.Description ?? "",
                Rate3Hours = rt?.GetRateForDuration(3) ?? 0,
                Rate12Hours = rt?.GetRateForDuration(12) ?? 0,
                Rate24Hours = rt?.GetRateForDuration(24) ?? 0,
                RateNightly = rt?.GetRateForDuration(24) ?? 0,
                StayRate = rt == null ? 0 : (isNightly ? rt.GetRateForDuration(24) * nights : rt.GetRateForDuration(dur)),
                DurationLabel = isNightly ? $"{nights} {(nights == 1 ? "Night" : "Nights")}" : $"{dur} Hours",
                MaxOccupancy = rt?.MaxOccupancy ?? 1,
                Amenities = string.Join(", ", amenities),
                Status = "Available",
                IsSelectable = true
            };
        }).ToList();

        vm.RoomRates = allRooms.Select(r => new RoomRateOption
        {
            RoomId = r.Id,
            Rate3Hours = r.RoomType?.GetRateForDuration(3) ?? 0,
            Rate12Hours = r.RoomType?.GetRateForDuration(12) ?? 0,
            Rate24Hours = r.RoomType?.GetRateForDuration(24) ?? 0,
            RateNightly = r.RoomType?.GetRateForDuration(24) ?? 0
        }).ToList();

        var roomTypes = await _db.RoomTypes.OrderBy(rt => rt.Name).ToListAsync();
        vm.RoomTypeOptions = roomTypes
            .Select(rt => new SelectListItem(rt.Name, rt.Id.ToString()))
            .ToList();
        vm.RoomTypeRatesJson = System.Text.Json.JsonSerializer.Serialize(
            roomTypes.Select(rt => new {
                id = rt.Id,
                name = rt.Name,
                rate3 = rt.GetRateForDuration(3),
                rate12 = rt.GetRateForDuration(12),
                rate24 = rt.GetRateForDuration(24),
                rateNightly = rt.GetRateForDuration(24)
            }));

        vm.NationalityOptions = FrontDeskController.GetNationalityOptions();
        vm.BookingSourceOptions = new List<SelectListItem>(); // unused — source fixed to Front Desk
    }

    [HttpGet]
    public async Task<IActionResult> GetAvailableRoomsJson(DateTime checkIn, DateTime? checkOut, string? stayType, int? durationHours, int? numberOfNights)
    {
        var isNightly = string.Equals(stayType, "Nightly", StringComparison.OrdinalIgnoreCase);
        var dur = durationHours is 3 or 12 ? durationHours.Value : 3;
        var cin = checkIn.Date;
        int nights;
        DateTime cout;
        if (isNightly)
        {
            // Prefer explicit check-out date; nights = checkout date − check-in date.
            if (checkOut.HasValue && checkOut.Value.Date > cin)
            {
                nights = Math.Clamp((checkOut.Value.Date - cin).Days, 1, 30);
                cout = checkOut.Value.Date.Add(Reservation.NightlyCheckoutTime);
            }
            else
            {
                nights = Math.Max(1, numberOfNights ?? 1);
                cout = cin.AddDays(nights).Add(Reservation.NightlyCheckoutTime);
            }
        }
        else
        {
            nights = 1;
            cout = cin.AddHours(dur);
        }
        if (cout <= cin) cout = cin.AddDays(1).Add(Reservation.NightlyCheckoutTime);

        var selectableRooms = await _reservationSvc.GetAvailableRoomsAsync(cin, cout);

        var list = selectableRooms.Select(r =>
        {
            var rt = r.RoomType;
            return new
            {
                id = r.Id,
                roomNumber = r.RoomNumber,
                roomTypeId = r.RoomTypeId,
                roomTypeName = rt?.Name ?? "Unknown",
                description = r.Description ?? "",
                maxOccupancy = rt?.MaxOccupancy ?? 1,
                rate3Hours = rt?.GetRateForDuration(3) ?? 0,
                rate12Hours = rt?.GetRateForDuration(12) ?? 0,
                rateNightly = rt?.GetRateForDuration(24) ?? 0,
                stayRate = rt == null ? 0 : (isNightly ? rt.GetRateForDuration(24) * nights : rt.GetRateForDuration(dur)),
                durationLabel = isNightly ? $"{nights} {(nights == 1 ? "Night" : "Nights")}" : $"{dur} Hours"
            };
        }).ToList();

        return Json(list);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Cancel(int id, string? reason)
    {
        var res = await _db.Reservations
            .Include(r => r.Room)
            .Include(r => r.Guest)
            .FirstOrDefaultAsync(r => r.Id == id);
        if (res == null) return NotFound();

        // Only pre-arrival bookings can be cancelled here.
        var cancellable = new[] { ReservationStatus.Pending, ReservationStatus.Confirmed, ReservationStatus.Reserved };
        if (!cancellable.Contains(res.Status))
        {
            TempData["Error"] = $"A reservation with status '{res.Status}' cannot be cancelled.";
            return RedirectToAction("Details", new { id });
        }

        // Cancel whole booking group so multi-room refs stay consistent.
        var siblings = await GetGroupSiblingsAsync(res);
        var toCancel = siblings.Where(s => cancellable.Contains(s.Status)).ToList();
        var cancelReason = string.IsNullOrWhiteSpace(reason) ? "Cancelled by staff" : reason.Trim();
        foreach (var item in toCancel)
        {
            item.Status = ReservationStatus.Cancelled;
            item.CancellationReason = cancelReason;
            if (item.Room != null && item.Room.Status != RoomStatus.Occupied)
                item.Room.Status = RoomStatus.Available;
        }

        var guestName = res.Guest?.FullName ?? "Guest";
        var displayRef = GroupBaseRef(res.ReferenceNumber);
        if (string.IsNullOrEmpty(displayRef)) displayRef = res.ReferenceNumber;

        // Bell notification so staff can detect the cancellation.
        _db.Notifications.Add(new Notification
        {
            Type = "ReservationCancelled",
            Message = $"Reservation cancelled — {guestName} (Ref {displayRef})"
                      + (toCancel.Count > 1 ? $", {toCancel.Count} rooms" : ""),
            Link = $"/Reservation/Details/{res.Id}",
            ReservationId = res.Id,
            CreatedAt = DateTime.UtcNow
        });

        WriteAudit("cancel_reservation", "reservation", res.Id,
            $"Ref {displayRef}; reason: {cancelReason}; rooms: {toCancel.Count}");

        await _db.SaveChangesAsync();
        TempData["Success"] = toCancel.Count > 1
            ? $"Reservation group cancelled ({toCancel.Count} rooms). Open the CANCELLED card to view."
            : "Reservation cancelled. Open the CANCELLED card to view it.";
        // Show cancelled list so the cancellation is immediately visible.
        return RedirectToAction("Manage", new { status = "Cancelled" });
    }

    // ── Reschedule (change dates for Pending / Confirmed / Reserved) ───
    [HttpGet]
    public async Task<IActionResult> Reschedule(int id)
    {
        var res = await _db.Reservations
            .Include(r => r.Guest)
            .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
            .Include(r => r.PreferredRoomType)
            .FirstOrDefaultAsync(r => r.Id == id);
        if (res == null) return NotFound();

        var allowed = new[] { ReservationStatus.Pending, ReservationStatus.Confirmed, ReservationStatus.Reserved };
        if (!allowed.Contains(res.Status))
        {
            TempData["Error"] = $"Cannot reschedule a reservation with status '{res.Status}'.";
            return RedirectToAction("Details", new { id });
        }

        var cin = res.ExpectedCheckIn ?? res.CheckInDate ?? DateTime.Today;
        var cout = res.ExpectedCheckOut
                   ?? (res.CheckOutDate.HasValue
                       ? (res.IsNightlyStay ? res.CheckOutDate.Value.Date.Add(Reservation.NightlyCheckoutTime) : res.CheckOutDate.Value)
                       : (res.IsNightlyStay
                           ? cin.Date.AddDays(Math.Max(1, res.NumberOfNights)).Add(Reservation.NightlyCheckoutTime)
                           : cin.AddHours(Math.Max(1, res.DurationHours))));

        var roomLabel = res.Room != null
            ? $"Room {res.Room.RoomNumber} — {res.Room.RoomType?.Name ?? "Room"}"
            : (res.PreferredRoomType?.Name ?? "Room TBA");

        var vm = new RescheduleReservationViewModel
        {
            ReservationId = res.Id,
            ReferenceNumber = res.ReferenceNumber,
            GuestName = res.Guest?.FullName ?? "—",
            RoomInfo = roomLabel,
            CurrentStaySummary = $"{cin:yyyy-MM-dd HH:mm} → {cout:yyyy-MM-dd HH:mm}"
                + (res.IsNightlyStay ? $" ({Math.Max(1, res.NumberOfNights)} night(s))" : $" ({res.DurationHours} hr)"),
            IsNightly = res.IsNightlyStay,
            DurationHours = res.DurationHours > 0 ? res.DurationHours : 24,
            NewCheckIn = cin,
            NewCheckOut = cout
        };
        return View(vm);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Reschedule(RescheduleReservationViewModel vm)
    {
        var res = await _db.Reservations
            .Include(r => r.Guest)
            .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
            .Include(r => r.PreferredRoomType)
            .FirstOrDefaultAsync(r => r.Id == vm.ReservationId);
        if (res == null) return NotFound();

        var allowed = new[] { ReservationStatus.Pending, ReservationStatus.Confirmed, ReservationStatus.Reserved };
        if (!allowed.Contains(res.Status))
        {
            TempData["Error"] = $"Cannot reschedule a reservation with status '{res.Status}'.";
            return RedirectToAction("Details", new { id = vm.ReservationId });
        }

        if (vm.NewCheckOut <= vm.NewCheckIn)
            ModelState.AddModelError(nameof(vm.NewCheckOut), "Check-out must be after check-in.");

        if (!ModelState.IsValid)
        {
            vm.ReferenceNumber = res.ReferenceNumber;
            vm.GuestName = res.Guest?.FullName ?? "—";
            vm.RoomInfo = res.Room != null ? $"Room {res.Room.RoomNumber}" : (res.PreferredRoomType?.Name ?? "Room TBA");
            return View(vm);
        }

        var siblings = await GetGroupSiblingsAsync(res);
        var toMove = siblings.Where(s => allowed.Contains(s.Status)).ToList();
        if (toMove.Count == 0) toMove.Add(res);
        var excludeIds = toMove.Select(s => s.Id).ToHashSet();

        foreach (var item in toMove)
        {
            if (item.RoomId == null) continue;
            var conflict = await _db.Reservations.AnyAsync(r =>
                r.RoomId == item.RoomId
                && !excludeIds.Contains(r.Id)
                && r.Status != ReservationStatus.Cancelled
                && r.Status != ReservationStatus.CheckedOut
                && r.Status != ReservationStatus.Completed
                && r.Status != ReservationStatus.NoShow
                && ((r.CheckInDate.HasValue && r.CheckOutDate.HasValue
                     && r.CheckInDate.Value < vm.NewCheckOut && r.CheckOutDate.Value > vm.NewCheckIn)
                    || (r.ExpectedCheckIn.HasValue && r.ExpectedCheckOut.HasValue
                        && r.ExpectedCheckIn.Value < vm.NewCheckOut && r.ExpectedCheckOut.Value > vm.NewCheckIn)));
            if (conflict)
            {
                ModelState.AddModelError("", $"Room {item.Room?.RoomNumber} is not available for the new dates.");
                vm.ReferenceNumber = res.ReferenceNumber;
                vm.GuestName = res.Guest?.FullName ?? "—";
                vm.RoomInfo = res.Room != null ? $"Room {res.Room.RoomNumber}" : "Room TBA";
                return View(vm);
            }
        }

        // Type-only bookings (RoomId == null, PreferredRoomTypeId set) hold a room
        // TYPE, not a physical room, so the new dates must still have enough free
        // rooms of that type. The reservations being moved do not count against
        // themselves (they are excluded from the capacity count).
        foreach (var typeGroup in toMove
                     .Where(i => i.RoomId == null && i.PreferredRoomTypeId != null)
                     .GroupBy(i => i.PreferredRoomTypeId!.Value))
        {
            var capacity = await _reservationSvc.GetAvailableCapacityForRoomTypeAsync(
                typeGroup.Key, vm.NewCheckIn, vm.NewCheckOut, excludeIds);
            if (capacity < typeGroup.Count())
            {
                var typeName = typeGroup.First().PreferredRoomType?.Name ?? "selected room type";
                ModelState.AddModelError("", capacity <= 0
                    ? $"No {typeName} rooms are available for the new dates."
                    : $"Only {capacity} {typeName} room(s) are available for the new dates, but {typeGroup.Count()} are needed.");
                vm.ReferenceNumber = res.ReferenceNumber;
                vm.GuestName = res.Guest?.FullName ?? "—";
                vm.RoomInfo = res.Room != null ? $"Room {res.Room.RoomNumber}" : (res.PreferredRoomType?.Name ?? "Room TBA");
                return View(vm);
            }
        }

        var oldSummary = $"{(res.ExpectedCheckIn ?? res.CheckInDate):yyyy-MM-dd} → {(res.ExpectedCheckOut ?? res.CheckOutDate):yyyy-MM-dd}";
        var nights = Math.Max(1, (int)Math.Ceiling((vm.NewCheckOut.Date - vm.NewCheckIn.Date).TotalDays));

        foreach (var item in toMove)
        {
            item.ExpectedCheckIn = vm.NewCheckIn;
            item.ExpectedCheckOut = vm.NewCheckOut;
            item.CheckInDate = vm.NewCheckIn.Date;
            item.CheckOutDate = vm.NewCheckOut.Date;
            if (item.IsNightlyStay)
                item.NumberOfNights = nights;
            else
                item.DurationHours = (int)Math.Max(1, Math.Round((vm.NewCheckOut - vm.NewCheckIn).TotalHours));
            if (!string.IsNullOrWhiteSpace(vm.Notes))
            {
                var noteLine = $"[Rescheduled {DateTime.Now:yyyy-MM-dd HH:mm}] {vm.Notes.Trim()}";
                item.SpecialRequests = string.IsNullOrWhiteSpace(item.SpecialRequests)
                    ? noteLine
                    : item.SpecialRequests + " | " + noteLine;
            }
        }

        var displayRef = GroupBaseRef(res.ReferenceNumber);
        if (string.IsNullOrEmpty(displayRef)) displayRef = res.ReferenceNumber;
        var guestName = res.Guest?.FullName ?? "Guest";

        _db.Notifications.Add(new Notification
        {
            Type = "ReservationRescheduled",
            Message = $"Rescheduled — {guestName} (Ref {displayRef}): {oldSummary} → {vm.NewCheckIn:yyyy-MM-dd} / {vm.NewCheckOut:yyyy-MM-dd}",
            Link = $"/Reservation/Details/{res.Id}",
            ReservationId = res.Id,
            CreatedAt = DateTime.UtcNow
        });
        WriteAudit("reschedule_reservation", "reservation", res.Id,
            $"Ref {displayRef}; {oldSummary} → {vm.NewCheckIn:yyyy-MM-dd HH:mm} / {vm.NewCheckOut:yyyy-MM-dd HH:mm}");

        await _db.SaveChangesAsync();
        TempData["Success"] = toMove.Count > 1
            ? $"Reservation group rescheduled ({toMove.Count} rooms)."
            : $"Reservation rescheduled to {vm.NewCheckIn:MMM dd, yyyy HH:mm} – {vm.NewCheckOut:MMM dd, yyyy HH:mm}.";
        return RedirectToAction("Details", new { id = res.Id });
    }

    // ── Pre-check-in Extra Hours (recorded on Confirmed reservations) ───
    [HttpGet]
    public async Task<IActionResult> ExtraHours(int id)    {
        var res = await _db.Reservations
            .Include(r => r.Guest)
            .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
            .FirstOrDefaultAsync(r => r.Id == id);
        if (res == null) return NotFound();

        if (res.Status != ReservationStatus.Confirmed)
        {
            TempData["Error"] = "Extra hours can only be added to Confirmed reservations.";
            return RedirectToAction("Details", new { id });
        }

        var extraHourRate = res.Room!.RoomType!.GetExtraHourRateForDuration(res.DurationHours);
        var vm = new ReservationExtraHoursViewModel
        {
            ReservationId = res.Id,
            Reservation = res,
            GuestName = res.Guest.FullName,
            RoomInfo = $"Room {res.Room.RoomNumber} — {res.Room.RoomType.Name}",
            ActualCheckIn = res.ActualCheckIn,
            DurationHours = res.DurationHours > 0 ? res.DurationHours : 24,
            ExtraHourRate = extraHourRate,
            IsNightlyStay = res.IsNightlyStay,
            ExtraHours = res.ExtraHours > 0 ? res.ExtraHours : 0,
            ExtraHoursCharge = res.ExtraHoursCharge,
            Notes = res.ExtraHoursNotes
        };
        return View(vm);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> ExtraHours(ReservationExtraHoursViewModel vm)
    {
        var res = await _db.Reservations
            .Include(r => r.Guest)
            .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
            .FirstOrDefaultAsync(r => r.Id == vm.ReservationId);
        if (res == null) return NotFound();

        if (res.Status != ReservationStatus.Confirmed)
        {
            ModelState.AddModelError(string.Empty, "Extra hours can only be added to Confirmed reservations.");
        }

        var extraHourRate = res.Room!.RoomType!.GetExtraHourRateForDuration(res.DurationHours);
        vm.Reservation = res;
        vm.GuestName = res.Guest.FullName;
        vm.RoomInfo = $"Room {res.Room.RoomNumber} — {res.Room.RoomType.Name}";
        vm.ActualCheckIn = res.ActualCheckIn;
        vm.DurationHours = res.DurationHours > 0 ? res.DurationHours : 24;
        vm.ExtraHourRate = extraHourRate;
        vm.IsNightlyStay = res.IsNightlyStay;
        vm.ExtraHoursCharge = vm.ExtraHours * extraHourRate;

        if (extraHourRate <= 0)
        {
            ModelState.AddModelError(string.Empty, "This room type has no Extra Hour Rate configured. Please set one before recording extra hours.");
        }

        if (!ModelState.IsValid)
        {
            TempData["Error"] = "Please correct the highlighted fields.";
            return View(vm);
        }

        res.ExtraHours = vm.ExtraHours;
        res.ExtraHourRate = extraHourRate;
        res.ExtraHoursCharge = vm.ExtraHoursCharge;
        res.ExtraHoursNotes = vm.Notes;

        await _db.SaveChangesAsync();
        TempData["Success"] = $"Extra hours updated: {vm.ExtraHours} hour(s) at ₱{extraHourRate:N2}/hour = ₱{vm.ExtraHoursCharge:N2}.";
        return RedirectToAction("Details", new { id = res.Id });
    }

    // ── Edit Extra Hours for already-checked-in guests (updates Transaction) ─
    [HttpGet]
    public async Task<IActionResult> EditExtraHours(int id)
    {
        var res = await _db.Reservations
            .Include(r => r.Guest)
            .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
            .Include(r => r.Transaction)
            .FirstOrDefaultAsync(r => r.Id == id);
        if (res == null) return NotFound();

        if (res.Status != ReservationStatus.CheckedIn)
        {
            TempData["Error"] = "Edit Extra Hours is only available for guests who are currently checked in.";
            return RedirectToAction("Details", new { id });
        }

        var extraHourRate = res.Room!.RoomType!.GetExtraHourRateForDuration(res.DurationHours);
        var vm = new ReservationExtraHoursViewModel
        {
            ReservationId = res.Id,
            Reservation = res,
            GuestName = res.Guest.FullName,
            RoomInfo = $"Room {res.Room.RoomNumber} — {res.Room.RoomType.Name}",
            ActualCheckIn = res.ActualCheckIn,
            DurationHours = res.DurationHours > 0 ? res.DurationHours : 24,
            ExtraHourRate = extraHourRate,
            IsNightlyStay = res.IsNightlyStay,
            ExtraHours = 0,
            ExtraHoursCharge = 0,
            Notes = null
        };
        return View(vm);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> EditExtraHours(ReservationExtraHoursViewModel vm)
    {
        var res = await _db.Reservations
            .Include(r => r.Guest)
            .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
            .Include(r => r.Transaction)
            .FirstOrDefaultAsync(r => r.Id == vm.ReservationId);
        if (res == null) return NotFound();

        if (res.Status != ReservationStatus.CheckedIn || res.Transaction == null)
        {
            ModelState.AddModelError(string.Empty, "Edit Extra Hours is only available for guests who are currently checked in.");
        }

        var extraHourRate = res.Room!.RoomType!.GetExtraHourRateForDuration(res.DurationHours);
        vm.Reservation = res;
        vm.GuestName = res.Guest.FullName;
        vm.RoomInfo = $"Room {res.Room.RoomNumber} — {res.Room.RoomType.Name}";
        vm.ActualCheckIn = res.ActualCheckIn;
        vm.DurationHours = res.DurationHours > 0 ? res.DurationHours : 24;
        vm.ExtraHourRate = extraHourRate;
        vm.IsNightlyStay = res.IsNightlyStay;
        vm.ExtraHoursCharge = vm.ExtraHours * extraHourRate;

        if (extraHourRate <= 0)
        {
            ModelState.AddModelError(string.Empty, "This room type has no Extra Hour Rate configured.");
        }

        if (!ModelState.IsValid)
        {
            TempData["Error"] = "Please correct the highlighted fields.";
            return View(vm);
        }

        // Add to the live transaction's extra hours (accumulate, not replace)
        var tx = res.Transaction!;
        tx.ExtraHours += vm.ExtraHours;
        tx.ExtraHourRate = extraHourRate;
        tx.ExtraHoursCharge += vm.ExtraHoursCharge;

        // Recompute via the single source of truth so nothing (extension,
        // extras, extra hours) is ever counted twice.
        var breakdown = _billingSvc.ComputeBreakdown(
            tx.Subtotal,
            tx.DiscountRate,
            extensionCharge: tx.ExtensionCharge,
            extraPersons: res.ExtraPersons,
            extraBeds: res.ExtraBeds,
            extraHoursCharge: tx.ExtraHoursCharge,
            otherManualCharges: tx.AdditionalCharges);

        tx.DiscountAmount = breakdown.DiscountAmount;
        tx.TotalAmount = breakdown.RoomChargesTotal;
        tx.FinalAmount = breakdown.TotalDue;

        // Extra hours push the checkout date/time back accordingly, so Front Desk
        // due-out lists and the Dashboard reflect the guest's new checkout time.
        res.ExtraHours += vm.ExtraHours;
        res.ExpectedCheckOut = res.ExpectedCheckOut.HasValue ? res.ExpectedCheckOut.Value.AddHours(vm.ExtraHours) : res.ExpectedCheckOut;

        await _db.SaveChangesAsync();
        TempData["Success"] = $"Extra hours added: {vm.ExtraHours} hour(s) at ₱{extraHourRate:N2}/hour = +₱{vm.ExtraHoursCharge:N2}.";
        return RedirectToAction("Details", new { id = res.Id });
    }


    private static string GroupBaseRef(string? rn)
    {
        if (string.IsNullOrEmpty(rn)) return "";
        return System.Text.RegularExpressions.Regex.Replace(rn, @"-R?\d+$", "");
    }

    private async Task<List<Reservation>> GetGroupSiblingsAsync(Reservation res)
    {
        var baseRef = GroupBaseRef(res.ReferenceNumber);
        var siblings = await _db.Reservations
            .Include(r => r.Guest)
            .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
            .Include(r => r.PreferredRoomType)
            .Include(r => r.Transaction)
            .Where(r => r.ReferenceNumber == baseRef
                     || r.ReferenceNumber.StartsWith(baseRef + "-")
                     || (r.SpecialRequests != null && r.SpecialRequests.Contains(baseRef)))
            .OrderBy(r => r.ReferenceNumber)
            .ToListAsync();
        if (!siblings.Any(s => s.Id == res.Id))
            siblings.Insert(0, res);
        return siblings;
    }

    private void WriteAudit(string action, string entityType, int? entityId, string? details)
    {
        var uid = HttpContext.Session.GetInt32("UserId");
        _db.AuditLogs.Add(new AuditLog
        {
            Action = action,
            EntityType = entityType,
            EntityId = entityId,
            Details = details,
            UserId = uid,
            UserName = HttpContext.Session.GetString("UserFullName")
                       ?? HttpContext.Session.GetString("Username"),
            CreatedAt = DateTime.UtcNow
        });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> AddCharge(int id, string? chargeType, string? description, decimal amount)
    {
        var res = await _db.Reservations.FirstOrDefaultAsync(r => r.Id == id);
        if (res == null) return NotFound();
        if (amount <= 0)
        {
            TempData["Error"] = "Charge amount must be greater than zero.";
            return RedirectToAction(nameof(Details), new { id });
        }
        res.ExtraCharge += amount;
        WriteAudit("add_charge", "reservation", res.Id,
            $"{chargeType ?? "extra"} {amount:0.00} {description}".Trim());
        await _db.SaveChangesAsync();
        TempData["Success"] = $"Added charge ₱{amount:N2}.";
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> TransferRoom(int id, int fromRoomId, int toRoomId, string? reason)
    {
        var res = await _db.Reservations
            .Include(r => r.Room)
            .FirstOrDefaultAsync(r => r.Id == id);
        if (res == null) return NotFound();
        if (res.Status != ReservationStatus.CheckedIn)
        {
            TempData["Error"] = "Room transfer is only allowed for in-house guests.";
            return RedirectToAction(nameof(Details), new { id });
        }
        if (res.RoomId != fromRoomId)
        {
            TempData["Error"] = "From room does not match this reservation.";
            return RedirectToAction(nameof(Details), new { id });
        }
        if (fromRoomId == toRoomId)
        {
            TempData["Error"] = "Source and target room cannot be the same.";
            return RedirectToAction(nameof(Details), new { id });
        }
        var toRoom = await _db.Rooms.Include(r => r.RoomType).FirstOrDefaultAsync(r => r.Id == toRoomId);
        if (toRoom == null)
        {
            TempData["Error"] = "Target room not found.";
            return RedirectToAction(nameof(Details), new { id });
        }

        // Physical status alone is not enough: the target room must also have no
        // other active reservation overlapping this guest's remaining stay.
        var stayFrom = DateTime.Now;
        var stayTo = res.ExpectedCheckOut ?? res.CheckOutDate ?? stayFrom.AddDays(1);
        if (stayTo <= stayFrom) stayTo = stayFrom.AddHours(1);
        if (toRoom.Status == RoomStatus.Occupied
            || toRoom.Status == RoomStatus.ForCleaning
            || toRoom.Status == RoomStatus.Maintenance
            || !_reservationSvc.IsRoomAvailable(toRoom.Id, stayFrom, stayTo, res.Id))
        {
            TempData["Error"] = $"Room {toRoom.RoomNumber} is not available for the rest of this stay (it is occupied or reserved by another guest).";
            return RedirectToAction(nameof(Details), new { id });
        }
        var from = res.Room;
        if (from != null)
        {
            from.Status = RoomStatus.ForCleaning;
        }
        toRoom.Status = RoomStatus.Occupied;
        res.RoomId = toRoom.Id;
        WriteAudit("room_transfer", "reservation", res.Id,
            $"from={from?.RoomNumber} to={toRoom.RoomNumber} {reason}".Trim());
        await _db.SaveChangesAsync();
        TempData["Success"] = $"Transferred to Room {toRoom.RoomNumber}.";
        return RedirectToAction(nameof(Details), new { id });
    }

    /// <summary>
    /// Authenticated download of a payment proof stored outside wwwroot.
    /// Accepts either a private-proofs/filename or a legacy uploads/filename (for old records).
    /// </summary>
    [HttpGet]
    public IActionResult DownloadPaymentProof(string file)
    {
        if (string.IsNullOrWhiteSpace(file))
            return NotFound();

        // Prevent path traversal — only allow the leaf file name.
        var safeName = Path.GetFileName(file.Replace("\\", "/").Split('/').Last());
        if (string.IsNullOrWhiteSpace(safeName) || safeName.Contains(".."))
            return BadRequest();

        var privateDir = Path.Combine(Directory.GetCurrentDirectory(), "App_Data", "payment-proofs");
        var legacyDir = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");

        var candidates = new[]
        {
            Path.Combine(privateDir, safeName),
            Path.Combine(legacyDir, safeName)
        };

        foreach (var path in candidates)
        {
            if (System.IO.File.Exists(path))
            {
                var contentType = safeName.EndsWith(".png", StringComparison.OrdinalIgnoreCase) ? "image/png"
                    : safeName.EndsWith(".webp", StringComparison.OrdinalIgnoreCase) ? "image/webp"
                    : safeName.EndsWith(".gif", StringComparison.OrdinalIgnoreCase) ? "image/gif"
                    : "image/jpeg";
                return PhysicalFile(path, contentType, safeName);
            }
        }
        return NotFound();
    }

    /// <summary>
    /// Combines a date with an optional "HH:mm" arrival time string into ExpectedCheckIn.
    /// Defaults to 14:00 when the time is missing or invalid.
    /// </summary>
    private static DateTime ParseExpectedArrival(DateTime date, string? timeStr)
    {
        var baseDate = date.Date;
        if (string.IsNullOrWhiteSpace(timeStr)) return baseDate.AddHours(14);
        if (TimeSpan.TryParse(timeStr.Trim(), out var ts))
            return baseDate.Add(ts);
        return baseDate.AddHours(14);
    }
}
