using HotelEase.Data;
using HotelEase.Filters;
using HotelEase.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HotelEase.Controllers
{
    // Room type catalog management is Admin-only.
    [RequireRole(UserRole.Admin)]
    public class RoomTypeController : Controller
    {
        private readonly ApplicationDbContext _context;
        public RoomTypeController(ApplicationDbContext ctx) => _context = ctx;

        // Accepts real hotel room type names: letters, digits, spaces, and common
        // separators, but blocks empty input and obvious keyboard-mash strings.
        private static bool IsValidRoomTypeName(string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return false;
            name = name.Trim();

            // Allow letters, digits, spaces, and basic separators used in room names
            // (e.g. "Deluxe Twin", "Family Room", "Superior Suite", "Single - Double").
            if (!System.Text.RegularExpressions.Regex.IsMatch(name, @"^[A-Za-z0-9\s\-/&.]+$")) return false;

            var words = name.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            if (words.Length == 0) return false;

            // Reject long runs of consonants or digits that look like keyboard mashing
            // (e.g. "jdfgosdjgoisn", "123456"). Vowel check is removed because abbreviations
            // such as "ST" or "VIP" are valid.
            foreach (var w in words)
            {
                if (w.Length > 8 && System.Text.RegularExpressions.Regex.IsMatch(w, @"^[^aeiouAEIOU]+$"))
                    return false;
            }

            return true;
        }

        // Room Types are now managed from the merged Room Management page.
        public IActionResult Index() => RedirectToAction("Index", "Room");

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(RoomType roomType, string? RoomNumbers, string? Amenities)
        {
            roomType.Name = roomType.Name?.Trim() ?? string.Empty;
            if (!IsValidRoomTypeName(roomType.Name))
            {
                TempData["Error"] = "Room type name looks invalid. Please enter a real room type name.";
                return RedirectToAction("Index");
            }

            bool isDuplicate = await _context.RoomTypes
                .AnyAsync(rt => rt.Name.ToLower() == roomType.Name.ToLower());
            if (isDuplicate)
            {
                TempData["Error"] = $"A room type named '{roomType.Name}' already exists. Please choose a different name.";
                return RedirectToAction("Index");
            }

            if (!ModelState.IsValid)
            {
                TempData["Error"] = "Could not add room type. Please check your input.";
                return RedirectToAction("Index");
            }

            _context.RoomTypes.Add(roomType);
            await _context.SaveChangesAsync();

            await AssignRoomNumbersAsync(roomType, RoomNumbers);
            await SyncRoomNoAsync(roomType.Id, RoomNumbers);
            await SyncAmenitiesAsync(roomType.Id, Amenities);

            TempData["Success"] = $"Room Type '{roomType.Name}' added.";
            return RedirectToAction("Index");
        }

        // Replaces the amenity set assigned to a room type (Hol_RoomAmenities) with the
        // comma-separated list submitted from the tag-pill UI. Amenity names are matched
        // case-insensitively against Hol_Amenities; unrecognized names become new amenities.
        private async Task SyncAmenitiesAsync(int roomTypeId, string? amenitiesCsv)
        {
            var desiredNames = (amenitiesCsv ?? string.Empty)
                .Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            var existingLinks = await _context.RoomTypeAmenities
                .Include(l => l.Amenity)
                .Where(l => l.RoomTypeId == roomTypeId)
                .ToListAsync();

            var toRemove = existingLinks
                .Where(l => !desiredNames.Any(n => string.Equals(n, l.Amenity!.Name, StringComparison.OrdinalIgnoreCase)))
                .ToList();
            if (toRemove.Any()) _context.RoomTypeAmenities.RemoveRange(toRemove);

            // Keep Name in sync on links that stay, in case the amenity was renamed elsewhere.
            foreach (var link in existingLinks.Except(toRemove))
                link.Name = link.Amenity!.Name;

            var existingNames = existingLinks.Select(l => l.Amenity!.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
            foreach (var name in desiredNames.Where(n => !existingNames.Contains(n)))
            {
                var amenity = await _context.Amenities.FirstOrDefaultAsync(a => a.Name.ToLower() == name.ToLower());
                if (amenity == null)
                {
                    amenity = new Amenity { Name = name };
                    _context.Amenities.Add(amenity);
                    await _context.SaveChangesAsync(); // need the generated Id before linking
                }
                _context.RoomTypeAmenities.Add(new RoomTypeAmenity { RoomTypeId = roomTypeId, AmenityId = amenity.Id, Name = amenity.Name });
            }

            await _context.SaveChangesAsync();
        }

        // Assigns the given comma-separated room numbers (e.g. "101,205") to the room type.
        // Rooms that already exist and belong to a DIFFERENT room type are skipped — a room
        // number already in use elsewhere can never be silently reassigned this way; the UI
        // enforces the same rule by disabling those chips. Room numbers that don't exist yet
        // are created fresh (available, floor derived from all but the last two digits).
        private async Task AssignRoomNumbersAsync(RoomType roomType, string? RoomNumbers)
        {
            if (string.IsNullOrWhiteSpace(RoomNumbers)) return;

            var numbers = RoomNumbers.Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries)
                                      .Distinct()
                                      .ToList();
            if (!numbers.Any()) return;

            var existingRooms = await _context.Rooms.Where(r => numbers.Contains(r.RoomNumber)).ToListAsync();
            foreach (var r in existingRooms.Where(r => r.RoomTypeId == roomType.Id))
            {
                // Already belongs to this type — just keep its description in sync.
                r.Description = roomType.Description;
            }

            var takenByAnotherType = existingRooms.Where(r => r.RoomTypeId != roomType.Id).Select(r => r.RoomNumber).ToHashSet();
            var existingNumbers = existingRooms.Select(r => r.RoomNumber).ToHashSet();
            foreach (var num in numbers.Where(n => !existingNumbers.Contains(n) && !takenByAnotherType.Contains(n)))
            {
                var floor = num.Length > 2 ? num[..^2] : num;
                _context.Rooms.Add(new Room
                {
                    RoomNumber = num,
                    Floor = floor,
                    RoomTypeId = roomType.Id,
                    Status = RoomStatus.Available,
                    Description = roomType.Description
                });
            }

            await _context.SaveChangesAsync();
        }

        // tbl_RoomNo: mirrors the room numbers assigned via AssignRoomNumbersAsync into the
        // dedicated RoomNo table (RoomTypeId + RoomNo), matching the sketch's own table.
        // Kept in sync the same way AssignRoomNumbersAsync keeps Rooms in sync: numbers no
        // longer submitted are removed, new ones are added.
        private async Task SyncRoomNoAsync(int roomTypeId, string? RoomNumbers)
        {
            var numbers = (RoomNumbers ?? string.Empty)
                .Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries)
                .Distinct()
                .ToHashSet();

            var existing = await _context.RoomNos
                .Where(rn => rn.RoomTypeId == roomTypeId)
                .ToListAsync();

            var toRemove = existing.Where(rn => !numbers.Contains(rn.RoomNo)).ToList();
            if (toRemove.Any()) _context.RoomNos.RemoveRange(toRemove);

            var existingNumbers = existing.Select(rn => rn.RoomNo).ToHashSet();
            foreach (var num in numbers.Where(n => !existingNumbers.Contains(n)))
            {
                // A room number can only belong to one room type; skip if it's already
                // taken elsewhere (same rule AssignRoomNumbersAsync applies to Rooms).
                bool takenElsewhere = await _context.RoomNos
                    .AnyAsync(rn => rn.RoomNo == num && rn.RoomTypeId != roomTypeId);
                if (takenElsewhere) continue;

                _context.RoomNos.Add(new RoomNoEntry { RoomTypeId = roomTypeId, RoomNo = num });
            }

            await _context.SaveChangesAsync();
        }

        [HttpGet]
        public async Task<IActionResult> GetDetails(int id)
        {
            var rt = await _context.RoomTypes
                .Include(r => r.RoomTypeAmenities).ThenInclude(l => l.Amenity)
                .FirstOrDefaultAsync(r => r.Id == id);
            if (rt == null) return NotFound();
            var roomNumbers = await _context.Rooms
                .Where(r => r.RoomTypeId == id)
                .Select(r => r.RoomNumber)
                .ToListAsync();
            return Json(new {
                rt.Id, rt.Name,
                rt.Rate3Hours, rt.Rate12Hours, rt.BaseRate,
                rt.ExtraHourRate3Hours, rt.ExtraHourRate,
                rt.MaxOccupancy, rt.Description, rt.Amenities,
                roomNumbers
            });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(RoomType roomType, string? RoomNumbers, string? Amenities)
        {
            roomType.Name = roomType.Name?.Trim() ?? string.Empty;
            if (!IsValidRoomTypeName(roomType.Name))
            {
                TempData["Error"] = "Room type name looks invalid. Please enter a real room type name.";
                return RedirectToAction("Index");
            }

            bool isDuplicate = await _context.RoomTypes
                .AnyAsync(rt => rt.Id != roomType.Id && rt.Name.ToLower() == roomType.Name.ToLower());
            if (isDuplicate)
            {
                TempData["Error"] = $"A room type named '{roomType.Name}' already exists. Please choose a different name.";
                return RedirectToAction("Index");
            }

            if (!ModelState.IsValid)
            {
                TempData["Error"] = "Could not update room type.";
                return RedirectToAction("Index");
            }
            _context.Update(roomType);
            await _context.SaveChangesAsync();

            // The modal re-submits the full, current set of room numbers (existing + newly
            // added), so anything that was assigned to this type but is missing from that set
            // was removed via the "x" on a pill. Only delete rooms that have no active
            // reservations; otherwise, keep them and warn the user.
            var keepNumbers = (RoomNumbers ?? string.Empty)
                .Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries)
                .ToHashSet();
            var roomsToRemove = await _context.Rooms
                .Include(r => r.Reservations)
                .Where(r => r.RoomTypeId == roomType.Id && !keepNumbers.Contains(r.RoomNumber))
                .ToListAsync();
            var blockedRemovals = roomsToRemove
                .Where(r => r.Reservations.Any(res =>
                    res.Status != ReservationStatus.Cancelled
                    && res.Status != ReservationStatus.CheckedOut
                    && res.Status != ReservationStatus.Completed
                    && res.Status != ReservationStatus.NoShow))
                .Select(r => r.RoomNumber)
                .ToList();
            if (blockedRemovals.Any())
            {
                TempData["Error"] = $"Cannot remove room(s) {string.Join(", ", blockedRemovals)} — they have active reservations.";
                return RedirectToAction("Index");
            }
            if (roomsToRemove.Any())
            {
                _context.Rooms.RemoveRange(roomsToRemove);
                await _context.SaveChangesAsync();
            }

            // Assign any newly-picked rooms to this room type (existing assignments from the
            // modal are re-submitted too, so this is safe to apply as a whole).
            await AssignRoomNumbersAsync(roomType, RoomNumbers);
            await SyncRoomNoAsync(roomType.Id, RoomNumbers);

            // Keep every assigned room's own description in sync with its room type's description.
            var assignedRooms = await _context.Rooms.Where(r => r.RoomTypeId == roomType.Id).ToListAsync();
            foreach (var r in assignedRooms) r.Description = roomType.Description;
            await _context.SaveChangesAsync();

            await SyncAmenitiesAsync(roomType.Id, Amenities);

            TempData["Success"] = $"Room Type '{roomType.Name}' updated.";
            return RedirectToAction("Index");
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var rt = await _context.RoomTypes
                .Include(r => r.Rooms)
                .FirstOrDefaultAsync(r => r.Id == id);
            if (rt == null) { TempData["Error"] = "Room Type not found."; return RedirectToAction("Index"); }
            if (rt.Rooms.Any()) { TempData["Error"] = $"Cannot delete '{rt.Name}' — it has {rt.Rooms.Count} room(s) assigned."; return RedirectToAction("Index"); }
            _context.RoomTypes.Remove(rt);
            await _context.SaveChangesAsync();
            TempData["Success"] = $"Room Type '{rt.Name}' deleted.";
            return RedirectToAction("Index");
        }
    }
}
