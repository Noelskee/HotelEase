using HotelEase.Data;
using HotelEase.Filters;
using HotelEase.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HotelEase.Controllers
{
    // Staff room board / CRUD. Housekeeping: Board + MarkCleaned only.
    // Admin + Front Desk: room inventory (Index). Create/Edit/Delete remain Admin-only.
    [RequireRole(UserRole.Admin, UserRole.FrontDesk, UserRole.Housekeeping)]
    public class RoomController : Controller
    {
        private readonly ApplicationDbContext _context;
        public RoomController(ApplicationDbContext ctx) => _context = ctx;

        /// <summary>Room & Room Type management — Admin and Front Desk (view).</summary>
        public async Task<IActionResult> Index()
        {
            var role = HttpContext.Session.GetString("UserRole") ?? "";
            if (string.Equals(role, "Housekeeping", StringComparison.OrdinalIgnoreCase))
                return RedirectToAction(nameof(Board));

            ViewBag.IsAdmin = string.Equals(role, "Admin", StringComparison.OrdinalIgnoreCase);
            ViewBag.RoomTypes = await _context.RoomTypes
                .Include(rt => rt.Rooms)
                .Include(rt => rt.RoomTypeAmenities).ThenInclude(l => l.Amenity)
                .OrderBy(rt => rt.Name)
                .ToListAsync();
            return View(await _context.Rooms
                .Include(r => r.RoomType).ThenInclude(rt => rt!.RoomTypeAmenities).ThenInclude(l => l.Amenity)
                .OrderBy(r => r.RoomNumber)
                .ToListAsync());
        }
        // Visual room board (status grid).
        // Manuscript: HK and Front Desk both view statuses Available / Reserved /
        // Occupied / For Cleaning. HK may update cleaning readiness (MarkCleaned).
        public async Task<IActionResult> Board()
        {
            var role = HttpContext.Session.GetString("UserRole") ?? "";
            var isHousekeeping = string.Equals(role, "Housekeeping", StringComparison.OrdinalIgnoreCase);

            // All roles see the full status picture (manuscript Room & Housekeeping Management).
            var rooms = await _context.Rooms
                .Include(r => r.RoomType)
                .OrderBy(r => r.Floor).ThenBy(r => r.RoomNumber)
                .ToListAsync();

            var active = await _context.Reservations
                .Include(r => r.Guest)
                .Where(r => r.Status == ReservationStatus.CheckedIn
                         || r.Status == ReservationStatus.Reserved
                         || r.Status == ReservationStatus.Confirmed)
                .ToListAsync();

            ViewBag.ActiveReservations = active;
            ViewBag.IsHousekeeping = isHousekeeping;
            return View(rooms);
        }

        /// <summary>
        /// Housekeeping marks a ForCleaning room as Available after cleaning.
        /// </summary>
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> MarkCleaned(int id)
        {
            var role = HttpContext.Session.GetString("UserRole") ?? "";
            var allowed = string.Equals(role, "Housekeeping", StringComparison.OrdinalIgnoreCase)
                       || string.Equals(role, "Admin", StringComparison.OrdinalIgnoreCase)
                       || string.Equals(role, "FrontDesk", StringComparison.OrdinalIgnoreCase);
            if (!allowed) return Forbid();

            var room = await _context.Rooms.FirstOrDefaultAsync(r => r.Id == id);
            if (room == null)
            {
                TempData["Error"] = "Room not found.";
                return RedirectToAction(nameof(Board));
            }
            if (room.Status != RoomStatus.ForCleaning)
            {
                TempData["Error"] = $"Room {room.RoomNumber} is not For Cleaning (current: {room.Status}).";
                return RedirectToAction(nameof(Board));
            }

            var old = room.Status;
            room.Status = RoomStatus.Available;
            var userId = HttpContext.Session.GetInt32("UserId") ?? 0;
            _context.AuditLogs.Add(new AuditLog
            {
                Action = "update_room_status",
                EntityType = "Room",
                EntityId = room.Id,
                UserId = userId > 0 ? userId : null,
                UserName = HttpContext.Session.GetString("UserFullName"),
                Details = $"{old} → Available | Marked clean by housekeeping",
                CreatedAt = DateTime.UtcNow
            });
            await _context.SaveChangesAsync();
            TempData["Success"] = $"Room {room.RoomNumber} is now Available.";
            return RedirectToAction(nameof(Board));
        }


        /// <summary>JSON for room-edit modal — Admin only.</summary>
        [HttpGet]
        [RequireRole(UserRole.Admin)]
        public async Task<IActionResult> GetRoom(int id)
        {
            var room = await _context.Rooms
                .Include(r => r.RoomType).ThenInclude(rt => rt!.RoomTypeAmenities).ThenInclude(l => l.Amenity)
                .FirstOrDefaultAsync(r => r.Id == id);
            if (room == null) return NotFound();
            return Json(new
            {
                room.Id,
                room.RoomNumber,
                room.RoomTypeId,
                roomTypeName = room.RoomType?.Name,
                room.Floor,
                status       = (int)room.Status,
                room.Description,
                maxOccupancy = room.RoomType?.MaxOccupancy,
                amenities    = room.RoomType?.Amenities,
                baseRate     = room.RoomType?.BaseRate
            });
        }

        /// <summary>
        /// Room create/edit is Admin only. Housekeeping must not
        /// bypass the UI to alter room numbers, types, or floor assignments.
        /// </summary>
        [HttpPost, ValidateAntiForgeryToken]
        [RequireRole(UserRole.Admin)]
        public async Task<IActionResult> Edit(Room room)
        {
            // Defense in depth — attribute + explicit session check (Housekeeping must not edit).
            var editRole = HttpContext.Session.GetString("UserRole") ?? "";
            if (!string.Equals(editRole, "Admin", StringComparison.OrdinalIgnoreCase))
            {
                return RedirectToAction("AccessDenied", "Account");
            }

            if (!ModelState.IsValid)
            {
                TempData["Error"] = "Could not update room. Please check your input.";
                return RedirectToAction("Index");
            }

            bool isDuplicate = await _context.Rooms
                .AnyAsync(r => r.Id != room.Id && r.RoomNumber == room.RoomNumber);
            if (isDuplicate)
            {
                TempData["Error"] = $"Room {room.RoomNumber} is already assigned to another room. Please pick a different number.";
                return RedirectToAction("Index");
            }

            _context.Update(room);
            await _context.SaveChangesAsync();
            TempData["Success"] = $"Room {room.RoomNumber} updated.";
            return RedirectToAction("Index");
        }

        /// <summary>
        /// Room delete is Admin only. Housekeeping has no authority
        /// to remove physical rooms from inventory.
        /// </summary>
        [HttpPost, ValidateAntiForgeryToken]
        [RequireRole(UserRole.Admin)]
        public async Task<IActionResult> Delete(int id)
        {
            // Defense in depth — attribute + explicit session check.
            var delRole = HttpContext.Session.GetString("UserRole") ?? "";
            if (!string.Equals(delRole, "Admin", StringComparison.OrdinalIgnoreCase))
            {
                return RedirectToAction("AccessDenied", "Account");
            }

            var room = await _context.Rooms
                .Include(r => r.Reservations)
                .FirstOrDefaultAsync(r => r.Id == id);
            if (room == null)
            {
                TempData["Error"] = "Room not found.";
                return RedirectToAction("Index");
            }

            var activeReservations = room.Reservations
                .Where(r => r.Status != ReservationStatus.Cancelled
                    && r.Status != ReservationStatus.CheckedOut
                    && r.Status != ReservationStatus.Completed
                    && r.Status != ReservationStatus.NoShow)
                .ToList();

            if (activeReservations.Any())
            {
                TempData["Error"] = $"Cannot delete Room {room.RoomNumber} because it has active reservations. Cancel or complete them first.";
                return RedirectToAction("Index");
            }

            _context.Rooms.Remove(room);
            await _context.SaveChangesAsync();
            TempData["Success"] = $"Room {room.RoomNumber} deleted.";
            return RedirectToAction("Index");
        }
    }
}
