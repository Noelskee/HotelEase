using HotelEase.Data;
using HotelEase.Models;
using HotelEase.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HotelEase.Controllers;

[RequireRole(UserRole.Admin, UserRole.FrontDesk, UserRole.Housekeeping)]
public class AuditLogController : Controller
{
    private readonly ApplicationDbContext _db;
    public AuditLogController(ApplicationDbContext db) => _db = db;

    private bool IsAdmin() =>
        string.Equals(HttpContext.Session.GetString("UserRole"), "Admin", StringComparison.OrdinalIgnoreCase);

    private int? CurrentUserId() => HttpContext.Session.GetInt32("UserId");

    /// <summary>
    /// NOTE: Parameter is named logAction (NOT "action") to avoid conflict with
    /// the route value "action" which would otherwise bind to "Index" and break the filter.
    /// </summary>
    public async Task<IActionResult> Index(string? q = null, string? logAction = null, DateTime? from = null, DateTime? to = null)
    {
        var isAdmin = IsAdmin();
        var currentUserId = CurrentUserId();

        q = string.IsNullOrWhiteSpace(q) ? null : q.Trim();
        logAction = string.IsNullOrWhiteSpace(logAction) ? null : logAction.Trim();

        var query = _db.AuditLogs.Include(l => l.User).AsQueryable();

        // Non-admins see only their own logs
        if (!isAdmin)
        {
            query = query.Where(l => l.UserId == currentUserId);
        }

        if (from.HasValue)
        {
            var start = from.Value.Date;
            query = query.Where(l => l.CreatedAt >= start);
        }
        if (to.HasValue)
        {
            var end = to.Value.Date.AddDays(1);
            query = query.Where(l => l.CreatedAt < end);
        }
        if (!string.IsNullOrEmpty(logAction))
        {
            var a = logAction.ToLower();
            query = query.Where(l => l.Action != null && l.Action.ToLower().Contains(a));
        }
        if (!string.IsNullOrEmpty(q))
        {
            var term = q.ToLower();

            if (isAdmin)
            {
                // Admin can search by user too
                query = query.Where(l =>
                    (l.UserName != null && l.UserName.ToLower().Contains(term))
                    || (l.Details != null && l.Details.ToLower().Contains(term))
                    || (l.EntityType != null && l.EntityType.ToLower().Contains(term))
                    || (l.Action != null && l.Action.ToLower().Contains(term))
                    || (l.User != null && l.User.FullName.ToLower().Contains(term))
                    || (l.User != null && l.User.Email != null && l.User.Email.ToLower().Contains(term)));
            }
            else
            {
                // Staff/Housekeeping: search by action, entity, details only
                query = query.Where(l =>
                    (l.Details != null && l.Details.ToLower().Contains(term))
                    || (l.EntityType != null && l.EntityType.ToLower().Contains(term))
                    || (l.Action != null && l.Action.ToLower().Contains(term)));
            }
        }

        var logs = await query
            .OrderByDescending(l => l.CreatedAt)
            .Take(500)
            .ToListAsync();

        ViewBag.Search = q;
        ViewBag.ActionFilter = logAction;
        ViewBag.From = from?.ToString("yyyy-MM-dd");
        ViewBag.To = to?.ToString("yyyy-MM-dd");
        ViewBag.IsAdmin = isAdmin;

        return View(logs);
    }
}
