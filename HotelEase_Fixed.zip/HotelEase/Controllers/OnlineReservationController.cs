using HotelEase.Data;
using HotelEase.Models;
using HotelEase.Services;
using HotelEase.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace HotelEase.Controllers;

// Public, guest-facing online booking site — no login required.
// Views live in Views/OnlineReservation, with their own _Layout.cshtml
// (the "OnlineReservation" folder name matches this controller's name so
// Razor's default view/layout lookup finds them with no explicit paths).
// Staff-side reservation management (Manage/Details/Confirm/Cancel) lives
// separately in ReservationController and uses the staff Shared/_Layout.
[AllowAnonymous]
public class OnlineReservationController : Controller
{
    private readonly ApplicationDbContext _db;
    private readonly IReservationService _reservationSvc;
    private readonly IEmailService _emailSvc;
    private readonly IConfiguration _config;

    public OnlineReservationController(ApplicationDbContext db, IReservationService rs, IEmailService es, IConfiguration config)
    {
        _db = db; _reservationSvc = rs; _emailSvc = es; _config = config;
    }

    private string HotelName => _config.GetValue("AppSettings:HotelName", "Alemar Budgetel") ?? "Alemar Budgetel";
    private string PaymentPolicy => _config.GetValue("AppSettings:PaymentPolicy",
        "A deposit of 30% is required within 48 hours of booking confirmation. Payment instructions will be sent to your email.") ?? "";
    private string CancellationPolicy => _config.GetValue("AppSettings:CancellationPolicy",
        "Free cancellation is allowed up to 48 hours before check-in. Cancellations made after this period may be subject to charges at the hotel's discretion.") ?? "";
    // Public landing page (hero + welcome + rooms preview). Booking via Rooms.
    [HttpGet]
    public async Task<IActionResult> Index()
    {
        var featured = await _db.RoomTypes
            .Include(rt => rt.Images)
            .OrderBy(rt => rt.BaseRate)
            .Take(6)
            .ToListAsync();
        ViewBag.FeaturedRoomTypes = featured;
        return View();
    }

    // Public booking form — mirrors the staff Walk-In wizard's operation:
    // Step 1 search (stay type/dates/duration + guest count + optional room
    // type filter) -> Step 2 pick an available room card -> Step 3 guest
    // info + discount -> Step 4 review & confirm. A GET with search=true
    // re-renders the page with Step 2's room cards populated, same pattern
    // as FrontDeskController.WalkIn.
    [HttpGet]
    public async Task<IActionResult> Create(
        string? stayType,
        DateTime? checkInDate,
        DateTime? checkOutDate,
        int? durationHours,
        int? roomTypeId,
        int? adults,
        int? children,
        string? childrenAges = null,
        int? roomsRequested = null,
        bool search = false,
        int? roomId = null)
    {
        var today = checkInDate ?? DateTime.Today;
        var vm = new ReservationCreateViewModel
        {
            StayType = stayType == "Hourly" ? "Hourly" : "Nightly",
            CheckInDate = today,
            CheckOutDate = checkOutDate ?? today.AddDays(1),
            DurationHours = durationHours is 3 or 12 ? durationHours.Value : 3,
            RoomTypeId = roomTypeId is > 0 ? roomTypeId : null,
            Adults = adults is >= 1 and <= 20 ? adults.Value : 1,
            Children = children is >= 0 and <= 20 ? children.Value : 0,
            ChildrenAges = string.IsNullOrWhiteSpace(childrenAges) ? null : childrenAges.Trim(),
            Type = ReservationType.Online,
            RoomsRequested = roomsRequested is >= 1 and <= 10 ? roomsRequested.Value : 1,
            RoomId = roomId ?? 0
        };

        // Entry: Rooms page → Create with dates + room type.
        // Process is type-only (no physical room number until check-in).
        if (roomId is > 0)
            vm.RoomId = roomId.Value;

        if (roomTypeId is > 0 || search || checkInDate.HasValue)
        {
            vm.RoomTypeId = roomTypeId is > 0 ? roomTypeId : vm.RoomTypeId;
            vm.CurrentStep = 1; // Step 1 = confirm stay + type, then Guest, then Review
        }
        else
        {
            return RedirectToAction(nameof(Rooms));
        }

        // Nightly stays use full nights; hourly uses 3 or 12 only.
        if (vm.StayType == "Nightly")
            vm.DurationHours = 24;
        else if (vm.DurationHours is not (3 or 12))
            vm.DurationHours = 3;

        var checkOut = ComputeCheckOutDate(vm);
        vm.CheckOutDate = checkOut;
        var rooms = await _reservationSvc.GetAvailableRoomsAsync(vm.CheckInDate, checkOut);
        vm.AvailableRoomCards = await BuildAvailableRoomCardsAsync(vm, rooms);

        await PopulateRoomTypeDropdownAsync(vm);
        await PopulatePricingAsync(vm);

        // Pre-fill rate/name when a physical room or room type is known.
        if (vm.RoomId > 0)
        {
            var room = await _db.Rooms.Include(r => r.RoomType).FirstOrDefaultAsync(r => r.Id == vm.RoomId);
            if (room?.RoomType != null)
            {
                var rt = room.RoomType;
                var nights = vm.StayType == "Nightly"
                    ? Math.Max(1, (vm.CheckOutDate.Date - vm.CheckInDate.Date).Days)
                    : 1;
                var unit = vm.StayType == "Hourly"
                    ? rt.GetRateForDuration(vm.DurationHours)
                    : rt.GetRateForDuration(24);
                ViewBag.SelectedRoomTypeName = $"{rt.Name} — Room {room.RoomNumber}";
                ViewBag.SelectedRoomRate = unit * nights;
                ViewBag.SelectedRoomUnitRate = unit;
            }
        }
        else if (vm.RoomTypeId is > 0)
        {
            var rt = await _db.RoomTypes.FindAsync(vm.RoomTypeId.Value);
            if (rt != null)
            {
                var nights = vm.StayType == "Nightly"
                    ? Math.Max(1, (vm.CheckOutDate.Date - vm.CheckInDate.Date).Days)
                    : 1;
                var unit = vm.StayType == "Hourly"
                    ? rt.GetRateForDuration(vm.DurationHours)
                    : rt.GetRateForDuration(24);
                ViewBag.SelectedRoomTypeName = rt.Name;
                ViewBag.SelectedRoomRate = unit * nights;
                ViewBag.SelectedRoomUnitRate = unit;
            }
        }

        ViewBag.PaymentPolicy = PaymentPolicy;
        return View(vm);
    }

    // Same duration/date logic as WalkInViewModel.ComputeCheckOutDate.
    private static string? NormalizeImageUrl(string? url)
    {
        if (string.IsNullOrWhiteSpace(url)) return null;
        url = url.Trim();
        if (url.StartsWith("http://", StringComparison.OrdinalIgnoreCase)
            || url.StartsWith("https://", StringComparison.OrdinalIgnoreCase)
            || url.StartsWith("/"))
            return url;
        return "/" + url.TrimStart('~', '/');
    }

    // Nightly: check-out is always 12:00 PM on the selected departure date
    // (hotel policy — same as Reservation.NightlyCheckoutTime).
    // Hourly: same calendar day as check-in + selected package (3 or 12 hours).
    private static DateTime ComputeCheckOutDate(ReservationCreateViewModel vm)
    {
        if (vm.StayType == "Nightly")
            return vm.CheckOutDate.Date.Add(Reservation.NightlyCheckoutTime);
        var hours = vm.DurationHours is 3 or 12 ? vm.DurationHours : 3;
        return vm.CheckInDate.Date.AddHours(hours);
    }

    private async Task<List<ReservationCreateViewModel.AvailableRoomCard>> BuildAvailableRoomCardsAsync(
        ReservationCreateViewModel vm, List<Room> rooms)
    {
        // Show individual physical rooms so guests can pick a room NUMBER
        // (same idea as Walk-In). Availability already accounts for type holds.
        var isNightly = vm.StayType == "Nightly";
        var durationHours = isNightly ? 24 : vm.DurationHours;
        var nights = isNightly ? Math.Max(1, (vm.CheckOutDate.Date - vm.CheckInDate.Date).Days) : 1;

        // Max occupancy applies to ADULTS only (children free / do not reduce capacity) — same as Front Desk.
        var adults = Math.Max(1, vm.Adults);
        var filtered = rooms
            .Where(r => !vm.RoomTypeId.HasValue || r.RoomTypeId == vm.RoomTypeId.Value)
            .Where(r => (r.RoomType?.MaxOccupancy ?? 1) >= adults)
            .OrderBy(r => r.RoomNumber)
            .ToList();

        var typeIds = filtered.Select(r => r.RoomTypeId).Distinct().ToList();
        var primaryImages = await _db.RoomTypeImages
            .Where(i => typeIds.Contains(i.RoomTypeId))
            .GroupBy(i => i.RoomTypeId)
            .Select(g => g.OrderByDescending(i => i.IsPrimary).ThenBy(i => i.DisplayOrder).ThenBy(i => i.Id).First())
            .ToDictionaryAsync(i => i.RoomTypeId, i => i.ImageUrl);

        var cards = new List<ReservationCreateViewModel.AvailableRoomCard>();
        foreach (var room in filtered)
        {
            var rt = room.RoomType;
            cards.Add(new ReservationCreateViewModel.AvailableRoomCard
            {
                Id = room.Id, // physical Room.Id (room number selectable)
                RoomNumber = room.RoomNumber,
                RoomTypeName = rt?.Name ?? "Unknown",
                StayRate = rt == null ? 0 : rt.GetRateForDuration(durationHours) * (isNightly ? nights : 1),
                DurationLabel = isNightly ? $"{nights} night(s)" : $"{vm.DurationHours} hour(s)",
                MaxOccupancy = rt?.MaxOccupancy ?? 1,
                Amenities = rt?.Amenities ?? "",
                ImageUrl = NormalizeImageUrl(primaryImages.TryGetValue(room.RoomTypeId, out var url) ? url : rt?.ImageUrl)
            });
        }
        return cards;
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(ReservationCreateViewModel vm)
    {
        // Normalize discount flags: senior and pwd are mutually exclusive.
        if (vm.IsSeniorCitizen && vm.IsPwd)
            vm.IsPwd = false;

        // Government ID is collected at front-desk check-in only — never block online booking.
        vm.IdType = string.IsNullOrWhiteSpace(vm.IdType) ? null : vm.IdType.Trim();
        vm.IdNumber = string.IsNullOrWhiteSpace(vm.IdNumber) ? null : vm.IdNumber.Trim();
        ModelState.Remove(nameof(vm.IdType));
        ModelState.Remove(nameof(vm.IdNumber));

        if (vm.StayType == "Hourly")
        {
            // Hourly packages are 3 or 12 hours only — overnight covers full day.
            if (vm.DurationHours is not (3 or 12))
                vm.DurationHours = 3;
        }
        else
        {
            vm.StayType = "Nightly";
            vm.DurationHours = 24;
        }
        // Hourly: same-day checkout = check-in + duration. Nightly: date picker.
        vm.CheckOutDate = ComputeCheckOutDate(vm);

        async Task<IActionResult> ReturnToStepAsync(int step)
        {
            vm.CurrentStep = step;
            var checkOut = ComputeCheckOutDate(vm);
            var roomsForRedisplay = await _reservationSvc.GetAvailableRoomsAsync(vm.CheckInDate, checkOut);
            vm.AvailableRoomCards = await BuildAvailableRoomCardsAsync(vm, roomsForRedisplay);
            await PopulateRoomTypeDropdownAsync(vm);
            await PopulatePricingAsync(vm);
            ViewBag.PaymentPolicy = PaymentPolicy;
            return View(vm);
        }

        if (vm.CheckOutDate.Date <= vm.CheckInDate.Date && vm.StayType != "Hourly")
        {
            ModelState.AddModelError("", "For Overnight stays, check-out date must be at least one day after check-in.");
            return await ReturnToStepAsync(1);
        }
        if (vm.CheckOutDate <= vm.CheckInDate)
        {
            ModelState.AddModelError("", "Check-out must be after check-in.");
            return await ReturnToStepAsync(1);
        }

        if (vm.CheckInDate < DateTime.Today)
        {
            ModelState.AddModelError("", "Check-in date can't be in the past.");
            return await ReturnToStepAsync(1);
        }

        // Online booking is room-TYPE only (no physical room number).
        // Guest picks type + quantity; front desk assigns room numbers at check-in.
        var roomTypeId = vm.RoomTypeId is > 0 ? vm.RoomTypeId.Value : 0;
        // Legacy: RoomId may still arrive from older links — map to its type.
        if (roomTypeId <= 0 && vm.RoomId > 0)
        {
            var legacyRoom = await _db.Rooms.AsNoTracking().FirstOrDefaultAsync(r => r.Id == vm.RoomId);
            if (legacyRoom != null) roomTypeId = legacyRoom.RoomTypeId;
        }
        if (roomTypeId <= 0)
        {
            ModelState.AddModelError("", "Please select a room type.");
            return await ReturnToStepAsync(1);
        }

        var roomType = await _db.RoomTypes.FirstOrDefaultAsync(rt => rt.Id == roomTypeId);
        if (roomType == null)
        {
            ModelState.AddModelError("", "Selected room type was not found.");
            return await ReturnToStepAsync(1);
        }

        if (vm.RoomsRequested < 1 || vm.RoomsRequested > 5)
            ModelState.AddModelError(nameof(vm.RoomsRequested), "Number of rooms must be between 1 and 5.");
        var roomsWantedCount = Math.Max(1, Math.Min(5, vm.RoomsRequested > 0 ? vm.RoomsRequested : 1));
        // Capacity check must match ReservationService.GetAvailableRoomsAsync:
        // subtract both (1) physical rooms already assigned via RoomId and
        // (2) unassigned online/type holds (RoomId null, PreferredRoomTypeId set)
        // so subsequent online bookings cannot overbook the type.
        var freeRoomsOfType = (await _reservationSvc.GetAvailableRoomsAsync(vm.CheckInDate, vm.CheckOutDate))
            .Where(r => r.RoomTypeId == roomTypeId)
            .ToList();
        var freeCount = freeRoomsOfType.Count;
        if (freeCount < roomsWantedCount)
        {
            ModelState.AddModelError("", $"Only {freeCount} {roomType.Name} room(s) available for those dates (you requested {roomsWantedCount}).");
            return await ReturnToStepAsync(1);
        }

        // Synthetic selection list (type only — RoomId left 0 / unassigned)
        var selectedList = Enumerable.Range(0, roomsWantedCount)
            .Select(_ => new ReservationCreateViewModel.OnlineRoomSelection
            {
                RoomId = 0,
                RoomNumber = "TBA",
                RoomTypeName = roomType.Name,
                MaxOccupancy = roomType.MaxOccupancy,
                StayRate = vm.StayType == "Hourly"
                    ? roomType.GetRateForDuration(vm.DurationHours)
                    : roomType.GetRateForDuration(24)
            }).ToList();

        if (!ModelState.IsValid)
        {
            return await ReturnToStepAsync(3);
        }

        // Capacity is per room, not total adults across the whole booking.
        // Example: 2× SINGLE (max 1 adult each) with 1 adult per room is valid;
        // rejecting total adults (2) > MaxOccupancy (1) was blocking multi-room.
        var maxOcc = Math.Max(1, roomType.MaxOccupancy);
        var perRoomAdults = new List<int>();
        if (!string.IsNullOrWhiteSpace(vm.RoomOccupancyJson))
        {
            try
            {
                using var doc = System.Text.Json.JsonDocument.Parse(vm.RoomOccupancyJson);
                if (doc.RootElement.ValueKind == System.Text.Json.JsonValueKind.Array)
                {
                    foreach (var el in doc.RootElement.EnumerateArray())
                    {
                        var a = 1;
                        if (el.TryGetProperty("adults", out var ap) && ap.TryGetInt32(out var av))
                            a = Math.Max(1, av);
                        else if (el.TryGetProperty("Adults", out var ap2) && ap2.TryGetInt32(out var av2))
                            a = Math.Max(1, av2);
                        perRoomAdults.Add(a);
                    }
                }
            }
            catch { /* fall back below */ }
        }
        if (perRoomAdults.Count == 0)
        {
            // Distribute total adults across requested rooms as evenly as possible
            var totalA = Math.Max(1, vm.Adults);
            for (var i = 0; i < roomsWantedCount; i++)
                perRoomAdults.Add(1);
            for (var i = 0; i < totalA - roomsWantedCount && i < perRoomAdults.Count; i++)
                perRoomAdults[i % perRoomAdults.Count]++;
        }
        for (var i = 0; i < perRoomAdults.Count; i++)
        {
            if (perRoomAdults[i] > maxOcc)
            {
                ModelState.AddModelError("",
                    $"{roomType.Name} allows up to {maxOcc} adult(s) per room (R{i + 1} has {perRoomAdults[i]}). " +
                    "Reduce adults for that room, or extra adults can be recorded as Extra Persons at check-in.");
                return await ReturnToStepAsync(1);
            }
        }
        if (vm.Children > 0)
        {
            if (string.IsNullOrWhiteSpace(vm.ChildrenAges))
            {
                ModelState.AddModelError(nameof(vm.ChildrenAges), "Please select the age of each child (1–12 years).");
                return await ReturnToStepAsync(1);
            }
            var ageParts = vm.ChildrenAges.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            if (ageParts.Length < vm.Children)
            {
                ModelState.AddModelError(nameof(vm.ChildrenAges), $"Please select the age of each child ({vm.Children} required).");
                return await ReturnToStepAsync(1);
            }
            foreach (var part in ageParts)
            {
                if (!int.TryParse(part, out var age) || age < 1 || age > 12)
                {
                    ModelState.AddModelError(nameof(vm.ChildrenAges), "Child ages must be between 1 and 12 years only.");
                    return await ReturnToStepAsync(1);
                }
            }
        }

        // Reuse an existing guest only when BOTH the contact number AND full
        // name match. Same contact number with a different name means a
        // different person sharing a phone, so create a separate guest record.
        var guest = await _db.Guests
            .FirstOrDefaultAsync(g => g.ContactNumber == vm.GuestContactNumber &&
                                      g.FullName == vm.GuestFullName);

        if (guest == null)
        {
            guest = new Guest
            {
                FullName = vm.GuestFullName,
                Email = vm.GuestEmail,
                ContactNumber = vm.GuestContactNumber,
                Nationality = vm.GuestNationality ?? "Filipino",
                IdType = vm.IdType,
                IdNumber = vm.IdNumber,
                IsSeniorCitizen = vm.IsSeniorCitizen,
                IsPwd = vm.IsPwd
            };
            _db.Guests.Add(guest);
        }
        else
        {
            guest.Email = vm.GuestEmail;
            guest.Nationality = vm.GuestNationality ?? guest.Nationality ?? "Filipino";
            guest.IdType = vm.IdType ?? guest.IdType;
            guest.IdNumber = vm.IdNumber ?? guest.IdNumber;
            guest.IsSeniorCitizen = vm.IsSeniorCitizen;
            guest.IsPwd = vm.IsPwd;
        }
        await _db.SaveChangesAsync();

        // Persist any uploaded GCash payment proof before saving the reservation.
        string? paymentProofUrl = null;
        if (vm.PaymentMethod?.Equals("GCash", StringComparison.OrdinalIgnoreCase) == true &&
            vm.PaymentProofImage != null && vm.PaymentProofImage.Length > 0)
        {
            var ext = Path.GetExtension(vm.PaymentProofImage.FileName).ToLowerInvariant();
            var allowed = new[] { ".jpg", ".jpeg", ".png", ".webp", ".gif" };
            if (allowed.Contains(ext) && vm.PaymentProofImage.Length <= 5 * 1024 * 1024)
            {
                // Store outside wwwroot so proofs are not directly web-accessible.
                var uploadsDir = Path.Combine(Directory.GetCurrentDirectory(), "App_Data", "payment-proofs");
                Directory.CreateDirectory(uploadsDir);
                var fileName = $"payment_{Guid.NewGuid():N}{ext}";
                var filePath = Path.Combine(uploadsDir, fileName);
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await vm.PaymentProofImage.CopyToAsync(stream);
                }
                // Private path marker — staff retrieve via authenticated endpoint.
                paymentProofUrl = $"private-proofs/{fileName}";
            }
        }

        // One reservation per requested room of the type (physical RoomId assigned at check-in).
        var roomsWanted = selectedList.Count;
        var stayEnum = vm.StayType == "Hourly" ? StayType.Hourly : StayType.Nightly;
        var nights = stayEnum == StayType.Nightly
            ? Math.Max(1, (vm.CheckOutDate.Date - vm.CheckInDate.Date).Days)
            : 1;
        var refBase = _reservationSvc.GenerateReferenceNumber();
        var createdReservations = new List<Reservation>();
        var roomTypeLabel = roomType.Name;

        // Prefer explicit per-room occupancy from Step 1 (RoomOccupancyJson).
        // Example: R1: 1A + 2C ages 5,10 · R2: 1A + 3C ages 7,12,8
        var roomCount = selectedList.Count;
        var adultsPerRoom = new int[roomCount];
        var childrenPerRoom = new int[roomCount];
        var agesPerRoom = Enumerable.Range(0, roomCount).Select(_ => new List<string>()).ToArray();

        var occList = new List<(int Adults, int Children, string? Ages)>();
        if (!string.IsNullOrWhiteSpace(vm.RoomOccupancyJson))
        {
            try
            {
                using var doc = System.Text.Json.JsonDocument.Parse(vm.RoomOccupancyJson);
                foreach (var node in doc.RootElement.EnumerateArray())
                {
                    var a = node.TryGetProperty("adults", out var ap) ? ap.GetInt32() : 1;
                    var c = node.TryGetProperty("children", out var cp) ? cp.GetInt32() : 0;
                    var ages = node.TryGetProperty("childrenAges", out var agesP) ? agesP.GetString() : null;
                    occList.Add((Math.Max(1, a), Math.Max(0, c), ages));
                }
            }
            catch { /* fall through */ }
        }

        if (occList.Count >= roomCount)
        {
            for (var i = 0; i < roomCount; i++)
            {
                adultsPerRoom[i] = occList[i].Adults;
                childrenPerRoom[i] = occList[i].Children;
                if (!string.IsNullOrWhiteSpace(occList[i].Ages))
                    agesPerRoom[i].AddRange(occList[i].Ages!
                        .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries));
            }
        }
        else
        {
            var totalAdults = Math.Max(1, vm.Adults);
            var totalChildren = Math.Max(0, vm.Children);
            var ageQueue = string.IsNullOrWhiteSpace(vm.ChildrenAges)
                ? new List<string>()
                : vm.ChildrenAges.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                    .Where(a => !string.IsNullOrWhiteSpace(a)).ToList();
            for (var i = 0; i < roomCount; i++)
                adultsPerRoom[i] = 1;
            var adultsLeft = Math.Max(0, totalAdults - roomCount);
            for (var i = 0; adultsLeft > 0; i++, adultsLeft--)
                adultsPerRoom[i % roomCount]++;
            for (var c = 0; c < totalChildren; c++)
            {
                var roomIdx = c % roomCount;
                childrenPerRoom[roomIdx]++;
                if (c < ageQueue.Count)
                    agesPerRoom[roomIdx].Add(ageQueue[c]);
            }
        }

        for (var i = 0; i < selectedList.Count; i++)
        {
            var roomAdults = Math.Max(1, adultsPerRoom[i]);
            var roomChildren = Math.Max(0, childrenPerRoom[i]);
            var roomAges = agesPerRoom[i].Count > 0 ? string.Join(",", agesPerRoom[i]) : null;

            var res = new Reservation
            {
                ReferenceNumber = roomsWanted == 1 ? refBase : $"{refBase}-{i + 1}",
                GuestId = guest.Id,
                RoomId = null, // assigned at check-in
                PreferredRoomTypeId = roomType.Id,
                PreferredRoomType = roomType,
                StayType = stayEnum,
                CheckInDate = vm.CheckInDate.Date,
                CheckOutDate = vm.CheckOutDate.Date,
                // Overnight: expected departure is 12:00 PM on the check-out date.
                // Hourly: expected departure is check-in date + package hours.
                ExpectedCheckIn = vm.CheckInDate.Date,
                ExpectedCheckOut = stayEnum == StayType.Nightly
                    ? vm.CheckOutDate.Date.Add(Reservation.NightlyCheckoutTime)
                    : vm.CheckInDate.Date.AddHours(vm.DurationHours is 3 or 12 ? vm.DurationHours : 3),
                // Nightly stays always store DurationHours = 24; billing uses NumberOfNights.
                DurationHours = stayEnum == StayType.Hourly
                    ? (vm.DurationHours is 3 or 12 ? vm.DurationHours : 3)
                    : 24,
                NumberOfNights = nights,
                Adults = roomAdults,
                Children = roomChildren,
                GuestCount = roomAdults + roomChildren,
                ChildrenAges = roomAges,
                RoomsRequested = 1,
                ExtraPersons = i == 0 ? Math.Max(0, vm.ExtraPersons) : 0,
                ExtraBeds = i == 0 ? vm.ExtraBeds : 0,
                SpecialRequests = i == 0
                    ? ((vm.SpecialRequests ?? "")
                       + (roomsWanted > 1 ? $" | Multi-room type booking: {roomsWanted}x {roomTypeLabel} (group {refBase})" : $" | Type: {roomTypeLabel}")
                       + (string.IsNullOrWhiteSpace(vm.PaymentMethod) ? "" : $" | Payment intent: {vm.PaymentMethod}")
                       + (string.IsNullOrWhiteSpace(paymentProofUrl) ? "" : $" | Proof: {paymentProofUrl}")).Trim().TrimStart('|').Trim()
                    : $"Part of multi-room group {refBase}",
                Type = ReservationType.Online,
                Status = ReservationStatus.Pending,
                PaymentStatus = PaymentStatus.Unpaid,
                IsPaymentVerified = false,
                CreatedByUserId = null
            };
            _db.Reservations.Add(res);
            createdReservations.Add(res);
        }
        var primaryReservation = createdReservations[0];

        // Save first so reservation Ids are generated (avoid Details/0 links).
        await _db.SaveChangesAsync();

        // Notify the back office (one bell item for the booking group).
        var roomTypeName = roomType.Name;
        var notificationMessage = roomsWanted > 1
            ? $"New online reservation from {guest.FullName} — {roomsWanted}x {roomTypeName}, group {refBase} (room TBA at check-in)"
            : $"New online reservation from {guest.FullName} — Ref {primaryReservation.ReferenceNumber} ({roomTypeName}, room TBA at check-in)";

        _db.Notifications.Add(new Notification
        {
            Type = "NewOnlineReservation",
            Message = notificationMessage,
            Link = $"/Reservation/Details/{primaryReservation.Id}",
            ReservationId = primaryReservation.Id,
            CreatedAt = DateTime.UtcNow
        });
        await _db.SaveChangesAsync();

        if (!string.IsNullOrWhiteSpace(guest.Email))
        {
            var isHourly = primaryReservation.DurationHours < 24;
            var emailNights = isHourly ? 1 : Math.Max(1, ((primaryReservation.CheckOutDate ?? primaryReservation.CheckInDate ?? DateTime.Today) - (primaryReservation.CheckInDate ?? DateTime.Today)).Days);
            var rate = isHourly ? roomType.GetRateForDuration(primaryReservation.DurationHours) : roomType.GetRateForDuration(24);
            var (subtotal, discount, discountedTotal, percent) = CalculateDiscount(rate * emailNights * roomsWanted, guest.IsSeniorCitizen || guest.IsPwd);
            var extrasCharge = primaryReservation.ExtraPersons * 300m + primaryReservation.ExtraBeds * 400m;
            var total = discountedTotal + extrasCharge;
            var stayLine = isHourly
                ? $"<li><strong>Stay Type:</strong> Hourly — {roomType.GetDurationLabel(primaryReservation.DurationHours)}</li>"
                : $"<li><strong>Stay Type:</strong> Nightly — {emailNights} night(s)</li>";
            var discountLine = discount > 0
                ? $"<li><strong>Discount:</strong> {percent:P0} (₱{discount:N2})</li>"
                : "";
            var extrasLine = extrasCharge > 0
                ? $"<li><strong>Extras:</strong> {(primaryReservation.ExtraPersons > 0 ? $"{primaryReservation.ExtraPersons} extra person(s)" : "")}{(primaryReservation.ExtraPersons > 0 && primaryReservation.ExtraBeds > 0 ? ", " : "")}{(primaryReservation.ExtraBeds > 0 ? $"{primaryReservation.ExtraBeds} extra bed(s)" : "")} (₱{extrasCharge:N2})</li>"
                : "";
            var roomsLine = roomsWanted > 1
                ? $"<li><strong>Rooms Booked:</strong> {roomsWanted}x {roomTypeLabel} (room number at check-in)</li>"
                : $"<li><strong>Room Type:</strong> {roomTypeName} (room number assigned at check-in)</li>";
            var body = $"""
                <p>Hi {System.Net.WebUtility.HtmlEncode(guest.FullName)},</p>
                <p>Thank you for booking with <strong>{HotelName}</strong>. Here are your reservation details:</p>
                <ul>
                    <li><strong>Primary Reference Number:</strong> {primaryReservation.ReferenceNumber}</li>
                    {roomsLine}
                    {stayLine}
                    <li><strong>Check-In:</strong> {primaryReservation.CheckInDate:MMMM dd, yyyy h:mm tt}</li>
                    <li><strong>Check-Out:</strong> {primaryReservation.CheckOutDate:MMMM dd, yyyy h:mm tt}</li>
                    <li><strong>Estimated Subtotal:</strong> ₱{subtotal:N2}</li>
                    {discountLine}
                    {extrasLine}
                    <li><strong>Estimated Total:</strong> ₱{total:N2}</li>
                    <li><strong>Status:</strong> Pending confirmation</li>
                </ul>
                <p><strong>Payment Policy:</strong> {System.Net.WebUtility.HtmlEncode(PaymentPolicy)}</p>
                <p>Our staff will contact you at {System.Net.WebUtility.HtmlEncode(guest.ContactNumber)} to confirm this reservation. You can also check its status anytime on our website using your reference number and contact number.</p>
                <p>— {HotelName}</p>
                """;
            // Best-effort: a failed/unconfigured mail server must never block
            // the reservation itself, so this is intentionally not awaited
            // into the request's success/failure path.
            await _emailSvc.SendAsync(guest.Email!, $"Your {HotelName} Reservation — {primaryReservation.ReferenceNumber}", body);
        }

        return RedirectToAction("Confirmation", new { id = primaryReservation.Id });
    }

    private static (decimal subtotal, decimal discount, decimal total, decimal percent) CalculateDiscount(decimal subtotal, bool qualifiesForDiscount)
    {
        const decimal discountPercent = 0.20m;
        if (!qualifiesForDiscount || subtotal <= 0)
            return (subtotal, 0, subtotal, 0);
        var discount = subtotal * discountPercent;
        return (subtotal, discount, subtotal - discount, discountPercent);
    }

    private async Task PopulateRoomTypeDropdownAsync(ReservationCreateViewModel vm)
    {
        var roomTypes = await _db.RoomTypes.OrderBy(rt => rt.BaseRate).ToListAsync();

        vm.RoomTypeOptions = roomTypes.Select(rt => new SelectListItem
        {
            Value = rt.Id.ToString(),
            Text = rt.Name
        }).ToList();

        var capacityMap = roomTypes.ToDictionary(
            rt => rt.Id.ToString(),
            rt => new
            {
                name = rt.Name,
                maxOccupancy = rt.MaxOccupancy,
                rate = rt.GetRateForDuration(24),
                rate3 = rt.GetRateForDuration(3),
                rate12 = rt.GetRateForDuration(12),
                rate24 = rt.GetRateForDuration(24)
            });
        ViewBag.RoomTypeCapacityJson = System.Text.Json.JsonSerializer.Serialize(capacityMap);
    }

    private async Task PopulatePricingAsync(ReservationCreateViewModel vm)
    {
        RoomType? roomType = null;
        if (vm.RoomId > 0)
        {
            var room = await _db.Rooms.Include(r => r.RoomType).FirstOrDefaultAsync(r => r.Id == vm.RoomId);
            roomType = room?.RoomType;
        }
        else if (vm.RoomTypeId.HasValue)
        {
            roomType = await _db.RoomTypes.FirstOrDefaultAsync(rt => rt.Id == vm.RoomTypeId.Value);
        }

        vm.RatePerNight = vm.StayType == "Hourly"
            ? (roomType?.GetRateForDuration(vm.DurationHours) ?? 0)
            : (roomType?.BaseRate ?? 0);
        vm.DiscountPercent = vm.IsSeniorCitizen || vm.IsPwd ? 0.20m : 0;
        vm.DiscountAmount = vm.Subtotal * vm.DiscountPercent;
    }

    public async Task<IActionResult> Confirmation(int id)
    {
        var res = await _db.Reservations
            .Include(r => r.Guest)
            .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
            .Include(r => r.PreferredRoomType)
            .FirstOrDefaultAsync(r => r.Id == id);
        if (res == null) return NotFound();

        ViewBag.PaymentPolicy = PaymentPolicy;
        ViewBag.CancellationPolicy = CancellationPolicy;
        ViewBag.CanCancel = res.Status == ReservationStatus.Pending || res.Status == ReservationStatus.Confirmed;
        return View(res);
    }

    // Public: browse room types (cards) — optionally filtered by date range.
    [HttpGet]
    public async Task<IActionResult> Rooms(string? stayType, DateTime? checkIn, DateTime? checkOut, int? durationHours, int? adults, int? children, string? childrenAges)
    {
        var normalizedStayType = stayType == "Hourly" ? "Hourly" : "Nightly";
        var search = new RoomAvailabilitySearchViewModel
        {
            StayType = normalizedStayType,
            CheckInDate = checkIn ?? DateTime.Today,
            CheckOutDate = checkOut ?? DateTime.Today.AddDays(1),
            DurationHours = durationHours is 3 or 12 ? durationHours.Value : 3,
            Adults = adults is >= 1 and <= 20 ? adults.Value : 1,
            Children = children is >= 0 and <= 20 ? children.Value : 0,
            ChildrenAges = childrenAges
        };

        var hasValidDates = normalizedStayType == "Hourly"
            ? checkIn.HasValue
            : checkIn.HasValue && checkOut.HasValue && checkOut.Value > checkIn.Value;
        var effectiveCheckOut = search.EffectiveCheckOutDate;

        var roomTypes = await _db.RoomTypes
            .Include(rt => rt.RoomTypeAmenities).ThenInclude(rta => rta.Amenity)
            .Include(rt => rt.Rooms)
            .Include(rt => rt.Images)
            .OrderBy(rt => rt.BaseRate)
            .ToListAsync();

        // Use service so unassigned online type-holds reduce the count (same as Create POST).
        var freeRooms = hasValidDates
            ? await _reservationSvc.GetAvailableRoomsAsync(search.CheckInDate, effectiveCheckOut)
            : await _reservationSvc.GetAvailableRoomsForWalkInAsync();

        var freeByType = freeRooms
            .GroupBy(r => r.RoomTypeId)
            .ToDictionary(g => g.Key, g => g.Count());

        var availabilityList = new List<RoomTypeAvailabilityViewModel>();
        foreach (var rt in roomTypes)
        {
            var total = rt.Rooms.Count;
            var availableForDates = freeByType.GetValueOrDefault(rt.Id, 0);

            availabilityList.Add(new RoomTypeAvailabilityViewModel
            {
                RoomType = rt,
                TotalRoomCount = total,
                AvailableRoomCount = availableForDates,
                IsAvailableForDates = availableForDates > 0,
                StayType = search.StayType,
                CheckInDate = search.CheckInDate,
                CheckOutDate = effectiveCheckOut,
                DurationHours = search.DurationHours,
                GuestCount = search.GuestCount,
                Adults = search.Adults,
                Children = search.Children,
                ChildrenAges = search.ChildrenAges
            });
        }

        ViewBag.Search = search;
        ViewBag.HasValidDates = hasValidDates;
        return View(availabilityList);
    }

    // Public: room type details page (gallery/description/amenities/availability/pricing).
    [HttpGet]
    public async Task<IActionResult> RoomDetails(int id, string? stayType, DateTime? checkIn, DateTime? checkOut, int? durationHours, int? adults, int? children, string? childrenAges)
    {
        var roomType = await _db.RoomTypes
            .Include(rt => rt.RoomTypeAmenities).ThenInclude(rta => rta.Amenity)
            .Include(rt => rt.Rooms)
            .Include(rt => rt.Images)
            .FirstOrDefaultAsync(rt => rt.Id == id);
        if (roomType == null) return NotFound();

        // 24 hours is not a separate rate — treat as Nightly (1 night).
        var normalizedStayType = stayType == "Hourly" && durationHours is not 24 ? "Hourly" : "Nightly";
        var normalizedDuration = durationHours is 3 or 12 ? durationHours.Value : 3;
        var hasDates = normalizedStayType == "Hourly"
            ? checkIn.HasValue
            : checkIn.HasValue && checkOut.HasValue && checkOut.Value > checkIn.Value;
        var effectiveCheckOut = hasDates
            ? (normalizedStayType == "Hourly" ? checkIn!.Value.AddHours(normalizedDuration) : checkOut!.Value)
            : (DateTime?)null;

        var roomIdsWithReservations = await _db.Reservations
            .Where(r => r.RoomId != null
                && r.Status != ReservationStatus.Cancelled
                && r.Status != ReservationStatus.CheckedOut
                && r.Status != ReservationStatus.Completed
                && r.Status != ReservationStatus.NoShow)
            .Select(r => r.RoomId!.Value)
            .ToListAsync();

        var availableNow = roomType.Rooms.Count(r =>
            r.Status == RoomStatus.Available && !roomIdsWithReservations.Contains(r.Id));
        int availableForDates = 0;
        if (hasDates)
        {
            availableForDates = await _reservationSvc.GetAvailableCapacityForRoomTypeAsync(
                roomType.Id, checkIn!.Value, effectiveCheckOut!.Value);
        }

        var normalizedAdults = adults is >= 1 and <= 20 ? adults.Value : 1;
        var normalizedChildren = children is >= 0 and <= 20 ? children.Value : 0;

        ViewBag.StayType = normalizedStayType;
        ViewBag.DurationHours = normalizedDuration;
        ViewBag.AvailableNow = availableNow;
        ViewBag.AvailableForDates = availableForDates;
        ViewBag.HasDates = hasDates;
        ViewBag.CheckInDate = checkIn;
        ViewBag.CheckOutDate = effectiveCheckOut;
        ViewBag.Adults = normalizedAdults;
        ViewBag.Children = normalizedChildren;
        ViewBag.ChildrenAges = childrenAges ?? "";
        ViewBag.GuestCount = normalizedAdults + normalizedChildren;
        ViewBag.Nights = hasDates
            ? (normalizedStayType == "Hourly" ? 1 : (effectiveCheckOut!.Value - checkIn!.Value).Days)
            : 0;
        return View(roomType);
    }

    // Public, no login: guests check their own reservation status using
    // their reference number + the contact number they booked with.
    [HttpGet]
    [HttpGet]
    public async Task<IActionResult> Status(string? referenceNumber, string? @ref)
    {
        // Refresh from result page: ?ref=ALE-... reloads the same booking (does not clear the form).
        var key = !string.IsNullOrWhiteSpace(@ref) ? @ref : referenceNumber;
        if (!string.IsNullOrWhiteSpace(key))
        {
            return await Status(new ReservationStatusLookupViewModel { ReferenceNumber = key.Trim() });
        }
        return View(new ReservationStatusLookupViewModel());
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Status(ReservationStatusLookupViewModel vm)
    {
        if (string.IsNullOrWhiteSpace(vm.ReferenceNumber))
        {
            ModelState.AddModelError(nameof(vm.ReferenceNumber), "Reference number is required.");
            return View(vm);
        }

        var refNo = vm.ReferenceNumber.Trim();

        // Lookup by reference only (contact is shown on the result, not required to search).
        var res = await _db.Reservations
            .Include(r => r.Guest)
            .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
            .Include(r => r.PreferredRoomType)
            .FirstOrDefaultAsync(r => r.ReferenceNumber == refNo);

        if (res == null)
        {
            var baseRef = refNo;
            var rIdx = refNo.LastIndexOf("-R", StringComparison.OrdinalIgnoreCase);
            if (rIdx > 0 && int.TryParse(refNo[(rIdx + 2)..], out _))
                baseRef = refNo[..rIdx];

            res = await _db.Reservations
                .Include(r => r.Guest)
                .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
                .Include(r => r.PreferredRoomType)
                .Where(r => r.ReferenceNumber == baseRef
                    || r.ReferenceNumber.StartsWith(baseRef + "-R"))
                .OrderBy(r => r.ReferenceNumber)
                .FirstOrDefaultAsync();
        }

        if (res == null)
        {
            ModelState.AddModelError("", "No reservation found for that reference number. Please double-check and try again.");
            return View(vm);
        }

        var groupBase = res.ReferenceNumber;
        var dashR = groupBase.LastIndexOf("-R", StringComparison.OrdinalIgnoreCase);
        if (dashR > 0 && int.TryParse(groupBase[(dashR + 2)..], out _))
            groupBase = groupBase[..dashR];

        var group = await _db.Reservations
            .Include(r => r.Guest)
            .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
            .Include(r => r.PreferredRoomType)
            .Where(r => r.GuestId == res.GuestId
                && (r.ReferenceNumber == groupBase
                    || r.ReferenceNumber.StartsWith(groupBase + "-R")))
            .OrderBy(r => r.ReferenceNumber)
            .ToListAsync();

        ViewBag.ReservationGroup = group;
        ViewBag.GroupBaseReference = groupBase;
        return View("StatusResult", res);
    }

    // Guest self-service cancellation: lookup page.
    [HttpGet]
    public IActionResult Cancel(string? referenceNumber, string? contactNumber)
    {
        var vm = new CancelReservationViewModel
        {
            ReferenceNumber = referenceNumber ?? "",
            ContactNumber = contactNumber ?? ""
        };
        ViewBag.CancellationPolicy = CancellationPolicy;
        return View(vm);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Cancel(CancelReservationViewModel vm)
    {
        ViewBag.CancellationPolicy = CancellationPolicy;

        if (!ModelState.IsValid)
            return View(vm);

        var res = await _db.Reservations
            .Include(r => r.Guest)
            .Include(r => r.Room)
            .FirstOrDefaultAsync(r =>
                r.ReferenceNumber == vm.ReferenceNumber.Trim() &&
                r.Guest.ContactNumber == vm.ContactNumber.Trim());

        if (res == null)
        {
            vm.Found = false;
            vm.ErrorMessage = "No reservation found matching that reference number and contact number. Please double-check and try again.";
            return View(vm);
        }

        if (res.Status != ReservationStatus.Pending && res.Status != ReservationStatus.Confirmed)
        {
            vm.Found = false;
            vm.ErrorMessage = "This reservation cannot be cancelled online. Please contact hotel staff for assistance.";
            return View(vm);
        }

        vm.Reservation = res;
        vm.Found = true;
        return View(vm);
    }

    // Confirm guest cancellation.
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> CancelConfirm(string referenceNumber, string contactNumber)
    {
        var res = await _db.Reservations
            .Include(r => r.Guest)
            .Include(r => r.Room)
            .FirstOrDefaultAsync(r =>
                r.ReferenceNumber == referenceNumber.Trim() &&
                r.Guest.ContactNumber == contactNumber.Trim());

        if (res == null || (res.Status != ReservationStatus.Pending && res.Status != ReservationStatus.Confirmed))
        {
            TempData["Error"] = "This reservation cannot be cancelled online. Please contact hotel staff.";
            return RedirectToAction("Cancel", new { referenceNumber, contactNumber });
        }

        // Cancel entire booking group under the same base reference.
        var baseRef = System.Text.RegularExpressions.Regex.Replace(res.ReferenceNumber ?? "", @"-\d+$", "");
        if (string.IsNullOrEmpty(baseRef)) baseRef = res.ReferenceNumber ?? "";
        var group = await _db.Reservations
            .Include(r => r.Room)
            .Include(r => r.Guest)
            .Where(r => r.Guest.ContactNumber == contactNumber.Trim()
                && (r.ReferenceNumber == baseRef
                    || r.ReferenceNumber == referenceNumber.Trim()
                    || r.ReferenceNumber.StartsWith(baseRef + "-")))
            .ToListAsync();

        var cancellable = new[] { ReservationStatus.Pending, ReservationStatus.Confirmed, ReservationStatus.Reserved };
        var toCancel = group.Where(r => cancellable.Contains(r.Status)).ToList();
        if (toCancel.Count == 0) toCancel.Add(res);

        foreach (var item in toCancel)
        {
            item.Status = ReservationStatus.Cancelled;
            item.CancellationReason = "Cancelled by guest via online portal";
            if (item.Room != null && item.Room.Status != RoomStatus.Occupied)
                item.Room.Status = RoomStatus.Available;
        }

        // Staff bell — so Front Desk can detect guest cancellations.
        var guestName = res.Guest?.FullName ?? "Guest";
        _db.Notifications.Add(new Notification
        {
            Type = "ReservationCancelled",
            Message = $"Guest cancelled online — {guestName} (Ref {baseRef})"
                      + (toCancel.Count > 1 ? $", {toCancel.Count} rooms" : ""),
            Link = $"/Reservation/Details/{res.Id}",
            ReservationId = res.Id,
            CreatedAt = DateTime.UtcNow
        });

        await _db.SaveChangesAsync();

        if (!string.IsNullOrWhiteSpace(res.Guest?.Email))
        {
            var body = $"""
                <p>Hi {System.Net.WebUtility.HtmlEncode(res.Guest.FullName)},</p>
                <p>Your reservation at <strong>{HotelName}</strong> has been cancelled.</p>
                <ul>
                    <li><strong>Reference Number:</strong> {baseRef}</li>
                    <li><strong>Room Type:</strong> {res.Room?.RoomType?.Name ?? "N/A"}</li>
                    <li><strong>Check-In:</strong> {res.CheckInDate:MMMM dd, yyyy}</li>
                    <li><strong>Check-Out:</strong> {res.CheckOutDate:MMMM dd, yyyy}</li>
                </ul>
                <p>If you have any questions, please refer to the hotel details in your confirmation email.</p>
                """;
            await _emailSvc.SendAsync(res.Guest.Email, $"Reservation Cancelled — {baseRef}", body);
        }

        return View(res);
    }

    // AJAX: return available rooms of a given type for the selected dates.
    // Uses GetAvailableRoomsAsync so unassigned online type-holds are respected.
    [HttpGet]
    public async Task<IActionResult> GetAvailableRooms(int roomTypeId, DateTime checkIn, DateTime checkOut)
    {
        if (checkOut <= checkIn)
            return Json(new List<object>());

        var available = (await _reservationSvc.GetAvailableRoomsAsync(checkIn, checkOut))
            .Where(r => r.RoomTypeId == roomTypeId)
            .OrderBy(r => r.RoomNumber)
            .Select(r => new { id = r.Id, roomNumber = r.RoomNumber })
            .ToList();

        return Json(available);
    }

    // AJAX: look up an existing guest by contact number so the booking form
    // can pre-fill personal details for returning guests.
    [HttpGet]
    public async Task<IActionResult> LookupGuest(string contactNumber)
    {
        if (string.IsNullOrWhiteSpace(contactNumber))
            return Json(new { found = false });

        var guest = await _db.Guests
            .FirstOrDefaultAsync(g => g.ContactNumber == contactNumber.Trim());

        if (guest == null)
            return Json(new { found = false });

        return Json(new
        {
            found = true,
            fullName = guest.FullName,
            email = guest.Email,
            nationality = guest.Nationality,
            idType = guest.IdType,
            idNumber = guest.IdNumber,
            isSeniorCitizen = guest.IsSeniorCitizen,
            isPwd = guest.IsPwd
        });
    }
}
