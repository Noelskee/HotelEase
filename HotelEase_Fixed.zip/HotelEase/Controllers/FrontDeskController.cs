using System.Data;
using HotelEase.Data;
using HotelEase.Filters;
using HotelEase.Helpers;
using HotelEase.Models;
using HotelEase.Services;
using HotelEase.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace HotelEase.Controllers
{
    // Front Desk.
    //
    // Direct Walk-In (WalkIn GET/POST) and pre-booked Reservation Check-In
    // (Index/CheckIn/CheckOut/Receipt) share the same billing/payment
    // services. Walk-ins are created at the front desk, checked in, and
    // charged immediately. Pre-booked reservations follow the standard
    // arrival/verification flow. Requires staff login throughout, since it
    // records which user checked the guest in/out.
    [RequireRole(UserRole.Admin, UserRole.FrontDesk)]
    public class FrontDeskController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IBillingService _billingSvc;
        private readonly IReservationService _reservationSvc;
        private readonly IRoomService _roomSvc;
        private readonly IAuditService _audit;

        public FrontDeskController(
            ApplicationDbContext ctx,
            IBillingService billingSvc,
            IReservationService reservationSvc,
            IRoomService roomSvc,
            IAuditService audit)
        {
            _context = ctx;
            _billingSvc = billingSvc;
            _reservationSvc = reservationSvc;
            _roomSvc = roomSvc;
            _audit = audit;
        }

        // ── Front Desk dashboard: today's arrivals/departures from Reservations ──
        public async Task<IActionResult> Index(string? mode = null)
        {
            // mode: "checkin" (default) | "checkout"
            // Check-In menu and Check-Out menu must not share the same mixed UI.
            ViewBag.Mode = string.Equals(mode, "checkout", StringComparison.OrdinalIgnoreCase)
                ? "checkout"
                : "checkin";

            var today = DateTime.Today;

            // Arrivals still awaiting check-in: expected on or before today
            // (includes late arrivals so they stay visible until processed).
            ViewBag.TodayArrivals = await _context.Reservations
                .Include(r => r.Guest).Include(r => r.Room).ThenInclude(rm => rm!.RoomType).Include(r => r.PreferredRoomType)
                .Where(r => (r.Status == ReservationStatus.Pending
                          || r.Status == ReservationStatus.Confirmed
                          || r.Status == ReservationStatus.Reserved)
                    && ((r.ExpectedCheckIn.HasValue && r.ExpectedCheckIn.Value.Date <= today)
                        || (!r.ExpectedCheckIn.HasValue && r.CheckInDate.HasValue && r.CheckInDate.Value.Date <= today)))
                .OrderBy(r => r.ExpectedCheckIn ?? r.CheckInDate).ToListAsync();

            // Expected departures still in-house today (for dashboard summary use)
            ViewBag.TodayDepartures = await _context.Reservations
                .Include(r => r.Guest).Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
                .Where(r => r.Status == ReservationStatus.CheckedIn
                    && r.ExpectedCheckOut.HasValue
                    && r.ExpectedCheckOut.Value.Date == today)
                .OrderBy(r => r.ExpectedCheckOut).ToListAsync();

            // Guests who already checked out (today + last 7 days) — shown on Check-Out nav
            ViewBag.RecentCheckOuts = await _context.Reservations
                .Include(r => r.Guest).Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
                .Where(r => (r.Status == ReservationStatus.CheckedOut
                          || r.Status == ReservationStatus.Completed)
                    && r.ActualCheckOut.HasValue
                    && r.ActualCheckOut.Value.Date >= today.AddDays(-7))
                .OrderByDescending(r => r.ActualCheckOut)
                .ToListAsync();

            // Occupancy snapshot for the dashboard strip
            var totalRooms = await _context.Rooms.CountAsync();
            var occupied = await _context.Rooms.CountAsync(r => r.Status == RoomStatus.Occupied);
            var available = await _context.Rooms.CountAsync(r => r.Status == RoomStatus.Available);
            var dirty = await _context.Rooms.CountAsync(r => r.Status == RoomStatus.ForCleaning || r.Status == RoomStatus.Maintenance);
            var inHouse = await _context.Reservations
                .Include(r => r.Guest).Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
                .Where(r => r.Status == ReservationStatus.CheckedIn)
                .OrderBy(r => r.Room!.RoomNumber)
                .ToListAsync();

            ViewBag.TotalRooms = totalRooms;
            ViewBag.OccupiedRooms = occupied;
            ViewBag.AvailableRooms = available;
            ViewBag.DirtyRooms = dirty;
            ViewBag.InHouse = inHouse;
            ViewBag.OccupancyPct = totalRooms > 0 ? (int)Math.Round(100.0 * occupied / totalRooms) : 0;

            return View();
        }

        // ── Direct Walk-In (creates a Guest + Pending Reservation and checks in immediately) ──
        [HttpGet]
        public async Task<IActionResult> WalkIn(
            string? stayType = null,
            int? durationHours = null,
            int? numberOfNights = null,
            string? checkOutDate = null,
            int? roomTypeId = null,
            int? roomId = null,
            string? selectedRoomsJson = null)
        {
            var now = DateTime.Now;
            var parsedStayType = ParseStayType(stayType);
            var parsedDuration = durationHours is 3 or 12 ? durationHours.Value : 3;

            // Nightly: nights derived from check-out date (or fallback numberOfNights).
            // Checkout always uses the hotel standard nightly checkout time (12:00).
            int parsedNights;
            DateTime nightlyCheckOut;
            if (parsedStayType == WalkInStayType.Nightly)
            {
                if (DateTime.TryParse(checkOutDate, out var coDate) && coDate.Date > now.Date)
                {
                    parsedNights = Math.Clamp((coDate.Date - now.Date).Days, 1, 30);
                    nightlyCheckOut = coDate.Date.Add(Reservation.NightlyCheckoutTime);
                }
                else
                {
                    parsedNights = Math.Clamp(numberOfNights ?? 1, 1, 30);
                    nightlyCheckOut = now.Date.AddDays(parsedNights).Add(Reservation.NightlyCheckoutTime);
                }
            }
            else
            {
                parsedNights = 1;
                nightlyCheckOut = now.AddHours(parsedDuration);
            }

            var vm = new WalkInViewModel
            {
                StayType = parsedStayType,
                DurationHours = parsedDuration,
                NumberOfNights = parsedNights,
                CheckInDateTime = now,
                CheckOutDateTime = parsedStayType == WalkInStayType.Nightly
                    ? nightlyCheckOut
                    : now.AddHours(parsedDuration),
                RoomTypeId = roomTypeId,
                RoomId = roomId ?? 0,
                SelectedRoomsJson = string.IsNullOrWhiteSpace(selectedRoomsJson) ? "[]" : selectedRoomsJson
            };

            // Walk-in starts immediately at the server's current time.
            // Availability must use the complete requested stay window so a
            // future reservation (e.g. Sept 13–15) does not block a walk-in
            // that ends before that reservation starts.
            var requestedCheckOut = parsedStayType == WalkInStayType.Nightly
                ? nightlyCheckOut
                : now.AddHours(parsedDuration);
            var availableRooms = await _reservationSvc.GetAvailableRoomsForWalkInAsync(now, requestedCheckOut);
            // Only rooms from the central availability rule are listed; reserved,
            // occupied, cleaning and maintenance rooms are not shown at all.
            vm.AvailableRoomCards = BuildAvailableRoomCards(vm, availableRooms);

            vm.AvailableRooms = availableRooms.Select(r => new SelectListItem(
                $"Room {r.RoomNumber} – {r.RoomType?.Name ?? "Unknown"} (₱{r.RoomType?.BaseRate ?? 0:N0})",
                r.Id.ToString())).ToList();

            vm.RoomTypeOptions = await _context.RoomTypes
                .OrderBy(rt => rt.Name)
                .Select(rt => new SelectListItem(rt.Name, rt.Id.ToString()))
                .ToListAsync();
            vm.NationalityOptions = GetNationalityOptions();
            return View(vm);
        }

        // Returns the authoritative RoomType rates used by Direct Walk-In.
        // The UI uses this endpoint whenever Stay Type / Duration changes so the
        // displayed price always comes from Room & Room Type Management.
        [HttpGet]
        public async Task<IActionResult> GetWalkInRoomRates(int roomId)
        {
            var room = await _context.Rooms
                .AsNoTracking()
                .Include(r => r.RoomType)
                .FirstOrDefaultAsync(r => r.Id == roomId);
            if (room?.RoomType == null) return NotFound();

            var rt = room.RoomType;
            return Json(new
            {
                roomId = room.Id,
                roomTypeId = rt.Id,
                rate3Hours = rt.GetRateForDuration(3),
                rate12Hours = rt.GetRateForDuration(12),
                nightlyRate = rt.GetRateForDuration(24)
            });
        }

        [HttpGet]
        public async Task<IActionResult> GetWalkInRates(int roomTypeId)
        {
            var rt = await _context.RoomTypes.AsNoTracking().FirstOrDefaultAsync(x => x.Id == roomTypeId);
            if (rt == null) return NotFound();

            return Json(new
            {
                roomTypeId = rt.Id,
                rate3Hours = rt.GetRateForDuration(3),
                rate12Hours = rt.GetRateForDuration(12),
                nightlyRate = rt.GetRateForDuration(24)
            });
        }

        [HttpGet]
        public async Task<IActionResult> GetWalkInAvailableRoomsJson(string? stayType, int? durationHours, int? numberOfNights, string? checkOutDate = null)
        {
            var now = DateTime.Now;
            var parsedStayType = ParseStayType(stayType);
            var parsedDuration = durationHours is 3 or 12 ? durationHours.Value : 3;
            int parsedNights;
            DateTime requestedCheckOut;
            if (parsedStayType == WalkInStayType.Nightly)
            {
                if (DateTime.TryParse(checkOutDate, out var coDate) && coDate.Date > now.Date)
                {
                    parsedNights = Math.Clamp((coDate.Date - now.Date).Days, 1, 30);
                    requestedCheckOut = coDate.Date.Add(Reservation.NightlyCheckoutTime);
                }
                else
                {
                    parsedNights = Math.Max(1, numberOfNights ?? 1);
                    requestedCheckOut = now.Date.AddDays(parsedNights).Add(Reservation.NightlyCheckoutTime);
                }
            }
            else
            {
                parsedNights = 1;
                requestedCheckOut = now.AddHours(parsedDuration);
            }

            var availableRooms = await _reservationSvc.GetAvailableRoomsForWalkInAsync(now, requestedCheckOut);
            var list = availableRooms.Select(r =>
            {
                var rt = r.RoomType;
                return new
                {
                    id = r.Id,
                    roomNumber = r.RoomNumber,
                    roomTypeId = r.RoomTypeId,
                    roomTypeName = rt?.Name ?? "Unknown",
                    description = r.Description ?? "",
                    maxOccupancy = rt?.MaxOccupancy ?? 1,
                    rate3Hours = rt?.GetRateForDuration(3) ?? 0,
                    rate12Hours = rt?.GetRateForDuration(12) ?? 0,
                    rateNightly = rt?.GetRateForDuration(24) ?? 0,
                    stayRate = rt == null ? 0 : (parsedStayType == WalkInStayType.Nightly
                        ? rt.GetRateForDuration(24) * parsedNights
                        : rt.GetRateForDuration(parsedDuration)),
                    durationLabel = parsedStayType == WalkInStayType.Nightly
                        ? $"{parsedNights} {(parsedNights == 1 ? "Night" : "Nights")}"
                        : $"{parsedDuration} hour(s)"
                };
            }).ToList();

            return Json(list);
        }

        private static WalkInStayType ParseStayType(string? value) =>
            value?.Trim().Equals("Nightly", StringComparison.OrdinalIgnoreCase) == true
                ? WalkInStayType.Nightly
                : WalkInStayType.Hourly;

        // `rooms` must already be filtered by IReservationService.GetAvailableRoomsAsync /
        // GetAvailableRoomsForWalkInAsync, so every card here is selectable.
        private static List<WalkInViewModel.AvailableRoomCard> BuildAvailableRoomCards(WalkInViewModel vm, List<Room> rooms)
        {
            var nights = vm.StayType == WalkInStayType.Nightly ? vm.NumberOfNights : 1;

            return rooms
                .Select(r =>
                {
                    var rt = r.RoomType;
                    const string status = "Available";
                    const bool selectable = true;
                    return new WalkInViewModel.AvailableRoomCard
                    {
                        Id = r.Id,
                        RoomNumber = r.RoomNumber,
                        RoomTypeId = r.RoomTypeId,
                        RoomTypeName = rt?.Name ?? "Unknown",
                        Description = r.Description ?? "",
                        StayRate = rt == null ? 0 : (vm.StayType == WalkInStayType.Nightly
                            ? rt.GetRateForDuration(24) * nights
                            : rt.GetRateForDuration(vm.DurationHours)),
                        // Use GetRateForDuration so zero DB rates still show consultation defaults.
                        Rate3Hours = rt?.GetRateForDuration(3) ?? 0,
                        Rate12Hours = rt?.GetRateForDuration(12) ?? 0,
                        Rate24Hours = rt?.GetRateForDuration(24) ?? 0,
                        RateNightly = rt?.GetRateForDuration(24) ?? 0,
                        DurationLabel = vm.StayType == WalkInStayType.Nightly
                            ? $"{nights} {(nights == 1 ? "Night" : "Nights")}"
                            : $"{vm.DurationHours} hour(s)",
                        MaxOccupancy = rt?.MaxOccupancy ?? 1,
                        Amenities = rt?.Amenities ?? "",
                        Status = status,
                        IsSelectable = selectable
                    };
                })
                .ToList();
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> WalkIn(WalkInViewModel vm)
        {
            var now = DateTime.Now;

            // Recover from empty-string posts on non-nullable value types
            // (browser can send "" for cleared number inputs / hidden fields).
            // Without this, ModelState shows the opaque "The value '' is invalid."
            void ClearEmptyIntBinding(string key, Action applyDefault)
            {
                if (ModelState.TryGetValue(key, out var entry)
                    && entry.Errors.Any(e => e.ErrorMessage != null
                        && e.ErrorMessage.Contains("is invalid", StringComparison.OrdinalIgnoreCase)))
                {
                    entry.Errors.Clear();
                    entry.ValidationState = Microsoft.AspNetCore.Mvc.ModelBinding.ModelValidationState.Valid;
                    applyDefault();
                }
            }
            ClearEmptyIntBinding(nameof(vm.RoomId), () => { /* keep 0 */ });
            ClearEmptyIntBinding(nameof(vm.ExtraPersons), () => { vm.ExtraPersons = Math.Max(0, vm.ExtraPersons); });
            ClearEmptyIntBinding(nameof(vm.ExtraBeds), () => { vm.ExtraBeds = Math.Max(0, vm.ExtraBeds); });
            ClearEmptyIntBinding(nameof(vm.Adults), () => { if (vm.Adults < 1) vm.Adults = 1; });
            ClearEmptyIntBinding(nameof(vm.Children), () => { if (vm.Children < 0) vm.Children = 0; });
            ClearEmptyIntBinding(nameof(vm.NumberOfNights), () => { if (vm.NumberOfNights < 1) vm.NumberOfNights = 1; });
            ClearEmptyIntBinding(nameof(vm.DurationHours), () => { if (vm.DurationHours < 3) vm.DurationHours = 3; });
            if (ModelState.TryGetValue(nameof(vm.AmountTendered), out var amtEntry)
                && amtEntry.Errors.Any(e => e.ErrorMessage != null
                    && e.ErrorMessage.Contains("is invalid", StringComparison.OrdinalIgnoreCase)))
            {
                amtEntry.Errors.Clear();
                amtEntry.ValidationState = Microsoft.AspNetCore.Mvc.ModelBinding.ModelValidationState.Valid;
                vm.AmountTendered = null;
            }

            vm.GuestFullName = vm.GuestFullName?.Trim() ?? string.Empty;
            vm.GuestContactNumber = vm.GuestContactNumber?.Trim() ?? string.Empty;
            vm.GuestNationality = string.IsNullOrWhiteSpace(vm.GuestNationality) ? "Filipino" : vm.GuestNationality.Trim();
            vm.GuestEmail = string.IsNullOrWhiteSpace(vm.GuestEmail) ? null : vm.GuestEmail.Trim();
            // Walk-In checks in immediately — Government ID is required here.
            vm.IdType = vm.IdType?.Trim() ?? string.Empty;
            vm.IdNumber = vm.IdNumber?.Trim() ?? string.Empty;
            if (string.IsNullOrWhiteSpace(vm.IdType))
                ModelState.AddModelError(nameof(vm.IdType), "Government ID Type is required at check-in.");
            if (string.IsNullOrWhiteSpace(vm.IdNumber))
                ModelState.AddModelError(nameof(vm.IdNumber), "ID Number is required at check-in.");

            // Direct walk-in always checks in NOW. The browser must not be able
            // to back-date or future-date an actual walk-in check-in. The server
            // is the source of truth for the check-in timestamp.
            if (vm.StayType == WalkInStayType.Hourly)
            {
                if (vm.DurationHours is not (3 or 12))
                    ModelState.AddModelError(nameof(vm.DurationHours), "Hourly duration must be 3 or 12 hours (use Overnight for full day).");
            }
            else
            {
                // Nightly: nights = Check-out Date − Check-in Date (must be ≥ 1).
                // Same-day dates are not a valid nightly stay.
                if (vm.CheckOutDateTime.HasValue && vm.CheckOutDateTime.Value.Date > now.Date)
                {
                    var nights = (vm.CheckOutDateTime.Value.Date - now.Date).Days;
                    if (nights < 1)
                        ModelState.AddModelError(nameof(vm.CheckOutDateTime), "Check-out date must be after check-in date for overnight stays.");
                    else
                        vm.NumberOfNights = Math.Clamp(nights, 1, 30);
                }
                else if (vm.NumberOfNights < 1 || vm.NumberOfNights > 30)
                {
                    ModelState.AddModelError(nameof(vm.CheckOutDateTime), "Please select a valid check-out date after today.");
                }
            }

            var walkInCheckIn = now;
            // Nightly checkout uses the hotel standard checkout time (12:00),
            // NOT check-in time + 24h × nights.
            var walkInCheckOut = vm.StayType == WalkInStayType.Nightly
                ? walkInCheckIn.Date.AddDays(Math.Max(1, vm.NumberOfNights)).Add(Reservation.NightlyCheckoutTime)
                : walkInCheckIn.AddHours(vm.DurationHours is 3 or 12 ? vm.DurationHours : 3);

            vm.CheckInDateTime = walkInCheckIn;
            vm.CheckOutDateTime = walkInCheckOut;

            var selectedRooms = vm.SelectedRooms;
            foreach (var sel in selectedRooms)
            {
                sel.StayType = vm.StayType.ToString();
                sel.DurationHours = vm.DurationHours;
                sel.NumberOfNights = vm.StayType == WalkInStayType.Nightly ? vm.NumberOfNights : 1;
                sel.CheckInDateTime = vm.CheckInDateTime;
                sel.CheckOutDateTime = vm.CheckOutDateTime;
            }
            if (!selectedRooms.Any() && vm.RoomId > 0)
            {
                selectedRooms.Add(new WalkInViewModel.WalkInRoomSelection
                {
                    RoomId = vm.RoomId,
                    StayType = vm.StayType.ToString(),
                    DurationHours = vm.DurationHours,
                    NumberOfNights = vm.NumberOfNights,
                    CheckInDateTime = vm.CheckInDateTime,
                    CheckOutDateTime = vm.CheckOutDateTime
                });
            }

            if (!selectedRooms.Any())
                ModelState.AddModelError(string.Empty, "Please select at least one room.");

            foreach (var sel in selectedRooms)
            {
                var isNightly = sel.StayType.Equals("Nightly", StringComparison.OrdinalIgnoreCase);
                if (isNightly)
                {
                    if (sel.NumberOfNights < 1)
                        ModelState.AddModelError(string.Empty, $"Room {sel.RoomNumber} requires a valid number of nights.");
                }
                else
                {
                    if (sel.DurationHours is not (3 or 12))
                        ModelState.AddModelError(string.Empty, $"Room {sel.RoomNumber} duration must be 3 or 12 hours.");
                }
            }

            var roomsById = new Dictionary<int, Room>();
            if (selectedRooms.Select(r => r.RoomId).Distinct().Count() != selectedRooms.Count)
                ModelState.AddModelError(string.Empty, "The same room was selected more than once.");

            foreach (var sel in selectedRooms)
            {
                var room = await _context.Rooms.Include(r => r.RoomType).FirstOrDefaultAsync(r => r.Id == sel.RoomId);
                if (room == null)
                {
                    ModelState.AddModelError(string.Empty, "One of the selected rooms is no longer valid.");
                    continue;
                }

                if (!_reservationSvc.IsRoomAvailable(sel.RoomId, walkInCheckIn, walkInCheckOut))
                    ModelState.AddModelError(string.Empty, $"Room {room.RoomNumber} is not available for the selected stay dates.");

                roomsById[sel.RoomId] = room;
            }

            // Per-room adult capacity (do not compare total adults to one room's max).
            foreach (var sel in selectedRooms)
            {
                if (!roomsById.TryGetValue(sel.RoomId, out var capRoom) || capRoom.RoomType == null)
                    continue;
                var maxOcc = Math.Max(1, capRoom.RoomType.MaxOccupancy);
                var roomAdults = Math.Max(1, sel.Adults > 0 ? sel.Adults : 1);
                if (roomAdults > maxOcc)
                {
                    ModelState.AddModelError(string.Empty,
                        $"Room {capRoom.RoomNumber} ({capRoom.RoomType.Name}) allows up to {maxOcc} adult(s); {roomAdults} were entered. Extra adults can be recorded as Extra Persons.");
                }
            }

            // Recalculate the selected-room rate from the database on the server.
            // Never trust the hidden/client-side StayRate when completing a walk-in.
            foreach (var sel in selectedRooms)
            {
                if (!roomsById.TryGetValue(sel.RoomId, out var selectedRoom) || selectedRoom.RoomType == null)
                    continue;

                var rt = selectedRoom.RoomType;
                decimal authoritativeRate;
                if (vm.StayType == WalkInStayType.Nightly)
                    authoritativeRate = rt.GetRateForDuration(24) * Math.Max(1, vm.NumberOfNights);
                else
                    authoritativeRate = rt.GetRateForDuration(vm.DurationHours);

                if (authoritativeRate <= 0)
                {
                    var rateLabel = vm.StayType == WalkInStayType.Nightly
                        ? "Nightly"
                        : $"{vm.DurationHours} hours";
                    ModelState.AddModelError(string.Empty,
                        $"Room {selectedRoom.RoomNumber} has no configured rate for {rateLabel}. Please configure the rate in Room & Room Types Management.");
                }

                // Normalize the posted selection so the persisted reservation uses
                // the current server-side stay values, not stale browser JSON.
                sel.StayType = vm.StayType.ToString();
                sel.DurationHours = vm.DurationHours;
                sel.NumberOfNights = vm.StayType == WalkInStayType.Nightly ? vm.NumberOfNights : 1;
                sel.StayRate = authoritativeRate;
            }

            Guest? existingGuest = null;
            if (!string.IsNullOrWhiteSpace(vm.GuestContactNumber))
            {
                existingGuest = await _context.Guests
                    .FirstOrDefaultAsync(g => !g.IsSystemRecord &&
                        g.ContactNumber == vm.GuestContactNumber &&
                        g.FullName.ToLower() == vm.GuestFullName.ToLower());
            }

            if (existingGuest != null && await _context.Reservations.AnyAsync(r =>
                r.GuestId == existingGuest.Id && r.Status == ReservationStatus.CheckedIn))
            {
                ModelState.AddModelError(nameof(vm.GuestContactNumber),
                    "This guest currently has an active check-in and cannot be used for a new reservation until checked out.");
            }

            // Payment validation
            var totalBase = 0m;
            if (vm.IsSeniorCitizen && vm.IsPwd)
            {
                ModelState.AddModelError(nameof(vm.IsPwd), "Select either Senior Citizen or PWD, not both.");
                vm.IsPwd = false; // prefer senior if both somehow sent
            }
            var discountRate = (vm.IsSeniorCitizen || vm.IsPwd) ? 20 : 0;
            foreach (var sel in selectedRooms)
            {
                if (!roomsById.TryGetValue(sel.RoomId, out var room) || room.RoomType == null) continue;
                if (sel.StayType.Equals("Nightly", StringComparison.OrdinalIgnoreCase))
                    totalBase += room.RoomType.GetRateForDuration(24) * Math.Max(1, sel.NumberOfNights);
                else
                    totalBase += room.RoomType.GetRateForDuration(sel.DurationHours);
            }
            if (totalBase <= 0 && selectedRooms.Count > 0)
            {
                ModelState.AddModelError("", "Room rate is ₱0.00. Please set Base Rate / duration rates under Room Type Management, then try again.");
            }
            // Extra persons / beds collected at direct walk-in (₱300 / ₱400 each).
            var extraPersons = Math.Max(0, Math.Min(20, vm.ExtraPersons));
            var extraBeds = Math.Max(0, Math.Min(10, vm.ExtraBeds));
            // Named parameters required — positional call mapped ExtraPersons→extensionCharge.
            var breakdown = _billingSvc.ComputeBreakdown(
                totalBase,
                discountRate,
                extensionCharge: 0m,
                extraPersons: extraPersons,
                extraBeds: extraBeds);
            var totalDue = breakdown.TotalDue;

            if (string.IsNullOrWhiteSpace(vm.PaymentMethod))
            {
                ModelState.AddModelError(nameof(vm.PaymentMethod), "Please select a payment method.");
            }
            else if (!string.Equals(vm.PaymentMethod, "Cash", StringComparison.OrdinalIgnoreCase)
                  && !string.Equals(vm.PaymentMethod, "GCash", StringComparison.OrdinalIgnoreCase))
            {
                ModelState.AddModelError(nameof(vm.PaymentMethod), "Only Cash and GCash are accepted.");
            }
            else if (string.Equals(vm.PaymentMethod, "Cash", StringComparison.OrdinalIgnoreCase))
            {
                if (vm.AmountTendered == null)
                {
                    ModelState.AddModelError(nameof(vm.AmountTendered), "Amount tendered is required for cash payments.");
                }
                else if (vm.AmountTendered.Value < totalDue)
                {
                    ModelState.AddModelError(nameof(vm.AmountTendered), $"Amount tendered must be at least ₱{totalDue:N2}.");
                }
            }
            else if (string.IsNullOrWhiteSpace(vm.PaymentReference))
            {
                ModelState.AddModelError(nameof(vm.PaymentReference), "Reference number is required for this payment method.");
            }

            // Children ages: required when Children > 0; each age must be 1–12 only
            if (vm.Children > 0)
            {
                if (string.IsNullOrWhiteSpace(vm.ChildrenAges))
                {
                    ModelState.AddModelError(nameof(vm.ChildrenAges), "Please select the age of each child (1–12 years).");
                }
                else
                {
                    var ageParts = vm.ChildrenAges.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
                    if (ageParts.Length < vm.Children)
                    {
                        ModelState.AddModelError(nameof(vm.ChildrenAges), $"Please select the age of each child ({vm.Children} required).");
                    }
                    else
                    {
                        foreach (var part in ageParts)
                        {
                            if (!int.TryParse(part, out var age) || age < 1 || age > 12)
                            {
                                ModelState.AddModelError(nameof(vm.ChildrenAges), "Child ages must be between 1 and 12 years only.");
                                break;
                            }
                        }
                    }
                }
            }

            if (!ModelState.IsValid)
            {
                await ReRenderWalkInViewAsync(vm);
                TempData["Error"] = "Please fill in all required fields correctly.";
                return View(vm);
            }

            var guest = existingGuest;

            if (guest != null)
            {
                guest.Nationality = vm.GuestNationality;
                guest.NumberOfGuests = Math.Max(1, vm.Adults + vm.Children);
                guest.Email = vm.GuestEmail;
                guest.IdType = vm.IdType;
                guest.IdNumber = vm.IdNumber;
                guest.IsSeniorCitizen = vm.IsSeniorCitizen;
                guest.IsPwd = vm.IsPwd;
                if (guest.IsArchived)
                {
                    guest.IsArchived = false;
                    guest.ArchivedAt = null;
                }
            }
            else
            {
                guest = new Guest
                {
                    FullName = vm.GuestFullName,
                    ContactNumber = vm.GuestContactNumber,
                    Email = vm.GuestEmail,
                    Nationality = vm.GuestNationality,
                    IdType = vm.IdType,
                    IdNumber = vm.IdNumber,
                    NumberOfGuests = Math.Max(1, vm.Adults + vm.Children),
                    IsSeniorCitizen = vm.IsSeniorCitizen,
                    IsPwd = vm.IsPwd,
                    CreatedAt = DateTime.UtcNow
                };
                _context.Guests.Add(guest);
            }

            var userId = HttpContext.Session.GetInt32("UserId");

            var reservations = new List<Reservation>();
            var referenceNumber = _reservationSvc.GenerateReferenceNumber();
            for (int i = 0; i < selectedRooms.Count; i++)
            {
                var sel = selectedRooms[i];
                var room = roomsById[sel.RoomId];
                var isNightly = sel.StayType.Equals("Nightly", StringComparison.OrdinalIgnoreCase);
                // Per-room occupancy from SelectedRoomsJson; extras only on first room
                // so a multi-room booking does not double-bill Extra Person / Extra Bed.
                var roomAdults = Math.Max(1, sel.Adults > 0 ? sel.Adults : 1);
                var roomChildren = Math.Max(0, sel.Children);
                var roomAges = string.IsNullOrWhiteSpace(sel.ChildrenAges) ? null : sel.ChildrenAges.Trim();
                // Fallback when older JSON lacked per-room occupancy: use form totals on first room only.
                if (sel.Adults <= 0 && i == 0)
                {
                    roomAdults = Math.Max(1, vm.Adults);
                    roomChildren = Math.Max(0, vm.Children);
                    roomAges = string.IsNullOrWhiteSpace(vm.ChildrenAges) ? null : vm.ChildrenAges.Trim();
                }
                var reservation = new Reservation
                {
                    ReferenceNumber = selectedRooms.Count > 1 ? $"{referenceNumber}-{i + 1}" : referenceNumber,
                    Guest = guest,
                    RoomId = sel.RoomId,
                    StayType = isNightly ? StayType.Nightly : StayType.Hourly,
                    GuestCount = Math.Max(1, roomAdults + roomChildren),
                    Adults = roomAdults,
                    Children = roomChildren,
                    ChildrenAges = roomAges,
                    // Nightly stores DurationHours=24 internally; billing uses NumberOfNights.
                    DurationHours = isNightly ? 24 : sel.DurationHours,
                    NumberOfNights = isNightly ? Math.Max(1, sel.NumberOfNights) : 1,
                    ExtraPersons = i == 0 ? Math.Max(0, Math.Min(20, vm.ExtraPersons)) : 0,
                    ExtraBeds = i == 0 ? Math.Max(0, Math.Min(10, vm.ExtraBeds)) : 0,
                    Type = ReservationType.WalkIn,
                    Status = ReservationStatus.Pending,
                    PaymentStatus = PaymentStatus.Unpaid,
                    IsPaymentVerified = false,
                    CreatedByUserId = userId
                };

                // Use the single normalized stay window computed above
                // (nightly = check-in date + N nights at standard checkout time).
                reservation.ExpectedCheckIn = walkInCheckIn;
                reservation.ExpectedCheckOut = walkInCheckOut;
                reservation.CheckInDate = walkInCheckIn.Date;
                reservation.CheckOutDate = walkInCheckOut.Date;

                reservation.Room = room;
                reservations.Add(reservation);
            }

            using var dbTransaction = await _context.Database.BeginTransactionAsync(System.Data.IsolationLevel.Serializable);
            try
            {
                var unavailableRooms = new List<string>();
                var terminalStatuses = new[]
                {
                    ReservationStatus.Cancelled,
                    ReservationStatus.CheckedOut,
                    ReservationStatus.Completed,
                    ReservationStatus.NoShow
                };

                foreach (var sel in selectedRooms)
                {
                    var room = await _context.Rooms.FindAsync(sel.RoomId);
                    if (room == null)
                    {
                        unavailableRooms.Add(sel.RoomNumber ?? $"Room {sel.RoomId}");
                        continue;
                    }

                    var reservationForWindow = reservations.FirstOrDefault(r => r.RoomId == sel.RoomId);
                    var requestedCheckIn = reservationForWindow?.ExpectedCheckIn ?? DateTime.Now;
                    var requestedCheckOut = reservationForWindow?.ExpectedCheckOut ?? requestedCheckIn.AddDays(1);
                    if (!_reservationSvc.IsRoomAvailable(sel.RoomId, requestedCheckIn, requestedCheckOut, reservationForWindow?.Id))
                        unavailableRooms.Add(room.RoomNumber);
                }

                if (unavailableRooms.Any())
                {
                    await dbTransaction.RollbackAsync();
                    ModelState.AddModelError(string.Empty,
                        $"The following room(s) are no longer available: {string.Join(", ", unavailableRooms.Distinct())}. Please select other rooms.");
                    await ReRenderWalkInViewAsync(vm);
                    return View(vm);
                }

                foreach (var reservation in reservations)
                {
                    reservation.Room!.Status = RoomStatus.Reserved;
                    _context.Reservations.Add(reservation);
                }

                await _context.SaveChangesAsync();

                var actualCheckIn = DateTime.Now;
                var totalTendered = string.Equals(vm.PaymentMethod, "Cash", StringComparison.OrdinalIgnoreCase)
                    ? (vm.AmountTendered ?? totalDue)
                    : totalDue;
                var totalChange = totalTendered - totalDue;
                var transactions = new List<Transaction>();
                var allocatedTendered = 0m;

                for (int i = 0; i < reservations.Count; i++)
                {
                    var res = reservations[i];
                    var roomTotalDue = ComputeReservationTotalDue(res);
                    var isLast = i == reservations.Count - 1;
                    var roomAmountTendered = isLast
                        ? totalTendered - allocatedTendered
                        : (totalDue == 0 ? totalTendered / reservations.Count : roomTotalDue);
                    allocatedTendered += roomAmountTendered;
                    var roomChange = isLast ? totalChange : 0m;

                    var tx = await PerformCheckInAsync(
                        res,
                        actualCheckIn,
                        paymentMethod: vm.PaymentMethod,
                        paymentReference: vm.PaymentReference ?? string.Empty,
                        amountTendered: roomAmountTendered,
                        changeAmount: roomChange,
                        amountPaidAtCheckIn: roomTotalDue);
                    if (tx != null) transactions.Add(tx);
                }

                await _context.SaveChangesAsync();
                await dbTransaction.CommitAsync();

                if (transactions.Any())
                {
                    foreach (var tx in transactions)
                    {
                        tx.InvoiceNumber ??= $"INV-{tx.CreatedAt:yyyyMMdd}{tx.Id:D3}";
                    }
                    await _context.SaveChangesAsync();
                }

                TempData["Success"] = reservations.Count == 1
                    ? $"Check-in successful. Reference: {reservations[0].ReferenceNumber}. Room {reservations[0].Room!.RoomNumber} is now Occupied. Guest is now In-House (manage under Front Desk)."
                    : $"Check-in successful for {reservations.Count} rooms. Reference: {referenceNumber}. Guests are now In-House (manage under Front Desk).";

                return RedirectToAction("WalkInReceipt", new { transactionIds = string.Join(",", transactions.Select(t => t.Id)) });
            }
            catch (Exception ex)
            {
                await dbTransaction.RollbackAsync();
                var detail = ex.InnerException != null ? $" {ex.InnerException.Message}" : string.Empty;
                ModelState.AddModelError(string.Empty, $"Could not complete check-in: {ex.Message}{detail}");
                await ReRenderWalkInViewAsync(vm);
                return View(vm);
            }
        }

        private async Task ReRenderWalkInViewAsync(WalkInViewModel vm)
        {
            var now = DateTime.Now;
            // Rebuild availability using the same immediate walk-in window used
            // by the initial GET. Never trust a posted check-in date/time.
            // Nightly window ends at the standard checkout time on the departure date.
            var requestedCheckOut = vm.StayType == WalkInStayType.Nightly
                ? now.Date.AddDays(Math.Max(1, vm.NumberOfNights)).Add(Reservation.NightlyCheckoutTime)
                : now.AddHours(vm.DurationHours is 3 or 12 ? vm.DurationHours : 3);
            var availableRooms = await _reservationSvc.GetAvailableRoomsForWalkInAsync(now, requestedCheckOut);
            // Only rooms from the central availability rule are listed; reserved,
            // occupied, cleaning and maintenance rooms are not shown at all.
            vm.AvailableRoomCards = BuildAvailableRoomCards(vm, availableRooms);
            vm.AvailableRooms = availableRooms.Select(r => new SelectListItem(
                $"Room {r.RoomNumber} – {r.RoomType?.Name ?? "Unknown"} (₱{r.RoomType?.BaseRate ?? 0:N0})",
                r.Id.ToString())).ToList();
            vm.RoomTypeOptions = await _context.RoomTypes
                .OrderBy(rt => rt.Name)
                .Select(rt => new SelectListItem(rt.Name, rt.Id.ToString()))
                .ToListAsync();
            vm.NationalityOptions = GetNationalityOptions();
        }

        // ── Complete Check-In Payment (fallback for pending Walk-In reservations) ──
        [HttpGet]
        public async Task<IActionResult> WalkInPayment(string reservationIds)
        {
            var ids = ParseReservationIds(reservationIds);
            if (!ids.Any()) return BadRequest("No reservations selected.");

            var reservations = await _context.Reservations
                .Include(r => r.Guest)
                .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
                .Where(r => ids.Contains(r.Id) && r.Type == ReservationType.WalkIn && r.Status == ReservationStatus.Pending)
                .ToListAsync();

            if (!reservations.Any()) return NotFound();
            if (reservations.Count != ids.Count)
                TempData["Warning"] = "Some reservations were skipped because they are not pending walk-ins.";

            var total = reservations.Sum(ComputeReservationTotalDue);
            var vm = new WalkInPaymentViewModel
            {
                ReservationIds = reservations.Select(r => r.Id).ToList(),
                Reservations = reservations,
                TotalAmount = total,
                ActualCheckIn = DateTime.Now
            };
            return View(vm);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> WalkInPayment(WalkInPaymentViewModel vm)
        {
            var ids = vm.ReservationIds?.Distinct().ToList() ?? new List<int>();
            if (!ids.Any()) return BadRequest("No reservations selected.");

            var reservations = await _context.Reservations
                .Include(r => r.Guest)
                .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
                .Include(r => r.Transaction)
                .Where(r => ids.Contains(r.Id) && r.Type == ReservationType.WalkIn && r.Status == ReservationStatus.Pending)
                .ToListAsync();

            if (!reservations.Any()) return NotFound();

            var totalDue = reservations.Sum(ComputeReservationTotalDue);
            vm.Reservations = reservations;
            vm.TotalAmount = totalDue;

            // Payment validation: Cash needs amount >= total; non-cash needs a reference.
            if (string.IsNullOrWhiteSpace(vm.PaymentMethod))
            {
                ModelState.AddModelError(nameof(vm.PaymentMethod), "Please select a payment method.");
            }
            else if (!string.Equals(vm.PaymentMethod, "Cash", StringComparison.OrdinalIgnoreCase)
                  && !string.Equals(vm.PaymentMethod, "GCash", StringComparison.OrdinalIgnoreCase))
            {
                ModelState.AddModelError(nameof(vm.PaymentMethod), "Only Cash and GCash are accepted.");
            }
            else if (string.Equals(vm.PaymentMethod, "Cash", StringComparison.OrdinalIgnoreCase))
            {
                if (vm.AmountTendered == null)
                {
                    ModelState.AddModelError(nameof(vm.AmountTendered), "Amount tendered is required for cash payments.");
                }
                else if (vm.AmountTendered.Value < totalDue)
                {
                    ModelState.AddModelError(nameof(vm.AmountTendered), $"Amount tendered must be at least ₱{totalDue:N2}.");
                }
            }
            else if (string.IsNullOrWhiteSpace(vm.PaymentReference))
            {
                ModelState.AddModelError(nameof(vm.PaymentReference), "Reference number is required for this payment method.");
            }

            if (!ModelState.IsValid)
            {
                TempData["Error"] = "Could not process payment. Please check the highlighted fields.";
                return View(vm);
            }

            var actualCheckIn = DateTime.Now;
            var totalTendered = vm.AmountTendered ?? totalDue;
            var totalChange = totalTendered - totalDue;

            // Prevent duplicate payment / check-in if the request is replayed.
            if (reservations.Any(r => r.PaymentStatus == PaymentStatus.Paid || r.Transaction != null))
            {
                TempData["Error"] = "Payment has already been recorded for this walk-in.";
                return RedirectToAction("Index");
            }

            // Concurrency guard: before collecting payment, recheck that every
            // selected room is still available for this walk-in. We run this
            // inside a serializable transaction so another user's claim of the
            // same room is visible and blocks completion.
            using var dbTransaction = await _context.Database.BeginTransactionAsync(System.Data.IsolationLevel.Serializable);

            var unavailableRooms = new List<string>();
            var terminalStatuses = new[]
            {
                ReservationStatus.Cancelled,
                ReservationStatus.CheckedOut,
                ReservationStatus.Completed,
                ReservationStatus.NoShow
            };

            foreach (var res in reservations)
            {
                var room = await _context.Rooms.FindAsync(res.RoomId!.Value);
                if (room == null)
                {
                    unavailableRooms.Add(res.Room?.RoomNumber ?? $"Room {res.RoomId}");
                    continue;
                }

                var requestedCheckIn = res.ExpectedCheckIn ?? DateTime.Now;
                var requestedCheckOut = res.ExpectedCheckOut ?? requestedCheckIn.AddDays(1);
                if (!_reservationSvc.IsRoomAvailable(res.RoomId.Value, requestedCheckIn, requestedCheckOut, res.Id))
                    unavailableRooms.Add(room.RoomNumber);
            }

            if (unavailableRooms.Any())
            {
                await dbTransaction.RollbackAsync();
                ModelState.AddModelError(string.Empty,
                    $"The following room(s) are no longer available: {string.Join(", ", unavailableRooms.Distinct())}. Please go back and select other available rooms.");
                TempData["Error"] = "One or more selected rooms are no longer available.";
                return View(vm);
            }

            var transactions = new List<Transaction>();
            var allocatedTendered = 0m;
            for (int i = 0; i < reservations.Count; i++)
            {
                var res = reservations[i];
                var roomTotalDue = ComputeReservationTotalDue(res);
                var isLast = i == reservations.Count - 1;
                var roomAmountTendered = isLast
                    ? totalTendered - allocatedTendered
                    : (totalDue == 0
                        ? totalTendered / reservations.Count
                        : roomTotalDue);
                allocatedTendered += roomAmountTendered;
                var roomChange = isLast ? totalChange : 0m;

                var tx = await PerformCheckInAsync(
                    res,
                    actualCheckIn,
                    paymentMethod: vm.PaymentMethod,
                    paymentReference: vm.PaymentReference,
                    amountTendered: roomAmountTendered,
                    changeAmount: roomChange,
                    amountPaidAtCheckIn: roomTotalDue);
                if (tx != null) transactions.Add(tx);
            }

            await _context.SaveChangesAsync();
            await dbTransaction.CommitAsync();

            if (transactions.Any())
            {
                foreach (var tx in transactions)
                {
                    tx.InvoiceNumber ??= $"INV-{tx.CreatedAt:yyyyMMdd}{tx.Id:D3}";
                }
                await _context.SaveChangesAsync();
            }

            TempData["Success"] = reservations.Count == 1
                ? $"Guest {reservations[0].Guest.FullName} checked in and payment collected successfully. Guest is now In-House (manage under Front Desk)."
                : $"Walk-in group checked in and payment collected for {reservations.Count} rooms. Guests are now In-House (manage under Front Desk).";

            var transactionIds = string.Join(",", transactions.Select(t => t.Id));
            return RedirectToAction("WalkInReceipt", new { transactionIds });
        }

        // ── Reservation Check-In ─────────────────────────────────────────
        [HttpGet]

        private static string GroupBaseRef(string? rn)
        {
            if (string.IsNullOrEmpty(rn)) return "";
            return System.Text.RegularExpressions.Regex.Replace(rn, @"-\d+$", "");
        }

        private async Task<List<Reservation>> GetGroupSiblingsForCheckInAsync(Reservation res)
        {
            var baseRef = GroupBaseRef(res.ReferenceNumber);
            var siblings = await _context.Reservations
                .Include(r => r.Guest)
                .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
                .Include(r => r.PreferredRoomType)
                .Include(r => r.Transaction)
                .Where(r => r.ReferenceNumber == baseRef
                         || r.ReferenceNumber.StartsWith(baseRef + "-")
                         || (r.SpecialRequests != null && r.SpecialRequests.Contains(baseRef)))
                .OrderBy(r => r.ReferenceNumber)
                .ToListAsync();
            if (!siblings.Any(s => s.Id == res.Id))
                siblings.Insert(0, res);
            return siblings;
        }

        public async Task<IActionResult> CheckIn(int id, int? reservationId = null)
        {
            // Default route is /FrontDesk/CheckIn/{id} — accept both id and reservationId.
            var rid = reservationId is > 0 ? reservationId.Value : id;
            if (rid <= 0) return NotFound();
            var res = await _context.Reservations
                .Include(r => r.Guest)
                .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
                .Include(r => r.PreferredRoomType)
                .Include(r => r.Transaction)
                .FirstOrDefaultAsync(r => r.Id == rid &&
                    (r.Status == ReservationStatus.Reserved || r.Status == ReservationStatus.Confirmed || r.Status == ReservationStatus.Pending));
            if (res == null) return NotFound();

            // Walk-ins have their own explicit payment step that can check
            // in multiple rooms at once. Redirect pending walk-ins there.
            if (res.Type == ReservationType.WalkIn && res.Status == ReservationStatus.Pending)
            {
                var siblingIds = await GetWalkInSiblingIdsAsync(res);
                return RedirectToAction("WalkInPayment", new { reservationIds = string.Join(",", siblingIds) });
            }

            // Preview discount from stored guest flags (form may update them on POST).
            var discountType = res.Guest.IsSeniorCitizen ? DiscountType.SeniorCitizen
                : res.Guest.IsPwd ? DiscountType.PWD : DiscountType.None;

            var (baseRoomCharge, ratePerNight, numberOfNights, durationHours) = ComputeBaseRoomCharge(res);
            var discountRatePercent = GetDiscountRatePercent(discountType);

            var breakdown = _billingSvc.ComputeBreakdown(
                baseRoomCharge,
                discountRatePercent,
                extraPersons: res.ExtraPersons,
                extraBeds: res.ExtraBeds);

            var amountPaid = res.Transaction?.AmountPaidAtCheckIn ?? 0m;
            // Charge balance is pure room/extras due.
            // NEVER trust PaymentStatus alone — a remaining balance may still exist.
            var chargeBalance = Math.Max(0m, breakdown.TotalDue - amountPaid);
            var remaining = chargeBalance;
            var isAlreadyPaid = remaining <= 0m;

            var guest = res.Guest;
            var vm = new CheckInViewModel
            {
                ReservationId = res.Id,
                Reservation = res,
                ActualCheckIn = res.ActualCheckIn ?? DateTime.Now,
                RatePerNight = ratePerNight,
                NumberOfNights = numberOfNights,
                DurationHours = durationHours,
                Subtotal = breakdown.BaseRoomCharge,
                DiscountAmount = breakdown.DiscountAmount,
                ExtraPersons = breakdown.ExtraPersons,
                ExtraBeds = breakdown.ExtraBeds,
                TotalAmount = breakdown.RoomChargesTotal,
                FinalAmount = breakdown.TotalDue,
                DiscountLegalBasis = GetDiscountLegalBasis(discountType),
                PaymentStatus = isAlreadyPaid
                    ? PaymentStatus.Paid
                    : (amountPaid > 0m ? PaymentStatus.PartiallyPaid : PaymentStatus.Unpaid),
                AmountPaid = amountPaid,
                RemainingBalance = remaining,
                IsAlreadyPaid = isAlreadyPaid,
                // Guest verification — same process as Booking / Walk-In
                GuestFullName = guest?.FullName ?? string.Empty,
                GuestContactNumber = guest?.ContactNumber ?? string.Empty,
                GuestEmail = guest?.Email,
                GuestNationality = string.IsNullOrWhiteSpace(guest?.Nationality) ? "Filipino" : guest!.Nationality,
                IdType = guest?.IdType ?? string.Empty,
                IdNumber = guest?.IdNumber ?? string.Empty,
                IsSeniorCitizen = guest?.IsSeniorCitizen ?? false,
                IsPwd = guest?.IsPwd ?? false,
                DiscountIdNumber = guest?.DiscountIdNumber,
                NationalityOptions = GetNationalityOptions()
            };

            // Room dropdown at check-in — same idea as booking: select from vacant rooms
            // of the preferred type (pre-select if already assigned).
            await PopulateCheckInRoomDropdownAsync(vm, res);

            var group = await GetGroupSiblingsForCheckInAsync(res);
            ViewBag.GroupReservations = group;
            ViewBag.IsGroupCheckIn = group.Count > 1;
            ViewBag.GroupRoomLabels = group
                .Where(g => g.Room != null)
                .Select(g => $"Room {g.Room!.RoomNumber} — {g.Room.RoomType?.Name ?? g.PreferredRoomType?.Name ?? "Room"}")
                .ToList();
            // Combined billing for group display
            decimal groupTotal = 0, groupPaid = 0;
            foreach (var g in group)
            {
                var (br, _, _, _) = ComputeBaseRoomCharge(g);
                var dt = g.Guest.IsSeniorCitizen ? DiscountType.SeniorCitizen
                    : g.Guest.IsPwd ? DiscountType.PWD : DiscountType.None;
                var bd = _billingSvc.ComputeBreakdown(br, GetDiscountRatePercent(dt),
                    extraPersons: g.ExtraPersons, extraBeds: g.ExtraBeds);
                groupTotal += bd.TotalDue;
                // Count only actual amounts recorded — not PaymentStatus.Paid flag.
                groupPaid += g.Transaction?.AmountPaidAtCheckIn ?? 0m;
            }
            ViewBag.GroupTotal = groupTotal;
            ViewBag.GroupPaid = groupPaid;
            ViewBag.GroupBalance = Math.Max(0m, groupTotal - groupPaid);
            // Recompute primary "already paid" from group balance so partial
            // Group balance reflects actual collected amounts.
            if (group.Count > 1)
            {
                var groupBal = Math.Max(0m, groupTotal - groupPaid);
                vm.AmountPaid = groupPaid;
                vm.RemainingBalance = groupBal;
                vm.IsAlreadyPaid = groupBal <= 0m;
                vm.PaymentStatus = groupBal <= 0m
                    ? PaymentStatus.Paid
                    : (groupPaid > 0m ? PaymentStatus.PartiallyPaid : PaymentStatus.Unpaid);
            }

            return View(vm);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> CheckIn(CheckInViewModel vm)
        {
            var res = await _context.Reservations
                .Include(r => r.Guest)
                .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
                .Include(r => r.PreferredRoomType)
                .Include(r => r.Transaction)
                .FirstOrDefaultAsync(r => r.Id == vm.ReservationId);
            if (res == null) return NotFound();

            if (res.Status == ReservationStatus.CheckedIn
                || res.Status == ReservationStatus.CheckedOut
                || res.Status == ReservationStatus.Completed
                || res.Status == ReservationStatus.Cancelled
                || res.Status == ReservationStatus.NoShow)
            {
                TempData["Error"] = res.Status == ReservationStatus.CheckedIn
                    ? "This reservation has already been checked in."
                    : $"Cannot check in a reservation with status '{res.Status}' from this screen.";
                return RedirectToAction("Details", "Reservation", new { id = res.Id });
            }

            // Early check-in is allowed, but it must not move the guest's
            // original reserved check-out date. Also reject a check-in that
            // happens after the reservation's scheduled departure.
            if (res.Type != ReservationType.WalkIn)
            {
                var scheduledCheckOut = GetScheduledCheckOutForCheckIn(res);
                if (vm.ActualCheckIn >= scheduledCheckOut)
                {
                    TempData["Error"] = $"This reservation's scheduled check-out is {scheduledCheckOut:MMM dd, yyyy h:mm tt}. Please reschedule the reservation before checking in.";
                    return RedirectToAction("Details", "Reservation", new { id = res.Id });
                }
            }

            // ── Guest verification (same process as Booking / Walk-In) ──
            // Staff re-confirm identity and discount eligibility at the desk.
            vm.GuestFullName = (vm.GuestFullName ?? string.Empty).Trim();
            vm.GuestContactNumber = (vm.GuestContactNumber ?? string.Empty).Trim();
            vm.GuestEmail = string.IsNullOrWhiteSpace(vm.GuestEmail) ? null : vm.GuestEmail.Trim();
            vm.GuestNationality = string.IsNullOrWhiteSpace(vm.GuestNationality) ? "Filipino" : vm.GuestNationality.Trim();
            vm.IdType = (vm.IdType ?? string.Empty).Trim();
            vm.IdNumber = (vm.IdNumber ?? string.Empty).Trim();
            vm.DiscountIdNumber = string.IsNullOrWhiteSpace(vm.DiscountIdNumber) ? null : vm.DiscountIdNumber.Trim();

            // Guest verification at the desk: name, contact, and Government ID required at check-in.
            if (string.IsNullOrWhiteSpace(vm.GuestFullName))
                ModelState.AddModelError(nameof(vm.GuestFullName), "Guest full name is required.");
            if (string.IsNullOrWhiteSpace(vm.GuestContactNumber))
                ModelState.AddModelError(nameof(vm.GuestContactNumber), "Contact number is required.");
            if (string.IsNullOrWhiteSpace(vm.IdType))
                ModelState.AddModelError(nameof(vm.IdType), "Government ID Type is required at check-in.");
            if (string.IsNullOrWhiteSpace(vm.IdNumber))
                ModelState.AddModelError(nameof(vm.IdNumber), "ID Number is required at check-in.");
            // Senior and PWD are mutually exclusive for a single guest record.
            if (vm.IsSeniorCitizen && vm.IsPwd)
            {
                ModelState.AddModelError(nameof(vm.IsPwd), "Select either Senior Citizen or PWD, not both.");
            }

            if (res.Guest != null && ModelState.IsValid)
            {
                res.Guest.FullName = vm.GuestFullName;
                res.Guest.ContactNumber = vm.GuestContactNumber;
                res.Guest.Email = vm.GuestEmail;
                res.Guest.Nationality = vm.GuestNationality;
                res.Guest.IdType = vm.IdType;
                res.Guest.IdNumber = vm.IdNumber;
                res.Guest.IsSeniorCitizen = vm.IsSeniorCitizen;
                res.Guest.IsPwd = vm.IsPwd;
                res.Guest.DiscountIdNumber = vm.DiscountIdNumber;
            }

            // Assign physical room(s) at check-in.
            // Single-room: AssignedRoomId. Multi-room group: GroupRoomAssignments
            // (one dropdown per sibling — required for online multi-room TBA holds).
            //
            // IMPORTANT: the room must be free at the ACTUAL check-in time.
            // This protects advance reservations from being checked in early
            // into a room that is still occupied by another guest.
            var groupForAssign = await GetGroupSiblingsForCheckInAsync(res);
            var isGroupAssign = groupForAssign.Count > 1
                && vm.GroupRoomAssignments != null
                && vm.GroupRoomAssignments.Count > 0;

            if (isGroupAssign)
            {
                // Sync primary from the group list if staff used the multi-row UI.
                var primaryRow = vm.GroupRoomAssignments!
                    .FirstOrDefault(g => g.ReservationId == res.Id);
                if (primaryRow?.AssignedRoomId is > 0)
                    vm.AssignedRoomId = primaryRow.AssignedRoomId;

                var usedRoomIds = new HashSet<int>();
                foreach (var item in vm.GroupRoomAssignments!)
                {
                    var sib = groupForAssign.FirstOrDefault(g => g.Id == item.ReservationId);
                    if (sib == null) continue;
                    if (item.AssignedRoomId is null or <= 0)
                    {
                        ModelState.AddModelError(nameof(vm.GroupRoomAssignments),
                            $"Please assign a room for {item.ReferenceNumber}.");
                        continue;
                    }
                    if (!usedRoomIds.Add(item.AssignedRoomId.Value))
                    {
                        ModelState.AddModelError(nameof(vm.GroupRoomAssignments),
                            $"Room was selected more than once. Each room in the group needs a different room number.");
                        continue;
                    }
                    var room = await _context.Rooms.Include(r => r.RoomType)
                        .FirstOrDefaultAsync(r => r.Id == item.AssignedRoomId.Value);
                    if (room == null)
                    {
                        ModelState.AddModelError(nameof(vm.GroupRoomAssignments),
                            $"Selected room for {item.ReferenceNumber} was not found.");
                        continue;
                    }
                    if (room.Status == RoomStatus.Occupied && sib.RoomId != room.Id)
                    {
                        ModelState.AddModelError(nameof(vm.GroupRoomAssignments),
                            $"Room {room.RoomNumber} is already occupied.");
                        continue;
                    }
                    var expectedType = sib.PreferredRoomTypeId ?? sib.Room?.RoomTypeId;
                    if (expectedType.HasValue && room.RoomTypeId != expectedType.Value)
                    {
                        ModelState.AddModelError(nameof(vm.GroupRoomAssignments),
                            $"Please choose a matching room type for {item.ReferenceNumber}.");
                        continue;
                    }

                    var sibCheckIn = vm.ActualCheckIn;
                    var sibCheckOut = GetScheduledCheckOutForCheckIn(sib);
                    if (!_reservationSvc.IsRoomAvailable(
                            room.Id, sibCheckIn, sibCheckOut, excludeReservationId: sib.Id))
                    {
                        ModelState.AddModelError(nameof(vm.GroupRoomAssignments),
                            $"Room {room.RoomNumber} is not available at the actual check-in time ({sibCheckIn:g}). It is occupied or has an overlapping reservation.");
                        continue;
                    }

                    sib.RoomId = room.Id;
                    sib.Room = room;
                    if (sib.PreferredRoomTypeId == null)
                        sib.PreferredRoomTypeId = room.RoomTypeId;
                    if (sib.Id == res.Id)
                    {
                        res.RoomId = room.Id;
                        res.Room = room;
                        vm.AssignedRoomId = room.Id;
                    }
                }
            }
            else
            {
                var assignId = vm.AssignedRoomId ?? res.RoomId;
                if (assignId == null || assignId <= 0)
                {
                    ModelState.AddModelError(nameof(vm.AssignedRoomId), "Please assign a room for this guest.");
                }
                else
                {
                    var room = await _context.Rooms.Include(r => r.RoomType).FirstOrDefaultAsync(r => r.Id == assignId);
                    if (room == null)
                    {
                        ModelState.AddModelError(nameof(vm.AssignedRoomId), "Selected room was not found.");
                    }
                    else if (room.Status == RoomStatus.Occupied && res.RoomId != room.Id)
                    {
                        ModelState.AddModelError(nameof(vm.AssignedRoomId), $"Room {room.RoomNumber} is already occupied.");
                    }
                    else if (res.PreferredRoomTypeId.HasValue && room.RoomTypeId != res.PreferredRoomTypeId.Value)
                    {
                        ModelState.AddModelError(nameof(vm.AssignedRoomId),
                            $"Please choose a {res.PreferredRoomType?.Name ?? "matching"} room.");
                    }
                    else if (!_reservationSvc.IsRoomAvailable(
                        room.Id, vm.ActualCheckIn, GetScheduledCheckOutForCheckIn(res), res.Id))
                    {
                        ModelState.AddModelError(nameof(vm.AssignedRoomId),
                            $"Room {room.RoomNumber} is not available at the actual check-in time ({vm.ActualCheckIn:g}). It is occupied or has an overlapping reservation.");
                    }
                    else
                    {
                        res.RoomId = room.Id;
                        res.Room = room;
                        if (res.PreferredRoomTypeId == null)
                            res.PreferredRoomTypeId = room.RoomTypeId;
                    }
                }
            }

            // Extra Persons / Extra Beds are set here, at Check-In, and only
            // here — this is the single point where the count gets written
            // to the Reservation. Once checked in there is no other screen
            // that can change it.
            res.ExtraPersons = Math.Max(0, Math.Min(20, vm.ExtraPersons));
            res.ExtraBeds = Math.Max(0, Math.Min(10, vm.ExtraBeds));

            var discountType = res.Guest?.IsSeniorCitizen == true ? DiscountType.SeniorCitizen
                : res.Guest?.IsPwd == true ? DiscountType.PWD : DiscountType.None;

            var (baseRoomCharge, ratePerNight, numberOfNights, durationHours) = ComputeBaseRoomCharge(res);
            var discountRatePercent = GetDiscountRatePercent(discountType);

            var breakdown = _billingSvc.ComputeBreakdown(
                baseRoomCharge,
                discountRatePercent,
                extraPersons: res.ExtraPersons,
                extraBeds: res.ExtraBeds);

            // Guard against zero-price check-in (missing RoomType rates or unloaded nav props).
            if (baseRoomCharge <= 0 && res.PaymentStatus != PaymentStatus.Paid)
            {
                ModelState.AddModelError("", "Room rate is ₱0.00. Assign a room with valid rates (or set rates under Room Type Management) before completing check-in.");
            }

            if (!ModelState.IsValid)
            {
                vm.Reservation = res;
                vm.RatePerNight = ratePerNight;
                vm.NumberOfNights = numberOfNights;
                vm.DurationHours = durationHours;
                vm.Subtotal = breakdown.BaseRoomCharge;
                vm.DiscountAmount = breakdown.DiscountAmount;
                vm.ExtraPersons = breakdown.ExtraPersons;
                vm.ExtraBeds = breakdown.ExtraBeds;
                vm.TotalAmount = breakdown.RoomChargesTotal;
                vm.FinalAmount = breakdown.TotalDue;
                vm.DiscountLegalBasis = GetDiscountLegalBasis(discountType);
                TempData["Error"] = "Could not process check-in. Please check the highlighted fields.";
                vm.NationalityOptions = GetNationalityOptions();
                await PopulateCheckInRoomDropdownAsync(vm, res);
                return View(vm);
            }

            // Payment at check-in: for multi-room groups use combined balance so
            // one payment of e.g. ₱1,600 covers both rooms and yields one receipt.
            var groupForPay = await GetGroupSiblingsForCheckInAsync(res);
            decimal groupTotalDue = 0, groupAlreadyPaid = 0;
            foreach (var g in groupForPay)
            {
                if (g.Transaction == null)
                    await _context.Entry(g).Reference(r => r.Transaction).LoadAsync();
                if (g.Room?.RoomType == null && g.RoomId != null)
                {
                    await _context.Entry(g).Reference(r => r.Room).LoadAsync();
                    if (g.Room != null)
                        await _context.Entry(g.Room).Reference(rm => rm.RoomType).LoadAsync();
                }
                if (g.PreferredRoomType == null && g.PreferredRoomTypeId != null)
                    await _context.Entry(g).Reference(r => r.PreferredRoomType).LoadAsync();
                if (g.Guest == null)
                    await _context.Entry(g).Reference(r => r.Guest).LoadAsync();

                var (gBase, _, _, _) = ComputeBaseRoomCharge(g);
                var gDt = g.Guest != null && g.Guest.IsSeniorCitizen ? DiscountType.SeniorCitizen
                    : g.Guest != null && g.Guest.IsPwd ? DiscountType.PWD : DiscountType.None;
                var gBd = _billingSvc.ComputeBreakdown(gBase, GetDiscountRatePercent(gDt),
                    extraPersons: g.ExtraPersons, extraBeds: g.ExtraBeds);
                groupTotalDue += gBd.TotalDue;
                // Actual pesos only — ignore PaymentStatus.Paid when calculating balance.
                groupAlreadyPaid += g.Transaction?.AmountPaidAtCheckIn ?? 0m;
            }
            var amountPaid = res.Transaction?.AmountPaidAtCheckIn ?? 0m;
            var chargeBalance = Math.Max(0m, breakdown.TotalDue - amountPaid);
            var groupRemaining = Math.Max(0m, groupTotalDue - groupAlreadyPaid);
            // Collect against group remaining when multi-room; else this room only.
            // Fully paid ONLY when remaining is zero — never trust status flags alone.
            var remaining = groupForPay.Count > 1 ? groupRemaining : chargeBalance;
            var isAlreadyPaid = remaining <= 0m;

            if (!isAlreadyPaid)
            {
                if (string.IsNullOrWhiteSpace(vm.PaymentMethod))
                {
                    ModelState.AddModelError(nameof(vm.PaymentMethod), "Please select a payment method.");
                }
                else if (string.Equals(vm.PaymentMethod, "Cash", StringComparison.OrdinalIgnoreCase))
                {
                    if (vm.AmountTendered == null)
                    {
                        ModelState.AddModelError(nameof(vm.AmountTendered), "Amount tendered is required for cash payments.");
                    }
                    else if (vm.AmountTendered.Value < remaining)
                    {
                        ModelState.AddModelError(nameof(vm.AmountTendered), $"Amount tendered must be at least ₱{remaining:N2}.");
                    }
                }
                else if (string.IsNullOrWhiteSpace(vm.PaymentReference))
                {
                    ModelState.AddModelError(nameof(vm.PaymentReference), "Reference number is required for non-cash payments.");
                }

                if (!ModelState.IsValid)
                {
                    vm.Reservation = res;
                    vm.RatePerNight = ratePerNight;
                    vm.NumberOfNights = numberOfNights;
                    vm.DurationHours = durationHours;
                    vm.Subtotal = breakdown.BaseRoomCharge;
                    vm.DiscountAmount = breakdown.DiscountAmount;
                    vm.ExtraPersons = breakdown.ExtraPersons;
                    vm.ExtraBeds = breakdown.ExtraBeds;
                    vm.TotalAmount = breakdown.RoomChargesTotal;
                    vm.FinalAmount = breakdown.TotalDue;
                    vm.DiscountLegalBasis = GetDiscountLegalBasis(discountType);
                    vm.PaymentStatus = PaymentStatus.Unpaid;
                    vm.AmountPaid = amountPaid;
                     vm.RemainingBalance = remaining;
                     vm.IsAlreadyPaid = false;
                    TempData["Error"] = "Could not process check-in. Please check the highlighted fields.";
                    vm.NationalityOptions = GetNationalityOptions();
                    await PopulateCheckInRoomDropdownAsync(vm, res);
                    return View(vm);
                }
            }

            // Per-room due for primary (for allocation of group payment)
            decimal RoomDue(Reservation r)
            {
                var (b, _, _, _) = ComputeBaseRoomCharge(r);
                var dt = r.Guest != null && r.Guest.IsSeniorCitizen ? DiscountType.SeniorCitizen
                    : r.Guest != null && r.Guest.IsPwd ? DiscountType.PWD : DiscountType.None;
                return _billingSvc.ComputeBreakdown(b, GetDiscountRatePercent(dt),
                    extraPersons: r.ExtraPersons, extraBeds: r.ExtraBeds).TotalDue;
            }
            var primaryDue = RoomDue(res);
            var primaryAlready = res.Transaction?.AmountPaidAtCheckIn ?? 0m;
            var primaryNeed = Math.Max(0m, primaryDue - primaryAlready);
            // amountPaidAtCheckIn stored on Transaction is the TOTAL collected for this room
            // Store the total amount collected for this room. When collecting remaining, set full due.
            var primaryPay = isAlreadyPaid
                ? Math.Max(primaryAlready, primaryDue)
                : primaryDue;

            var transaction = await PerformCheckInAsync(
                res,
                vm.ActualCheckIn,
                paymentMethod: vm.PaymentMethod,
                paymentReference: vm.PaymentReference,
                amountTendered: groupForPay.Count > 1 ? null : vm.AmountTendered,
                changeAmount: groupForPay.Count > 1 ? null
                    : (vm.AmountTendered.HasValue ? vm.AmountTendered.Value - remaining : null),
                amountPaidAtCheckIn: primaryPay,
                isAlreadyPaidOverride: isAlreadyPaid || primaryNeed <= 0);

            // Group: check in sibling rooms with room assigned → one combined receipt
            var groupSiblings = groupForPay;
            var allTx = new List<Transaction>();
            if (transaction != null) allTx.Add(transaction);

            var changeLeft = groupForPay.Count > 1 && vm.AmountTendered.HasValue
                ? Math.Max(0m, vm.AmountTendered.Value - remaining)
                : 0m;

            foreach (var sib in groupSiblings.Where(s => s.Id != res.Id
                && s.RoomId != null
                && (s.Status == ReservationStatus.Pending
                    || s.Status == ReservationStatus.Confirmed
                    || s.Status == ReservationStatus.Reserved)))
            {
                if (sib.Transaction == null)
                    await _context.Entry(sib).Reference(r => r.Transaction).LoadAsync();
                if (sib.Guest == null)
                    await _context.Entry(sib).Reference(r => r.Guest).LoadAsync();
                if (sib.Room == null)
                    await _context.Entry(sib).Reference(r => r.Room).LoadAsync();
                if (sib.Room != null && sib.Room.RoomType == null)
                    await _context.Entry(sib.Room).Reference(rm => rm.RoomType).LoadAsync();
                if (sib.PreferredRoomType == null && sib.PreferredRoomTypeId != null)
                    await _context.Entry(sib).Reference(r => r.PreferredRoomType).LoadAsync();

                var sibDue = RoomDue(sib);
                var sibAlready = sib.Transaction?.AmountPaidAtCheckIn ?? 0m;
                var sibNeed = Math.Max(0m, sibDue - sibAlready);
                // TOTAL collected for sibling after this check-in (never invent payment when already paid).
                var sibPay = isAlreadyPaid
                    ? Math.Max(sibAlready, sibDue)
                    : sibDue;

                var sibTx = await PerformCheckInAsync(
                    sib,
                    vm.ActualCheckIn,
                    paymentMethod: vm.PaymentMethod,
                    paymentReference: vm.PaymentReference,
                    amountTendered: null,
                    changeAmount: changeLeft > 0 ? changeLeft : null,
                    amountPaidAtCheckIn: sibPay,
                    isAlreadyPaidOverride: isAlreadyPaid || sibNeed <= 0);
                changeLeft = 0;
                if (sibTx != null) allTx.Add(sibTx);
            }

            await _context.SaveChangesAsync();

            foreach (var tx in allTx)
            {
                tx.InvoiceNumber ??= $"INV-{tx.CreatedAt:yyyyMMdd}{tx.Id:D3}";
            }
            if (allTx.Any())
                await _context.SaveChangesAsync();

            await _audit.LogAsync("check_in", "reservation", res.Id, res.ReferenceNumber);
            var guestName = res.Guest?.FullName ?? "Guest";
            TempData["Success"] = allTx.Count > 1
                ? $"Group check-in: {guestName} — {allTx.Count} rooms. Combined receipt. Guests are now In-House (manage under Front Desk)."
                : (isAlreadyPaid
                    ? $"Guest {guestName} checked in successfully. Payment was already completed. Guest is now In-House (manage under Front Desk)."
                    : $"Guest {guestName} checked in and payment collected successfully. Guest is now In-House (manage under Front Desk).");

            // 2+ rooms → one combined receipt; single room → normal receipt.
            // Never send staff back to Reservation after check-in — guest is
            // now In-House and belongs under Front Desk.
            if (allTx.Count > 1)
                return RedirectToAction("WalkInReceipt", new { transactionIds = string.Join(",", allTx.Select(t => t.Id)) });
            if (transaction != null)
                return RedirectToAction("Receipt", new { transactionId = transaction.Id });
            return RedirectToAction("Index");
        }

        // ── Extend Stay (approved extension for checked-in guests) ──────────
        // Supports single-room and multi-room group extend under one base
        // reference. Conflict check runs per physical room against the
         // proposed extension window [current ECO, new ECO).
        [HttpGet]
        public async Task<IActionResult> ExtendStay(int id, int? reservationId = null)
        {
            var rid = reservationId is > 0 ? reservationId.Value : id;
            if (rid <= 0) return NotFound();

            var res = await _context.Reservations
                .Include(r => r.Guest)
                .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
                .Include(r => r.PreferredRoomType)
                .Include(r => r.Transaction)
                .FirstOrDefaultAsync(r => r.Id == rid);
            if (res == null) return NotFound();

            if (res.Status != ReservationStatus.CheckedIn)
            {
                TempData["Error"] = "Extend Stay is only available for checked-in guests.";
                return RedirectToAction(nameof(Index), "FrontDesk", new { mode = "checkin" }, "inhouse-checkin");
            }

            if (res.ExpectedCheckOut == null)
            {
                TempData["Error"] = "Expected check-out is not set.";
                return RedirectToAction(nameof(Index), "FrontDesk", new { mode = "checkin" }, "inhouse-checkin");
            }

            if (res.Room == null || res.Room.RoomType == null)
            {
                TempData["Error"] = "A physical room must be assigned before extending stay.";
                return RedirectToAction(nameof(Index), "FrontDesk", new { mode = "checkin" }, "inhouse-checkin");
            }

            // Nightly extension = full night rate (Alemar BaseRate / defaults).
            // Hourly extension = per-hour extra rate from Room Type (Alemar defaults if DB is 0).
            var rate = res.IsNightlyStay
                ? res.Room.RoomType.GetRateForDuration(24)
                : res.Room.RoomType.GetExtraHourRateForDuration(res.DurationHours);

            var group = await GetGroupSiblingsForCheckInAsync(res);
            var checkedInSiblings = group
                .Where(s => s.Status == ReservationStatus.CheckedIn
                         && s.Room != null
                         && s.Room.RoomType != null
                         && s.ExpectedCheckOut.HasValue)
                .ToList();

            var vm = new ExtendStayViewModel
            {
                ReservationId = res.Id,
                Reservation = res,
                GuestName = res.Guest?.FullName ?? "—",
                RoomInfo = $"Room {res.Room.RoomNumber} — {res.Room.RoomType.Name}",
                IsNightlyStay = res.IsNightlyStay,
                CurrentExpectedCheckOut = res.ExpectedCheckOut,
                Rate = rate,
                ExtensionValue = 1,
                ExtensionCharge = rate,
                IsGroup = checkedInSiblings.Count > 1,
                GroupBaseReference = GroupBaseRef(res.ReferenceNumber),
                GroupRooms = checkedInSiblings.Select(s =>
                {
                    var sRate = s.IsNightlyStay
                        ? s.Room!.RoomType!.GetRateForDuration(24)
                        : s.Room!.RoomType!.GetExtraHourRateForDuration(s.DurationHours);
                    return new GroupExtendRoomItem
                    {
                        ReservationId = s.Id,
                        ReferenceNumber = s.ReferenceNumber,
                        RoomLabel = $"Room {s.Room!.RoomNumber} — {s.Room.RoomType!.Name}",
                        CurrentExpectedCheckOut = s.ExpectedCheckOut,
                        Rate = sRate,
                        IsNightlyStay = s.IsNightlyStay,
                        Selected = true
                    };
                }).ToList(),
                SelectedReservationIds = checkedInSiblings.Select(s => s.Id).ToList()
            };
            return View(vm);
        }

        // Live preview used by the Extend Stay page: tells the front desk BEFORE
        // confirming whether the extension collides with another booking on the
        // same physical room, who holds it, and which room the guest would move to.
        [HttpGet]
        public async Task<IActionResult> ExtendConflictCheck(int id, int value)
        {
            var res = await _context.Reservations
                .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
                .FirstOrDefaultAsync(r => r.Id == id);
            if (res == null || res.Room == null || !res.ExpectedCheckOut.HasValue || value < 1)
                return Json(new { conflict = false });

            var currentEco = res.ExpectedCheckOut.Value;
            var newEco = res.IsNightlyStay ? currentEco.AddDays(value) : currentEco.AddHours(value);

            if (_reservationSvc.IsRoomAvailable(res.RoomId!.Value, currentEco, newEco, res.Id))
                return Json(new { conflict = false });

            var blockers = await _context.Reservations
                .Include(r => r.Guest)
                .Where(r => r.RoomId == res.RoomId && r.Id != res.Id
                    && r.Status != ReservationStatus.Cancelled
                    && r.Status != ReservationStatus.CheckedOut
                    && r.Status != ReservationStatus.Completed
                    && r.Status != ReservationStatus.NoShow)
                .ToListAsync();

            var blocker = blockers
                .Select(b =>
                {
                    var st = b.ExpectedCheckIn ?? b.CheckInDate ?? DateTime.MinValue;
                    var en = b.ExpectedCheckOut ?? b.CheckOutDate ?? st.AddDays(1);
                    if (en <= st) en = st.AddDays(1);
                    return new { b, st, en };
                })
                .Where(x => x.st < newEco && x.en > currentEco)
                .OrderBy(x => x.st)
                .FirstOrDefault();

            var from = DateTime.Now;
            if (res.ActualCheckIn.HasValue && res.ActualCheckIn.Value < from) from = res.ActualCheckIn.Value;
            var alt = await FindAlternativeRoomForExtendAsync(
                res.Room.RoomTypeId, from, newEco, res.Id, res.RoomId, new HashSet<int>());

            return Json(new
            {
                conflict = true,
                room = res.Room.RoomNumber,
                blockerGuest = blocker?.b.Guest?.FullName ?? "another guest",
                blockerRef = blocker?.b.ReferenceNumber,
                blockerFrom = blocker?.st.ToString("MMM dd, yyyy h:mm tt"),
                blockerTo = blocker?.en.ToString("MMM dd, yyyy h:mm tt"),
                alternativeRoom = alt?.RoomNumber
            });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> ExtendStay(ExtendStayViewModel vm)
        {
            var primary = await _context.Reservations
                .Include(r => r.Guest)
                .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
                .Include(r => r.Transaction)
                .FirstOrDefaultAsync(r => r.Id == vm.ReservationId);
            if (primary == null) return NotFound();

            // Rebuild group context for redisplay / processing
            var group = await GetGroupSiblingsForCheckInAsync(primary);
            var checkedInSiblings = group
                .Where(s => s.Status == ReservationStatus.CheckedIn
                         && s.Room != null
                         && s.Room.RoomType != null
                         && s.ExpectedCheckOut.HasValue
                         && s.Transaction != null)
                .ToList();

            // Which rooms to extend: posted selection, or fall back to primary only
            var selectedIds = (vm.SelectedReservationIds != null && vm.SelectedReservationIds.Any())
                ? vm.SelectedReservationIds.Distinct().ToList()
                : new List<int> { primary.Id };

            var toExtend = checkedInSiblings
                .Where(s => selectedIds.Contains(s.Id))
                .ToList();

            if (!toExtend.Any())
            {
                ModelState.AddModelError(string.Empty, "Select at least one room to extend.");
            }

            // Validate extension value against primary stay type (group assumed same stay type)
            var isNightly = primary.IsNightlyStay;
            if (isNightly && (vm.ExtensionValue < 1 || vm.ExtensionValue > 30))
                ModelState.AddModelError(nameof(vm.ExtensionValue), "Nights to add must be between 1 and 30.");
            else if (!isNightly && (vm.ExtensionValue < 1 || vm.ExtensionValue > 72))
                ModelState.AddModelError(nameof(vm.ExtensionValue), "Hours to add must be between 1 and 72.");

            // Rebuild VM display fields
            var primaryRate = primary.Room != null && primary.Room.RoomType != null
                ? (isNightly
                    ? primary.Room.RoomType.GetRateForDuration(24)
                    : primary.Room.RoomType.GetExtraHourRateForDuration(primary.DurationHours))
                : 0m;
            vm.Reservation = primary;
            vm.GuestName = primary.Guest?.FullName ?? "—";
            vm.RoomInfo = primary.Room != null
                ? $"Room {primary.Room.RoomNumber} — {primary.Room.RoomType?.Name}"
                : "—";
            vm.IsNightlyStay = isNightly;
            vm.CurrentExpectedCheckOut = primary.ExpectedCheckOut;
            vm.Rate = primaryRate;
            vm.ExtensionCharge = primaryRate * vm.ExtensionValue;
            vm.IsGroup = checkedInSiblings.Count > 1;
            vm.GroupBaseReference = GroupBaseRef(primary.ReferenceNumber);
            vm.GroupRooms = checkedInSiblings.Select(s =>
            {
                var sRate = s.IsNightlyStay
                    ? s.Room!.RoomType!.GetRateForDuration(24)
                    : s.Room!.RoomType!.GetExtraHourRateForDuration(s.DurationHours);
                return new GroupExtendRoomItem
                {
                    ReservationId = s.Id,
                    ReferenceNumber = s.ReferenceNumber,
                    RoomLabel = $"Room {s.Room!.RoomNumber} — {s.Room.RoomType!.Name}",
                    CurrentExpectedCheckOut = s.ExpectedCheckOut,
                    Rate = sRate,
                    IsNightlyStay = s.IsNightlyStay,
                    Selected = selectedIds.Contains(s.Id)
                };
            }).ToList();

            if (!ModelState.IsValid)
            {
                TempData["Error"] = "Please correct the highlighted fields.";
                return View(vm);
            }

            // ── Conflict check + automatic resolution ─────────────────────
            // Extension window: [current ExpectedCheckOut, new ExpectedCheckOut).
            // Conflict = another non-terminal reservation overlaps that window
            // on the same physical room.
            //
            // Auto-resolve (default ON): move the CheckedIn guest to another
            // available room of the SAME type that is free for [now → new ECO],
            // then extend. Old room → ForCleaning; new room → Occupied.
            var unresolvedConflicts = new List<string>();
            var resolvedMoves = new List<string>();
            var okToExtend = new List<Reservation>();
            // Rooms already chosen as alternatives in this batch (avoid double-assign)
            var claimedAlternativeIds = new HashSet<int>();

            foreach (var res in toExtend)
            {
                var currentEco = res.ExpectedCheckOut!.Value;
                var newEco = isNightly
                    ? currentEco.AddDays(vm.ExtensionValue)
                    : currentEco.AddHours(vm.ExtensionValue);

                var available = _reservationSvc.IsRoomAvailable(
                    res.RoomId!.Value,
                    currentEco,
                    newEco,
                    excludeReservationId: res.Id);

                if (available)
                {
                    okToExtend.Add(res);
                    continue;
                }

                // Conflict detected
                var conflictMsg =
                    $"{res.Room!.RoomNumber} ({res.ReferenceNumber}): another reservation overlaps the extension period ending {newEco:MMM dd, yyyy h:mm tt}.";
                var item = vm.GroupRooms.FirstOrDefault(g => g.ReservationId == res.Id);
                if (item != null)
                {
                    item.HasConflict = true;
                    item.ConflictMessage = conflictMsg;
                }

                if (!vm.AutoResolveConflicts)
                {
                    unresolvedConflicts.Add(conflictMsg);
                    continue;
                }

                // Never move a checked-in guest silently: the front desk must
                // tick the confirmation shown on the Extend Stay page.
                if (!vm.ConfirmRoomMove)
                {
                    unresolvedConflicts.Add(conflictMsg + " Room move was not confirmed.");
                    continue;
                }

                // Auto-resolve: find another room of the same type free for the
                // remaining stay through the new check-out (guest must move now
                // so the original room is free for the overlapping booking).
                var roomTypeId = res.Room!.RoomTypeId;
                var from = DateTime.Now;
                if (res.ActualCheckIn.HasValue && res.ActualCheckIn.Value < from)
                    from = res.ActualCheckIn.Value;

                var alternative = await FindAlternativeRoomForExtendAsync(
                    roomTypeId,
                    from,
                    newEco,
                    excludeReservationId: res.Id,
                    excludeRoomId: res.RoomId,
                    alreadyClaimed: claimedAlternativeIds);

                if (alternative == null)
                {
                    unresolvedConflicts.Add(conflictMsg + " No alternative room of the same type is available.");
                    continue;
                }

                // Perform room transfer
                var oldRoom = res.Room;
                var oldNumber = oldRoom.RoomNumber;
                oldRoom.Status = RoomStatus.ForCleaning;
                alternative.Status = RoomStatus.Occupied;
                res.RoomId = alternative.Id;
                res.Room = alternative;
                // Keep PreferredRoomType aligned if it was null
                if (res.PreferredRoomTypeId == null)
                    res.PreferredRoomTypeId = alternative.RoomTypeId;

                claimedAlternativeIds.Add(alternative.Id);
                okToExtend.Add(res);

                var moveMsg = $"{oldNumber} → {alternative.RoomNumber} ({res.ReferenceNumber})";
                resolvedMoves.Add(moveMsg);
                if (item != null)
                    item.ResolvedToRoom = alternative.RoomNumber;
            }

            if (!okToExtend.Any())
            {
                ModelState.AddModelError(string.Empty,
                    "Cannot extend: every selected room has a conflicting reservation and no alternative room of the same type was available. " +
                    string.Join(" ", unresolvedConflicts));
                TempData["Error"] = "Extension blocked due to unresolved room conflicts.";
                return View(vm);
            }

            // Apply extension to rooms that are clear (or were auto-moved)
            decimal totalExtensionCharge = 0m;
            var extendedLabels = new List<string>();

            foreach (var res in okToExtend)
            {
                // Rate from the (possibly new) room type — Alemar rates via GetRateForDuration / GetExtraHourRateForDuration
                var rate = res.IsNightlyStay
                    ? res.Room!.RoomType!.GetRateForDuration(24)
                    : res.Room!.RoomType!.GetExtraHourRateForDuration(res.DurationHours);
                var extensionCharge = rate * vm.ExtensionValue;

                res.ExpectedCheckOut = res.IsNightlyStay
                    ? res.ExpectedCheckOut!.Value.AddDays(vm.ExtensionValue)
                    : res.ExpectedCheckOut!.Value.AddHours(vm.ExtensionValue);

                if (res.IsNightlyStay)
                    res.ExtendedNights += vm.ExtensionValue;
                else
                    res.ExtendedHours += vm.ExtensionValue;

                // Extension is billed as its own line; base room charge (Subtotal)
                // is never altered.
                res.ExtensionCharge += extensionCharge;
                res.CheckOutDate = res.ExpectedCheckOut.Value.Date;

                var tx = res.Transaction!;
                tx.ExtensionCharge += extensionCharge;

                var breakdown = _billingSvc.ComputeBreakdown(
                    tx.Subtotal,
                    tx.DiscountRate,
                    extensionCharge: tx.ExtensionCharge,
                    extraPersons: res.ExtraPersons,
                    extraBeds: res.ExtraBeds,
                    extraHoursCharge: tx.ExtraHoursCharge,
                    otherManualCharges: tx.AdditionalCharges);

                tx.DiscountAmount = breakdown.DiscountAmount;
                tx.TotalAmount = breakdown.RoomChargesTotal;
                tx.FinalAmount = breakdown.TotalDue;
                // Extension is unpaid until collected — clear full-paid flags
                // so folio Balance due reflects the new charge.
                if (tx.AmountPaidAtCheckIn < tx.TotalAmount - 0.009m)
                {
                    tx.IsPaid = false;
                    res.PaymentStatus = tx.AmountPaidAtCheckIn > 0
                        ? PaymentStatus.PartiallyPaid
                        : PaymentStatus.Unpaid;
                }

                totalExtensionCharge += extensionCharge;
                extendedLabels.Add($"{res.Room!.RoomNumber} (₱{extensionCharge:N2})");
            }

            await _context.SaveChangesAsync();

            var unit = isNightly ? "night(s)" : "hour(s)";
            var parts = new List<string>
            {
                $"Extended {okToExtend.Count} room(s) by {vm.ExtensionValue} {unit}.",
                $"Total extension charge: ₱{totalExtensionCharge:N2} ({string.Join(", ", extendedLabels)})."
            };
            if (resolvedMoves.Any())
                parts.Add($"Auto-resolved conflicts by room move: {string.Join("; ", resolvedMoves)}.");
            if (unresolvedConflicts.Any())
                parts.Add($"Could not resolve: {string.Join("; ", unresolvedConflicts)}.");

            // After confirming extension, return to Check-In nav → In-House list (where Extend lives)
            TempData["Success"] = string.Join(" ", parts);
            return RedirectToAction(nameof(Index), "FrontDesk", new { mode = "checkin" }, "inhouse-checkin");
        }

        /// <summary>
        /// Finds an alternative physical room of the given type that is free for
        /// [from, to), not Maintenance/ForCleaning/Occupied, and not already
        /// claimed in this batch. Used for automatic conflict resolution on extend.
        /// </summary>
        private async Task<Room?> FindAlternativeRoomForExtendAsync(
            int roomTypeId,
            DateTime from,
            DateTime to,
            int excludeReservationId,
            int? excludeRoomId,
            HashSet<int> alreadyClaimed)
        {
            // Candidate rooms of same type that are physically ready
            var candidates = await _context.Rooms
                .Include(r => r.RoomType)
                .Where(r => r.RoomTypeId == roomTypeId
                    && r.Status != RoomStatus.Maintenance
                    && r.Status != RoomStatus.ForCleaning
                    && r.Status != RoomStatus.Occupied
                    && (excludeRoomId == null || r.Id != excludeRoomId.Value)
                    && !alreadyClaimed.Contains(r.Id))
                .OrderBy(r => r.RoomNumber)
                .ToListAsync();

            foreach (var room in candidates)
            {
                if (_reservationSvc.IsRoomAvailable(room.Id, from, to, excludeReservationId))
                    return room;
            }

            return null;
        }

        // ── Reservation Check-Out (added) ─────────────────────────────────
        [HttpGet]
        public async Task<IActionResult> CheckOut(int id, int? reservationId = null)
        {
            var checkoutReservationId = reservationId is > 0 ? reservationId.Value : id;
            if (checkoutReservationId <= 0) return NotFound();

            var res = await _context.Reservations
                .Include(r => r.Guest)
                .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
                .Include(r => r.PreferredRoomType)
                .Include(r => r.Transaction)
                .FirstOrDefaultAsync(r => r.Id == checkoutReservationId);
            if (res == null) return NotFound();

            if (res.Status == ReservationStatus.Completed
                || res.Status == ReservationStatus.CheckedOut
                || res.Status == ReservationStatus.Cancelled
                || res.Status == ReservationStatus.NoShow)
            {
                TempData["Error"] = res.Status == ReservationStatus.Completed
                    || res.Status == ReservationStatus.CheckedOut
                    ? "This reservation has already been checked out."
                    : $"Cannot check out a reservation with status '{res.Status}'.";
                return RedirectToAction("Details", "Reservation", new { id = res.Id });
            }

            if (res.Status != ReservationStatus.CheckedIn)
            {
                TempData["Error"] = "Only checked-in reservations can be checked out.";
                return RedirectToAction("Details", "Reservation", new { id = res.Id });
            }

            // Ensure a billing transaction exists (needed for early check-out
            // when check-in used an advance payment path without linking one).
            if (res.Transaction == null)
            {
                res.Transaction = await EnsureCheckoutTransactionAsync(res);
                await _context.SaveChangesAsync();
            }

            var (extraHours, extraCharge) = ComputeExtraHoursAndCharge(res, DateTime.Now);
            var alreadyPaid = res.Transaction!.IsPaid
                || res.PaymentStatus == PaymentStatus.Paid
                || res.Transaction.AmountPaidAtCheckIn > 0;

            // Full recompute (not a subtraction from a stale FinalAmount) so
            // the preview always matches BillingService exactly, with the
            // room charge already settled at Check-In excluded so it is
            // never billed twice.
            var breakdown = _billingSvc.ComputeBreakdown(
                res.Transaction.Subtotal,
                res.Transaction.DiscountRate,
                extensionCharge: res.Transaction.ExtensionCharge,
                extraPersons: res.ExtraPersons,
                extraBeds: res.ExtraBeds,
                extraHoursCharge: extraCharge,
                otherManualCharges: 0,
                alreadyPaidAmount: 0);

            // Checkout settles remaining charges only.
            var chargePaidAtCheckIn = res.Transaction.AmountPaidAtCheckIn;
            var chargeBalance = Math.Max(0m, breakdown.RoomChargesTotal - chargePaidAtCheckIn);

            var vm = new CheckOutViewModel
            {
                ReservationId = res.Id,
                TransactionId = res.Transaction.Id,
                Reservation = res,
                Transaction = res.Transaction,
                ActualCheckOut = DateTime.Now,
                DurationHours = res.DurationHours > 0 ? res.DurationHours : 24,
                ExtraHours = extraHours,
                ExtraHoursCharge = extraCharge,
                ExtraPersons = res.ExtraPersons,
                ExtraBeds = res.ExtraBeds,
                ChargeBalance = chargeBalance,
                AmountDueFromGuest = chargeBalance,
                AlreadyPaid = res.Transaction.IsPaid,
                PaidMethod = res.Transaction.PaymentMethod,
                PaidReference = res.Transaction.PaymentReference,
                DiscountLegalBasis = res.Transaction.DiscountType != DiscountType.None
                    ? (res.Transaction.DiscountType == DiscountType.SeniorCitizen
                        ? "Republic Act No. 9994"
                        : "Republic Act No. 10754")
                    : null
            };
            return View(vm);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> CheckOut(CheckOutViewModel vm)
        {
            var res = await _context.Reservations
                .Include(r => r.Guest)
                .Include(r => r.Room).ThenInclude(rm => rm!.RoomType)
                .Include(r => r.PreferredRoomType)
                .Include(r => r.Transaction)
                .FirstOrDefaultAsync(r => r.Id == vm.ReservationId);
            if (res == null) return NotFound();

            if (res.Status != ReservationStatus.CheckedIn)
            {
                TempData["Error"] = "Only checked-in guests can be checked out.";
                return RedirectToAction("Details", "Reservation", new { id = res.Id });
            }

            if (res.Transaction == null)
            {
                res.Transaction = await EnsureCheckoutTransactionAsync(res);
                await _context.SaveChangesAsync();
            }

            var selectedChargeTypes = vm.SelectedChargeTypes ?? new List<string>();
            var selectedChargeAmt = selectedChargeTypes
                .Where(t => !string.IsNullOrWhiteSpace(t))
                .Sum(t => CheckOutViewModel.AvailableCharges.TryGetValue(t, out var amount) ? amount : 0m);

            // NOTE: AdditionalCharges is a hidden field populated by the check-out
            // page JS to mirror the selected checkbox total. The actual source of
            // truth for additional charges is SelectedChargeTypes + AvailableCharges.
            // If a future UI adds a free-text manual charge field, that value should
            // be added here instead of (or in addition to) selectedChargeAmt.
            // This bucket is exclusively manual check-out charges — Extra
            // Persons/Beds are set once at Check-In/Walk-In and are never
            // folded in here.
            var totalAdditionalCharge = selectedChargeAmt;

            var (extraHours, extraCharge) = ComputeExtraHoursAndCharge(res, vm.ActualCheckOut);

            // Capture BEFORE any changes: if the stay was already paid in
            // full at Check-In (the normal case now), Check-Out only needs
            // to collect additional charges — it doesn't ask for a payment
            // Prior collection (full or partial) — room charge already paid
            // must not be billed again. Use amount, not IsPaid flag alone.
            var alreadyPaidAmount = Math.Max(0m, res.Transaction.AmountPaidAtCheckIn);
            var alreadyPaid = alreadyPaidAmount > 0;

            // Full recompute via the single source of truth. Payments never
            // mutate the charge total, and payments never offset charges.
            var checkoutBreakdown = _billingSvc.ComputeBreakdown(
                res.Transaction.Subtotal,
                res.Transaction.DiscountRate,
                extensionCharge: res.Transaction.ExtensionCharge,
                extraPersons: res.ExtraPersons,
                extraBeds: res.ExtraBeds,
                extraHoursCharge: extraCharge,
                otherManualCharges: totalAdditionalCharge,
                alreadyPaidAmount: 0);

            // Remaining charges only.
            var chargePaidAtCheckIn = res.Transaction.AmountPaidAtCheckIn;
            var remainingCharges = Math.Max(0m, checkoutBreakdown.RoomChargesTotal - chargePaidAtCheckIn);
            var dueFromGuest = remainingCharges;

            var needsPaymentCapture = dueFromGuest > 0;

            if (needsPaymentCapture)
            {
                if (string.IsNullOrWhiteSpace(vm.PaymentMethod))
                {
                    ModelState.AddModelError(nameof(vm.PaymentMethod), "Please select a payment method.");
                }

                if (string.Equals(vm.PaymentMethod, "Cash", StringComparison.OrdinalIgnoreCase))
                {
                    if (vm.AmountTendered == null)
                    {
                        ModelState.AddModelError(nameof(vm.AmountTendered), "Amount tendered is required for cash payments.");
                    }
                    else if (vm.AmountTendered.Value < dueFromGuest)
                    {
                        ModelState.AddModelError(nameof(vm.AmountTendered), $"Amount tendered must be at least ₱{dueFromGuest:N2}.");
                    }
                }
                else if (string.IsNullOrWhiteSpace(vm.PaymentReference))
                {
                    ModelState.AddModelError(nameof(vm.PaymentReference), "Reference number is required for non-cash payments.");
                }
            }

            if (!ModelState.IsValid)
            {
                vm.Reservation = res;
                vm.Transaction = res.Transaction;
                var baselineCharges = Math.Max(0m, remainingCharges - totalAdditionalCharge);
                vm.ChargeBalance = baselineCharges;
                vm.AmountDueFromGuest = baselineCharges;
                vm.AlreadyPaid = alreadyPaid;
                vm.PaidMethod = res.Transaction.PaymentMethod;
                vm.PaidReference = res.Transaction.PaymentReference;
                if (vm.AmountTendered.HasValue && dueFromGuest > 0)
                    vm.ChangeAmount = vm.AmountTendered.Value - dueFromGuest;
                TempData["Error"] = "Could not process check-out. Please check the highlighted fields.";
                return View(vm);
            }


            var tx = res.Transaction;
            tx.ActualCheckOut = vm.ActualCheckOut;
            tx.ExtraHours = extraHours;
            tx.ExtraHoursCharge = extraCharge;
            // Set (not accumulate) — check-out only runs once per
            // reservation (guarded by the status check above), and this
            // bucket holds only the charges selected on this screen.
            tx.AdditionalCharges = totalAdditionalCharge;

            if (selectedChargeTypes.Any())
            {
                var chargeNames = string.Join(", ", selectedChargeTypes);
                tx.AdditionalChargesType = chargeNames;
            }

            // TotalAmount / FinalAmount = FULL charge bill (room + extension + extras + damages).
            tx.TotalAmount = checkoutBreakdown.RoomChargesTotal;
            tx.FinalAmount = checkoutBreakdown.RoomChargesTotal;

            if (dueFromGuest > 0)
            {
                if (!alreadyPaid)
                {
                    // Nothing collected at check-in — collect full remaining due now.
                    tx.PaymentMethod = vm.PaymentMethod;
                    tx.PaymentReference = vm.PaymentReference;
                    tx.AmountTendered = vm.AmountTendered;
                    tx.ChangeAmount = vm.AmountTendered.HasValue ? vm.AmountTendered.Value - dueFromGuest : null;
                }
                else
                {
                    // Already paid room charge at check-in; collect extension/damages now.
                    tx.CheckOutPaymentMethod = vm.PaymentMethod;
                    tx.CheckOutPaymentReference = vm.PaymentReference;
                    tx.CheckOutAmountTendered = vm.AmountTendered;
                    tx.CheckOutChangeAmount = vm.AmountTendered.HasValue ? vm.AmountTendered.Value - dueFromGuest : null;
                }

                // CRITICAL: fold checkout collection into AmountPaidAtCheckIn so the
                // folio balance (TotalAmount − AmountPaidAtCheckIn) becomes zero.
                // Without this, extension paid at checkout still shows as balance due.
                tx.AmountPaidAtCheckIn = Math.Max(tx.AmountPaidAtCheckIn, 0m) + dueFromGuest;
            }

            // After checkout, mark paid only when collections cover the full bill.
            // Never invent payment by forcing AmountPaidAtCheckIn up to TotalAmount.
            if (tx.AmountPaidAtCheckIn >= tx.TotalAmount - 0.009m)
            {
                tx.IsPaid = true;
                tx.InvoiceStatus = InvoiceStatus.Paid;
                res.PaymentStatus = PaymentStatus.Paid;
            }
            else if (tx.AmountPaidAtCheckIn > 0)
            {
                tx.IsPaid = false;
                tx.InvoiceStatus = InvoiceStatus.Issued;
                res.PaymentStatus = PaymentStatus.PartiallyPaid;
            }
            else
            {
                tx.IsPaid = false;
                res.PaymentStatus = PaymentStatus.Unpaid;
            }
            tx.InvoiceNumber ??= $"INV-{tx.CreatedAt:yyyyMMdd}{tx.Id:D3}";
            tx.CheckedOutByUserId = HttpContext.Session.GetInt32("UserId");

            res.Status = ReservationStatus.Completed;
            res.ActualCheckOut = vm.ActualCheckOut;
            res.ExtraHours = extraHours;
            res.ExtraHoursCharge = extraCharge;
            res.ExtraCharge = extraCharge;
            res.Room!.Status = RoomStatus.ForCleaning;

            await _context.SaveChangesAsync();

            var userId = HttpContext.Session.GetInt32("UserId") ?? 0;
            if (res.RoomId.HasValue)
                await _roomSvc.UpdateRoomStatusAsync(res.RoomId.Value, RoomStatus.ForCleaning, userId, "Auto-set after check-out — pending housekeeping.");

            if (dueFromGuest > 0)
            {
                TempData["Success"] =
                    $"Guest {res.Guest.FullName} checked out. " +
                    $"Collected ₱{dueFromGuest:N2} net settlement. " +
                    $"Room marked For Cleaning.";
            }
            else
            {
                TempData["Success"] =
                    $"Guest {res.Guest.FullName} checked out successfully. Fully settled. Room marked For Cleaning.";
            }

            await _audit.LogAsync("check_out", "reservation", res.Id,
                $"{res.ReferenceNumber} total={tx.TotalAmount:0.0}");
            return RedirectToAction("Receipt", new { transactionId = tx.Id });
        }

        public async Task<IActionResult> Receipt(int transactionId)
        {
            var tx = await _context.Transactions
                .Include(t => t.Reservation).ThenInclude(r => r.Guest)
                .Include(t => t.Reservation).ThenInclude(r => r.Room).ThenInclude(rm => rm!.RoomType)
                .Include(t => t.Reservation).ThenInclude(r => r.PreferredRoomType)
                .Include(t => t.CheckedInByUser)
                .Include(t => t.CheckedOutByUser)
                .FirstOrDefaultAsync(t => t.Id == transactionId);
            if (tx == null) return NotFound();
            return View(tx);
        }

        // Receipt for a multi-room walk-in payment (or any batch of
        // transactions that should be shown together).
        [HttpGet]
        public async Task<IActionResult> WalkInReceipt(string transactionIds)
        {
            var ids = ParseReservationIds(transactionIds);
            if (!ids.Any()) return BadRequest("No transactions selected.");

            var transactions = await _context.Transactions
                .Include(t => t.Reservation).ThenInclude(r => r.Guest)
                .Include(t => t.Reservation).ThenInclude(r => r.Room).ThenInclude(rm => rm!.RoomType)
                .Include(t => t.CheckedInByUser)
                .Where(t => ids.Contains(t.Id))
                .ToListAsync();

            if (!transactions.Any()) return NotFound();
            return View(transactions);
        }

        // Helper used by Check-In to populate the Available Rooms list.
        // Explains WHY the room booked for this guest cannot be used right now.
        private async Task<string> BuildRoomHeldNoticeAsync(Reservation res, DateTime from, DateTime to)
        {
            var roomNo = res.Room?.RoomNumber ?? "(assigned room)";
            var others = await _context.Reservations
                .Include(r => r.Guest)
                .Where(r => r.RoomId == res.RoomId && r.Id != res.Id
                    && r.Status != ReservationStatus.Cancelled
                    && r.Status != ReservationStatus.CheckedOut
                    && r.Status != ReservationStatus.Completed
                    && r.Status != ReservationStatus.NoShow)
                .ToListAsync();

            var blocker = others
                .Select(b =>
                {
                    var st = b.ExpectedCheckIn ?? b.CheckInDate ?? DateTime.MinValue;
                    var en = b.ExpectedCheckOut ?? b.CheckOutDate ?? st.AddDays(1);
                    if (en <= st) en = st.AddDays(1);
                    return new { b, st, en };
                })
                .Where(x => x.st < to && x.en > from)
                .OrderBy(x => x.st)
                .FirstOrDefault();

            if (blocker != null)
            {
                var who = blocker.b.Guest?.FullName ?? "another guest";
                if (blocker.b.Status == ReservationStatus.CheckedIn)
                {
                    var extended = (blocker.b.ExtendedNights > 0 || blocker.b.ExtendedHours > 0)
                        ? " (stay was extended)" : "";
                    return $"Room {roomNo} is still occupied by {who}{extended}, in-house until {blocker.en:MMM dd, yyyy h:mm tt}.";
                }
                return $"Room {roomNo} overlaps another booking by {who} ({blocker.st:MMM dd h:mm tt} – {blocker.en:MMM dd h:mm tt}).";
            }

            return res.Room != null
                ? $"Room {roomNo} is not available right now (status: {res.Room.Status})."
                : "The booked room is not available right now.";
        }

        private async Task PopulateCheckInRoomDropdownAsync(CheckInViewModel vm, Reservation res)
        {
            vm.PreferredRoomTypeName = res.PreferredRoomType?.Name ?? res.Room?.RoomType?.Name;
            // Keep staff selection on re-render; fall back to reservation's room.
            if (vm.AssignedRoomId is null or <= 0)
                vm.AssignedRoomId = res.RoomId;

            // Use the SAME window the POST validates: actual check-in time → scheduled
            // check-out. (Using only the booked dates hid real conflicts, e.g. an
            // in-house guest who extended into this room.)
            var checkIn = vm.ActualCheckIn > DateTime.MinValue ? vm.ActualCheckIn : DateTime.Now;
            var checkOut = GetScheduledCheckOutForCheckIn(res);
            if (checkOut <= checkIn) checkOut = checkIn.AddDays(1);

            // Central availability rule. Excluding THIS reservation keeps the room it
            // already holds in the list, while rooms held by other guests stay hidden.
            var allFree = await _reservationSvc.GetAvailableRoomsAsync(checkIn, checkOut, res.Id);

            var busyIds = await _context.Reservations
                .Where(r => r.Status == ReservationStatus.CheckedIn
                    && r.RoomId != null
                    && r.Id != res.Id)
                .Select(r => r.RoomId!.Value)
                .ToListAsync();

            vm.RoomConflictNotices = new List<string>();

            // Primary (single-room path) dropdown — preferred type only.
            var typeId = res.PreferredRoomTypeId ?? res.Room?.RoomTypeId;
            var primaryFree = typeId.HasValue
                ? allFree.Where(r => r.RoomTypeId == typeId.Value).ToList()
                : allFree.ToList();

            // Is the room already linked to this booking still free for this stay?
            var linkedBlocked = res.RoomId.HasValue
                && !_reservationSvc.IsRoomAvailable(res.RoomId.Value, checkIn, checkOut, res.Id);
            if (linkedBlocked)
            {
                var notice = await BuildRoomHeldNoticeAsync(res, checkIn, checkOut);
                // Pick the first free room of the same type so staff can proceed.
                var alt = primaryFree
                    .Where(r => r.Id != res.RoomId && !busyIds.Contains(r.Id))
                    .OrderBy(r => r.RoomNumber)
                    .FirstOrDefault();
                if (vm.AssignedRoomId == res.RoomId)
                    vm.AssignedRoomId = alt?.Id;
                vm.RoomConflictNotices.Add(alt != null
                    ? $"{notice} Room {alt.RoomNumber} ({alt.RoomType?.Name ?? "same type"}) was selected instead — please tell the guest about the room change."
                    : $"{notice} No other {res.PreferredRoomType?.Name ?? res.Room?.RoomType?.Name ?? "matching"} room is free right now, so this guest cannot be checked in yet.");
            }
            else if (res.Room != null && !primaryFree.Any(r => r.Id == res.Room.Id) && !busyIds.Contains(res.Room.Id))
            {
                // Ensure the reservation's already-assigned room stays selectable when it is genuinely free
                primaryFree.Insert(0, res.Room);
            }

            var selectedId = vm.AssignedRoomId;
            vm.AvailableRoomsForAssignment = primaryFree
                .Where(r => !busyIds.Contains(r.Id) && !(linkedBlocked && r.Id == res.RoomId))
                .OrderBy(r => r.RoomNumber)
                .Select(r => new SelectListItem(
                    $"Room {r.RoomNumber} — {r.RoomType?.Name ?? "Room"}",
                    r.Id.ToString(),
                    selectedId != null && r.Id == selectedId))
                .ToList();

            // Multi-room group: one dropdown per sibling so staff can assign
            // a distinct physical room to each (online bookings arrive TBA).
            var group = await GetGroupSiblingsForCheckInAsync(res);
            if (group.Count <= 1)
            {
                vm.GroupRoomAssignments = new List<GroupRoomAssignmentItem>();
                return;
            }

            // Preserve posted selections when re-rendering after validation error.
            var postedByResId = (vm.GroupRoomAssignments ?? new List<GroupRoomAssignmentItem>())
                .Where(g => g.ReservationId > 0)
                .ToDictionary(g => g.ReservationId, g => g.AssignedRoomId);

            var items = new List<GroupRoomAssignmentItem>();
            foreach (var sib in group)
            {
                var sibTypeId = sib.PreferredRoomTypeId ?? sib.Room?.RoomTypeId;
                // Same central rule, excluding only this sibling so its own room stays
                // visible but a room held by another sibling/guest is hidden.
                var sibAll = sib.Id == res.Id
                    ? allFree
                    : await _reservationSvc.GetAvailableRoomsAsync(checkIn, checkOut, sib.Id);
                var sibFree = sibTypeId.HasValue
                    ? sibAll.Where(r => r.RoomTypeId == sibTypeId.Value).ToList()
                    : sibAll.ToList();

                // Is this sibling's booked room still free for the stay window?
                var sibBlocked = sib.RoomId.HasValue
                    && !_reservationSvc.IsRoomAvailable(sib.RoomId.Value, checkIn, checkOut, sib.Id);
                if (sibBlocked && sib.Id != res.Id)
                {
                    var sibNotice = await BuildRoomHeldNoticeAsync(sib, checkIn, checkOut);
                    vm.RoomConflictNotices.Add($"{sib.ReferenceNumber}: {sibNotice} Choose another room below.");
                }
                else if (sibBlocked && sib.Id == res.Id && !vm.RoomConflictNotices.Any())
                {
                    vm.RoomConflictNotices.Add(await BuildRoomHeldNoticeAsync(sib, checkIn, checkOut) + " Choose another room below.");
                }

                int? chosen = null;
                if (postedByResId.TryGetValue(sib.Id, out var posted) && posted is > 0)
                    chosen = posted;
                else if (sib.RoomId is > 0 && !sibBlocked)
                    chosen = sib.RoomId;
                else if (sib.Id == res.Id && vm.AssignedRoomId is > 0 && !sibBlocked)
                    chosen = vm.AssignedRoomId;

                items.Add(new GroupRoomAssignmentItem
                {
                    ReservationId = sib.Id,
                    ReferenceNumber = sib.ReferenceNumber ?? "",
                    PreferredRoomTypeName = sib.PreferredRoomType?.Name ?? sib.Room?.RoomType?.Name ?? "Any",
                    PreferredRoomTypeId = sibTypeId,
                    AssignedRoomId = chosen,
                    AvailableRooms = (sib.Room != null && !sibBlocked && !sibFree.Any(r => r.Id == sib.Room.Id) && !busyIds.Contains(sib.Room.Id)
                            ? new List<Room> { sib.Room }.Concat(sibFree).ToList()
                            : sibFree)
                        .Where(r => !busyIds.Contains(r.Id) && !(sibBlocked && r.Id == sib.RoomId))
                        .OrderBy(r => r.RoomNumber)
                        .Select(r => new SelectListItem(
                            $"Room {r.RoomNumber} — {r.RoomType?.Name ?? "Room"}",
                            r.Id.ToString(),
                            chosen != null && r.Id == chosen))
                        .ToList()
                });
            }
            vm.GroupRoomAssignments = items;

            // Keep primary AssignedRoomId in sync with the primary row in the group list.
            var primaryItem = items.FirstOrDefault(i => i.ReservationId == res.Id);
            if (primaryItem?.AssignedRoomId is > 0)
                vm.AssignedRoomId = primaryItem.AssignedRoomId;
        }

        // Computes the base room charge (rate × nights, or the flat duration
        // rate) for a reservation at its ORIGINAL stay length — never
        // inflated by later Extend Stay activity. Any extension is billed
        // separately as its own "Stay Extension" line via
        // IBillingService.ComputeBreakdown, so this figure must stay fixed
        // once check-in happens.
        internal static (decimal BaseRoomCharge, decimal RatePerNight, int NumberOfNights, int DurationHours) ComputeBaseRoomCharge(Reservation res)
        {
            // Prefer assigned room type; fall back to preferred type booked at reservation.
            var roomType = res.Room?.RoomType ?? res.PreferredRoomType;
            if (roomType == null)
                return (0m, 0m, res.NumberOfNights, res.DurationHours);

            if (res.StayType == StayType.Nightly)
            {
                // Single source of truth for overnight rate (same as GetRateForDuration(24)).
                var rate = roomType.GetRateForDuration(24);
                var nights = Math.Max(1, res.NumberOfNights);
                return (rate * nights, rate, nights, 24);
            }

            var durationRate = roomType.GetRateForDuration(res.DurationHours);
            return (durationRate, durationRate, 1, res.DurationHours);
        }

        internal static decimal GetDiscountRatePercent(DiscountType discountType) => discountType switch
        {
            DiscountType.SeniorCitizen => 20m,
            DiscountType.PWD => 20m,
            _ => 0m
        };

        internal static string GetDiscountLegalBasis(DiscountType discountType) => discountType switch
        {
            DiscountType.SeniorCitizen => "Republic Act No. 9994 – Expanded Senior Citizens Act of 2010",
            DiscountType.PWD => "Republic Act No. 10754 – Act Expanding Benefits/Privileges of Persons with Disability",
            _ => string.Empty
        };

        // Returns the reservation's planned departure used for check-in
        // availability. This is intentionally independent of ActualCheckIn
        // so an early arrival does not accidentally shorten the booked stay.
        private static DateTime GetScheduledCheckOutForCheckIn(Reservation res)
        {
            var checkIn = res.ExpectedCheckIn ?? res.CheckInDate ?? DateTime.Today;
            var checkOut = res.ExpectedCheckOut ?? res.CheckOutDate;

            if (checkOut.HasValue && checkOut.Value > checkIn)
                return checkOut.Value;

            return res.StayType == StayType.Nightly
                ? checkIn.Date.AddDays(Math.Max(1, res.NumberOfNights)).Add(Reservation.NightlyCheckoutTime)
                : checkIn.AddHours(Math.Max(1, res.DurationHours));
        }

        // Computes expected check-out based on the stay type and the hotel's
        // fixed nightly policy (12:00 PM on the departure day).
        private static DateTime ComputeExpectedCheckOut(Reservation res, DateTime actualCheckIn)
        {
            if (res.StayType == StayType.Nightly)
                return actualCheckIn.Date.AddDays(Math.Max(1, res.NumberOfNights)).Add(Reservation.NightlyCheckoutTime);

            return actualCheckIn.AddHours(Math.Max(1, res.DurationHours));
        }

        // Computes extra hours and charge for a check-out that exceeds the
        // expected check-out time.
        private static (int ExtraHours, decimal ExtraCharge) ComputeExtraHoursAndCharge(
            Reservation res, DateTime actualCheckOut)
        {
            if (!res.ExpectedCheckOut.HasValue || actualCheckOut <= res.ExpectedCheckOut.Value)
                return (0, 0m);

            var extraHours = (int)Math.Ceiling((actualCheckOut - res.ExpectedCheckOut.Value).TotalHours);
            // Always use Alemar-aware extra-hour rate (DB or consultation defaults)
            var extraHourRate = res.Room?.RoomType != null
                ? res.Room.RoomType.GetExtraHourRateForDuration(res.IsNightlyStay ? 24 : res.DurationHours)
                : 70m;
            return (extraHours, extraHours * extraHourRate);
        }

        private decimal ComputeReservationTotalDue(Reservation res)
        {
            var discountType = res.Guest.IsSeniorCitizen ? DiscountType.SeniorCitizen
                : res.Guest.IsPwd ? DiscountType.PWD : DiscountType.None;
            var (baseRoomCharge, _, _, _) = ComputeBaseRoomCharge(res);
            var discountRatePercent = GetDiscountRatePercent(discountType);
            var breakdown = _billingSvc.ComputeBreakdown(
                baseRoomCharge,
                discountRatePercent,
                extraPersons: res.ExtraPersons,
                extraBeds: res.ExtraBeds);
            return breakdown.TotalDue;
        }

        private static List<int> ParseReservationIds(string? csv)
        {
            if (string.IsNullOrWhiteSpace(csv)) return new List<int>();
            return csv.Split(',', StringSplitOptions.RemoveEmptyEntries)
                .Select(s => int.TryParse(s.Trim(), out var id) ? id : (int?)null)
                .Where(id => id.HasValue)
                .Select(id => id!.Value)
                .Distinct()
                .ToList();
        }

        private async Task<List<int>> GetWalkInSiblingIdsAsync(Reservation res)
        {
            var baseRef = GetWalkInBaseReference(res.ReferenceNumber);
            var siblings = await _context.Reservations
                .Where(r => r.Type == ReservationType.WalkIn
                    && r.Status == ReservationStatus.Pending
                    && (r.ReferenceNumber == baseRef || r.ReferenceNumber.StartsWith(baseRef + "-")))
                .Select(r => r.Id)
                .ToListAsync();
            return siblings.Any() ? siblings : new List<int> { res.Id };
        }

        private static string GetWalkInBaseReference(string referenceNumber)
        {
            if (string.IsNullOrWhiteSpace(referenceNumber)) return referenceNumber;
            // Multi-room walk-ins use a suffix such as ALE-...-1, ALE-...-2.
            var lastDash = referenceNumber.LastIndexOf('-');
            if (lastDash > 0 && int.TryParse(referenceNumber[(lastDash + 1)..], out _))
                return referenceNumber[..lastDash];
            return referenceNumber;
        }

        private async Task<Transaction?> PerformCheckInAsync(
            Reservation res,
            DateTime actualCheckIn,
            string? paymentMethod = null,
            string? paymentReference = null,
            decimal? amountTendered = null,
            decimal? changeAmount = null,
            decimal? amountPaidAtCheckIn = null,
            bool? isAlreadyPaidOverride = null)
        {
            var discountType = res.Guest?.IsSeniorCitizen == true ? DiscountType.SeniorCitizen
                : res.Guest?.IsPwd == true ? DiscountType.PWD : DiscountType.None;
            var (baseRoomCharge, ratePerNight, numberOfNights, durationHours) = ComputeBaseRoomCharge(res);
            var discountRatePercent = GetDiscountRatePercent(discountType);
            var breakdown = _billingSvc.ComputeBreakdown(
                baseRoomCharge,
                discountRatePercent,
                extraPersons: res.ExtraPersons,
                extraBeds: res.ExtraBeds);
            // Walk-ins calculate their departure from the actual arrival.
            // Advance/phone/online reservations keep the ORIGINAL scheduled
            // check-out even when the guest arrives early or late.
            var expectedCheckOut = res.Type == ReservationType.WalkIn
                ? ComputeExpectedCheckOut(res, actualCheckIn)
                : GetScheduledCheckOutForCheckIn(res);

            // Fully paid only when pesos collected cover TotalDue — never from flags alone.
            var existingPaid = res.Transaction?.AmountPaidAtCheckIn ?? 0m;
            var paidNow = amountPaidAtCheckIn ?? breakdown.TotalDue;
            // amountPaidAtCheckIn from caller is the total collected for this room.
            var totalPaidForRoom = Math.Max(existingPaid, paidNow);
            var fullyPaid = isAlreadyPaidOverride == true
                || totalPaidForRoom >= breakdown.TotalDue - 0.009m;

            Transaction? transaction = res.Transaction;
            if (transaction == null)
            {
                transaction = new Transaction
                {
                    ReservationId = res.Id,
                    ActualCheckIn = actualCheckIn,
                    RatePerNight = ratePerNight,
                    NumberOfNights = numberOfNights,
                    DurationHours = durationHours,
                    Subtotal = breakdown.BaseRoomCharge,
                    DiscountType = discountType,
                    DiscountRate = breakdown.DiscountRate,
                    DiscountAmount = breakdown.DiscountAmount,
                    ExtensionCharge = 0,
                    AdditionalCharges = 0,
                    TotalAmount = breakdown.RoomChargesTotal,
                    FinalAmount = breakdown.TotalDue,
                    PaymentMethod = paymentMethod,
                    PaymentReference = paymentReference,
                    AmountTendered = amountTendered,
                    ChangeAmount = changeAmount,
                    IsPaid = fullyPaid,
                    AmountPaidAtCheckIn = totalPaidForRoom,
                    InvoiceStatus = fullyPaid ? InvoiceStatus.Paid : InvoiceStatus.Issued,
                    CheckedInByUserId = HttpContext.Session.GetInt32("UserId") ?? 0
                };
                _context.Transactions.Add(transaction);
            }
            else
            {
                // Update existing transaction with check-in collection.
                transaction.ActualCheckIn = actualCheckIn;
                transaction.RatePerNight = ratePerNight;
                transaction.NumberOfNights = numberOfNights;
                transaction.DurationHours = durationHours;
                transaction.Subtotal = breakdown.BaseRoomCharge;
                transaction.DiscountType = discountType;
                transaction.DiscountRate = breakdown.DiscountRate;
                transaction.DiscountAmount = breakdown.DiscountAmount;
                transaction.TotalAmount = breakdown.RoomChargesTotal;
                transaction.FinalAmount = breakdown.TotalDue;
                if (!string.IsNullOrWhiteSpace(paymentMethod))
                    transaction.PaymentMethod = paymentMethod;
                if (!string.IsNullOrWhiteSpace(paymentReference))
                    transaction.PaymentReference = paymentReference;
                if (amountTendered.HasValue)
                    transaction.AmountTendered = amountTendered;
                if (changeAmount.HasValue)
                    transaction.ChangeAmount = changeAmount;
                transaction.AmountPaidAtCheckIn = totalPaidForRoom;
                transaction.IsPaid = fullyPaid;
                transaction.InvoiceStatus = fullyPaid ? InvoiceStatus.Paid : InvoiceStatus.Issued;
                if (transaction.CheckedInByUserId == 0)
                    transaction.CheckedInByUserId = HttpContext.Session.GetInt32("UserId") ?? 0;
            }

            res.PaymentStatus = fullyPaid
                ? PaymentStatus.Paid
                : (totalPaidForRoom > 0 ? PaymentStatus.PartiallyPaid : PaymentStatus.Unpaid);
            res.IsPaymentVerified = totalPaidForRoom > 0;

            res.Status = ReservationStatus.CheckedIn;
            res.ActualCheckIn = actualCheckIn;
            res.ExpectedCheckOut = expectedCheckOut;
            res.CheckInDate = actualCheckIn.Date;
            res.CheckOutDate = expectedCheckOut.Date;

            // Ensure physical room is loaded and marked Occupied (multi-room walk-in
            // must update every selected room, not only the first).
            if (res.Room == null && res.RoomId.HasValue)
            {
                var loadedRoom = await _context.Rooms.FindAsync(res.RoomId.Value);
                if (loadedRoom != null)
                    res.Room = loadedRoom;
            }
            if (res.Room != null)
                res.Room.Status = RoomStatus.Occupied;

            return transaction;
        }


        /// <summary>
        /// Creates a minimal settlement transaction so early / normal check-out
        /// can run when check-in left PaymentStatus=Paid but no Transaction row.
        /// </summary>
        private async Task<Transaction> EnsureCheckoutTransactionAsync(Reservation res)
        {
            var (baseRoomCharge, ratePerNight, numberOfNights, durationHours) = ComputeBaseRoomCharge(res);
            var discountType = res.Guest?.IsSeniorCitizen == true ? DiscountType.SeniorCitizen
                : res.Guest?.IsPwd == true ? DiscountType.PWD : DiscountType.None;
            var discountRatePercent = GetDiscountRatePercent(discountType);
            var breakdown = _billingSvc.ComputeBreakdown(
                baseRoomCharge,
                discountRatePercent,
                extraPersons: res.ExtraPersons,
                extraBeds: res.ExtraBeds);

            var paid = res.PaymentStatus == PaymentStatus.Paid ? breakdown.TotalDue : 0m;
            var tx = new Transaction
            {
                ReservationId = res.Id,
                ActualCheckIn = res.ActualCheckIn ?? DateTime.Now,
                RatePerNight = ratePerNight,
                NumberOfNights = numberOfNights,
                DurationHours = durationHours,
                Subtotal = breakdown.BaseRoomCharge,
                DiscountType = discountType,
                DiscountRate = breakdown.DiscountRate,
                DiscountAmount = breakdown.DiscountAmount,
                ExtensionCharge = res.ExtensionCharge,
                AdditionalCharges = 0,
                TotalAmount = breakdown.RoomChargesTotal,
                FinalAmount = breakdown.TotalDue,
                IsPaid = paid > 0,
                AmountPaidAtCheckIn = paid,
                InvoiceStatus = paid > 0 ? InvoiceStatus.Paid : InvoiceStatus.Draft,
                CheckedInByUserId = HttpContext.Session.GetInt32("UserId")
            };
            _context.Transactions.Add(tx);
            await _context.SaveChangesAsync();
            return tx;
        }

        internal static List<SelectListItem> GetNationalityOptions()
        {
            var nationalities = new[]
            {
                "Filipino", "American", "Chinese", "Japanese", "Korean",
                "Australian", "British", "Canadian", "German", "Indian",
                "Indonesian", "Malaysian", "Singaporean", "Thai", "Vietnamese",
                "French", "Italian", "Spanish", "Saudi", "Emirati", "Other"
            };
            // Display text includes flag emoji; value stays plain nationality name
            return nationalities
                .Select(n => new SelectListItem(NationalityHelper.WithFlag(n), n))
                .ToList();
        }
    }
}
