using HotelEase.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace HotelEase.Filters;

/// <summary>
/// Server-side role gate for session-based auth.
/// Requires an authenticated session (UserId) AND that UserRole is one of the allowed roles.
/// Place on controllers or individual actions. Admin is never implied — list it explicitly when needed.
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
public sealed class RequireRoleAttribute : Attribute, IActionFilter
{
    private readonly HashSet<string> _allowed;

    public RequireRoleAttribute(params UserRole[] roles)
    {
        _allowed = new HashSet<string>(
            roles.Select(r => r.ToString()),
            StringComparer.OrdinalIgnoreCase);
    }

    public void OnActionExecuting(ActionExecutingContext context)
    {
        var session = context.HttpContext.Session;
        var userId = session.GetInt32("UserId");
        if (userId == null)
        {
            var returnUrl = context.HttpContext.Request.Path.Value ?? "/";
            context.Result = new RedirectToActionResult("Login", "Account", new { returnUrl });
            return;
        }

        var role = session.GetString("UserRole") ?? string.Empty;
        if (!_allowed.Contains(role))
        {
            context.Result = new RedirectToActionResult("AccessDenied", "Account", null);
        }
    }

    public void OnActionExecuted(ActionExecutedContext context) { }
}
