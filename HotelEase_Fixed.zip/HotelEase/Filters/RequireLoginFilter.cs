using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace HotelEase.Filters;

/// <summary>
/// Global action filter that blocks unauthenticated access.
/// Runs AFTER the session middleware has already loaded session data,
/// so no manual LoadAsync() is needed and there are no timing issues.
/// Controllers/actions decorated with [AllowAnonymous] are skipped.
/// Also enforces MustChangePassword: only ChangePassword + Logout allowed.
/// </summary>
public class RequireLoginFilter : IActionFilter
{
    public void OnActionExecuting(ActionExecutingContext context)
    {
        // Skip if the controller or action has [AllowAnonymous]
        var isPublic = context.ActionDescriptor.EndpointMetadata
            .Any(m => m is IAllowAnonymous);

        if (isPublic) return;

        var userId = context.HttpContext.Session.GetInt32("UserId");
        if (userId == null)
        {
            var returnUrl = context.HttpContext.Request.Path.Value ?? "/";
            context.Result = new RedirectToActionResult(
                "Login", "Account", new { returnUrl });
            return;
        }

        // Forced password change: staff may only open ChangePassword or Logout.
        var mustChange = context.HttpContext.Session.GetString("MustChangePassword");
        if (string.Equals(mustChange, "1", StringComparison.Ordinal))
        {
            var controller = (context.RouteData.Values["controller"]?.ToString() ?? "").ToLowerInvariant();
            var action = (context.RouteData.Values["action"]?.ToString() ?? "").ToLowerInvariant();
            var allowed =
                (controller == "account" && (action == "changepassword" || action == "logout"));
            if (!allowed)
            {
                context.Result = new RedirectToActionResult("ChangePassword", "Account", null);
            }
        }
    }

    public void OnActionExecuted(ActionExecutedContext context) { }
}
