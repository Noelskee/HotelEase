namespace HotelEase.Services;

public interface IEmailService
{
    // Fire-and-forget style: implementations should never throw back into
    // the caller (reservation submission must still succeed even if the
    // hotel's mail server is unreachable/unconfigured). Returns true if the
    // message was actually handed off to an SMTP server, false otherwise.
    Task<bool> SendAsync(string toAddress, string subject, string htmlBody);
}
