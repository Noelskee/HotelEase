using HotelEase.Models;

namespace HotelEase.Services;

public interface IReservationService
{
    string GenerateReferenceNumber();
    bool IsRoomAvailable(int roomId, DateTime checkIn, DateTime checkOut, int? excludeReservationId = null);
    /// <summary>
    /// Central availability rule. Returns only rooms that can be selected for the
    /// stay window. Pass excludeReservationId so a reservation's own room is not
    /// treated as taken (Check-In, Reschedule, Room Transfer).
    /// </summary>
    Task<List<Room>> GetAvailableRoomsAsync(DateTime checkIn, DateTime checkOut, int? excludeReservationId = null);
    Task<List<Room>> GetAvailableRoomsForWalkInAsync(DateTime? checkIn = null, DateTime? checkOut = null);

    /// <summary>
    /// How many rooms of this type can still be booked for the date range.
    /// Counts physical inventory minus rooms already assigned for overlapping
    /// stays and TBA holds (PreferredRoomTypeId, RoomId null) for the same type.
    /// </summary>
    Task<int> GetAvailableCapacityForRoomTypeAsync(int roomTypeId, DateTime checkIn, DateTime checkOut, int? excludeReservationId = null);
    Task<int> GetAvailableCapacityForRoomTypeAsync(int roomTypeId, DateTime checkIn, DateTime checkOut, IEnumerable<int> excludeReservationIds);
}
