using HotelEase.Data;
using HotelEase.Models;
using Microsoft.AspNetCore.Http;

namespace HotelEase.Services;

public class AuditService : IAuditService
{
    private readonly ApplicationDbContext _db;
    private readonly IHttpContextAccessor _http;

    public AuditService(ApplicationDbContext db, IHttpContextAccessor http)
    {
        _db = db;
        _http = http;
    }

    public async Task LogAsync(string action, string entityType, int? entityId = null, string? details = null, int? userId = null, string? userName = null)
    {
        var session = _http.HttpContext?.Session;
        var uid = userId ?? session?.GetInt32("UserId");
        var name = userName
            ?? session?.GetString("UserFullName")
            ?? session?.GetString("FullName")
            ?? session?.GetString("Username");

        _db.AuditLogs.Add(new AuditLog
        {
            Action = Truncate(action, 100),
            EntityType = Truncate(entityType, 100),
            EntityId = entityId,
            Details = Truncate(details, 500),
            UserId = uid,
            UserName = Truncate(name, 100),
            CreatedAt = DateTime.UtcNow
        });
        await _db.SaveChangesAsync();
    }

    private static string Truncate(string? value, int max)
    {
        if (string.IsNullOrEmpty(value)) return value ?? string.Empty;
        return value.Length <= max ? value : value[..max];
    }
}
