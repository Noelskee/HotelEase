namespace HotelEase.Services;

public interface IAuditService
{
    /// <summary>
    /// Record a sensitive operation. Role is resolved from the User row when UserId is set.
    /// </summary>
    Task LogAsync(string action, string entityType, int? entityId = null, string? details = null, int? userId = null, string? userName = null);
}
