using HotelEase.Models;

namespace HotelEase.Services;

public interface IBillingService
{
    /// <summary>
    /// Computes billing for a reservation.
    /// Applies 20% discount for Senior Citizens (RA 9994) or PWD (RA 10754).
    /// </summary>
    BillingResult ComputeBilling(
        decimal ratePerNight,
        int numberOfNights,
        DiscountType discountType,
        decimal additionalCharges = 0,
        int extraHours = 0,
        decimal extraHourRate = 0,
        decimal extensionCharge = 0);

    /// <summary>
    /// Computes billing for a duration-based reservation (3 / 12 / 24 hours)
    /// including extra persons, extra beds, and extra hours.
    /// </summary>
    BillingResult ComputeDurationBilling(
        RoomType roomType,
        int durationHours,
        DiscountType discountType,
        int extraPersons = 0,
        int extraBeds = 0,
        int extraHours = 0,
        decimal extensionCharge = 0);

    /// <summary>
    /// Single source of truth for the full billing breakdown shown on the
    /// Reservation Details page, the Check-Out page, and the Official
    /// Receipt. Every charge is passed in and counted exactly once — the
    /// caller must never separately add a charge that is already reflected
    /// in one of these parameters (e.g. never add Extension Charge again
    /// on top of a room charge that already spans the extended nights).
    /// </summary>
    /// <param name="baseRoomCharge">Room rate × original nights (or the flat duration rate), BEFORE discount, extension, or extras.</param>
    /// <param name="discountRatePercent">Senior/PWD discount rate as a percentage (e.g. 20 for 20%). Applies only to baseRoomCharge.</param>
    /// <param name="extensionCharge">Total Stay Extension charge (already-elapsed extensions), a single cumulative figure — never re-derived from an inflated night/hour count.</param>
    /// <param name="extraPersons">Current number of extra persons on the reservation.</param>
    /// <param name="extraBeds">Current number of extra beds on the reservation.</param>
    /// <param name="extraHoursCharge">Late check-out / early check-in Extra Hours charge, if any.</param>
    /// <param name="otherManualCharges">Manually-selected check-out charges only (e.g. Damages) — never extra persons/beds.</param>
    /// <param name="alreadyPaidAmount">Amount already collected from the guest (e.g. Transaction.AmountPaidAtCheckIn when settling at Check-Out) that must NOT be billed again. Subtracted from TotalDue only — never affects Subtotal/RoomChargesTotal, which always reflect the full current charges for display purposes.</param>
    BillingBreakdown ComputeBreakdown(
        decimal baseRoomCharge,
        decimal discountRatePercent,
        decimal extensionCharge = 0,
        int extraPersons = 0,
        int extraBeds = 0,
        decimal extraHoursCharge = 0,
        decimal otherManualCharges = 0,
        decimal alreadyPaidAmount = 0);
}

/// <summary>
/// Full billing breakdown. Mirrors the "Room Charge / Stay Extension /
/// Extra Person / Extra Bed / Room Charges Total / Current
/// Total / Amount Due" layout used consistently across
/// Reservation Details, Check-Out, and the Official Receipt.
/// </summary>
public class BillingBreakdown
{
    public decimal BaseRoomCharge { get; set; }
    public decimal DiscountRate { get; set; }
    public decimal DiscountAmount { get; set; }
    public decimal ExtensionCharge { get; set; }
    public int ExtraPersons { get; set; }
    public int ExtraBeds { get; set; }
    public decimal ExtraPersonCharge { get; set; }
    public decimal ExtraBedCharge { get; set; }
    public decimal ExtraHoursCharge { get; set; }
    public decimal OtherManualCharges { get; set; }

    /// <summary>BaseRoomCharge − DiscountAmount + ExtensionCharge + ExtraPersonCharge + ExtraBedCharge + ExtraHoursCharge + OtherManualCharges.</summary>
    public decimal RoomChargesTotal { get; set; }

    /// <summary>Same as RoomChargesTotal — kept as a separate property since Check-Out and the Receipt display it as "Subtotal".</summary>
    public decimal Subtotal { get; set; }

    /// <summary>Amount already collected from the guest previously (e.g. at Check-In), excluded from TotalDue so it is never billed twice.</summary>
    public decimal AlreadyPaidAmount { get; set; }

    /// <summary>Subtotal − AlreadyPaidAmount. The grand total ("Current Total" / "Amount Due" / "Total Amount Paid").</summary>
    public decimal TotalDue { get; set; }
}

public class BillingResult
{
    public decimal RatePerNight { get; set; }
    public int NumberOfNights { get; set; }
    public int DurationHours { get; set; }
    public decimal Subtotal { get; set; }
    public DiscountType DiscountType { get; set; }
    public decimal DiscountRate { get; set; }
    public decimal DiscountAmount { get; set; }
    public decimal AdditionalCharges { get; set; }
    public int ExtraPersons { get; set; }
    public int ExtraBeds { get; set; }
    public int ExtraHours { get; set; }
    public decimal ExtraHourRate { get; set; }
    public decimal ExtraHoursCharge { get; set; }
    public decimal ExtensionCharge { get; set; }
    public decimal TotalAmount { get; set; }
    public decimal FinalAmount { get; set; }
    public string DiscountLegalBasis { get; set; } = string.Empty;
}
