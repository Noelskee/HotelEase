using HotelEase.Models;

namespace HotelEase.Services;

/// <summary>
/// Computes billing per Philippine law:
///   - Senior Citizens: 20% discount under RA 9994 (Expanded Senior Citizens Act of 2010)
///   - PWD: 20% discount under RA 10754 (An Act Expanding the Benefits and Privileges of Persons with Disability)
///
/// Updated for Alemar Budgetel duration-based pricing (3 / 12 hour short stays and nightly stays)
/// plus extra-person (₱300) and extra-bed (₱400) charges.
/// </summary>
public class BillingService : IBillingService
{
    private const decimal SeniorDiscountRate = 0.20m;
    private const decimal PwdDiscountRate = 0.20m;

    public const decimal ExtraPersonCharge = 300.00m;
    public const decimal ExtraBedCharge = 400.00m;

    public BillingResult ComputeBilling(
        decimal ratePerNight,
        int numberOfNights,
        DiscountType discountType,
        decimal additionalCharges = 0,
        int extraHours = 0,
        decimal extraHourRate = 0,
        decimal extensionCharge = 0)
    {
        var subtotal = ratePerNight * numberOfNights;

        decimal discountRate = discountType switch
        {
            DiscountType.SeniorCitizen => SeniorDiscountRate,
            DiscountType.PWD => PwdDiscountRate,
            _ => 0m
        };

        var discountAmount = subtotal * discountRate;
        var totalAfterDiscount = subtotal - discountAmount;
        var extraHoursCharge = extraHours * extraHourRate;
        var finalAmount = totalAfterDiscount + extraHoursCharge + additionalCharges + extensionCharge;

        string legalBasis = discountType switch
        {
            DiscountType.SeniorCitizen => "Republic Act No. 9994 – Expanded Senior Citizens Act of 2010",
            DiscountType.PWD => "Republic Act No. 10754 – Act Expanding Benefits/Privileges of Persons with Disability",
            _ => string.Empty
        };

        return new BillingResult
        {
            RatePerNight = ratePerNight,
            NumberOfNights = numberOfNights,
            Subtotal = subtotal,
            DiscountType = discountType,
            DiscountRate = discountRate * 100,
            DiscountAmount = discountAmount,
            AdditionalCharges = additionalCharges,
            ExtraHours = extraHours,
            ExtraHourRate = extraHourRate,
            ExtraHoursCharge = extraHoursCharge,
            ExtensionCharge = extensionCharge,
            TotalAmount = totalAfterDiscount,
            FinalAmount = finalAmount,
            DiscountLegalBasis = legalBasis
        };
    }

    /// <summary>
    /// Computes billing for a duration-based reservation (3 / 12 / 24 hours).
    /// </summary>
    public BillingResult ComputeDurationBilling(
        RoomType roomType,
        int durationHours,
        DiscountType discountType,
        int extraPersons = 0,
        int extraBeds = 0,
        int extraHours = 0,
        decimal extensionCharge = 0)
    {
        var baseRate = roomType.GetRateForDuration(durationHours);
        var extraHourRate = roomType.GetExtraHourRateForDuration(durationHours);
        var additionalCharges = extraPersons * ExtraPersonCharge + extraBeds * ExtraBedCharge;

        var result = ComputeBilling(
            baseRate,
            1, // duration rate is a single charge
            discountType,
            additionalCharges,
            extraHours,
            extraHourRate,
            extensionCharge);

        result.DurationHours = durationHours;
        result.ExtraPersons = extraPersons;
        result.ExtraBeds = extraBeds;
        return result;
    }

    /// <summary>
    /// Single source of truth for the full billing breakdown. Every charge
    /// is counted exactly once here; callers pass in raw component values
    /// (never pre-combined totals) so nothing can be double counted.
    /// See doc comments on <see cref="IBillingService.ComputeBreakdown"/>.
    /// </summary>
    public BillingBreakdown ComputeBreakdown(
        decimal baseRoomCharge,
        decimal discountRatePercent,
        decimal extensionCharge = 0,
        int extraPersons = 0,
        int extraBeds = 0,
        decimal extraHoursCharge = 0,
        decimal otherManualCharges = 0,
        decimal alreadyPaidAmount = 0)
    {
        var discountAmount = baseRoomCharge * (discountRatePercent / 100m);
        var extraPersonCharge = extraPersons * ExtraPersonCharge;
        var extraBedCharge = extraBeds * ExtraBedCharge;

        var roomChargesTotal =
            (baseRoomCharge - discountAmount)
            + extensionCharge
            + extraPersonCharge
            + extraBedCharge
            + extraHoursCharge
            + otherManualCharges;

        var subtotal = roomChargesTotal;
        // alreadyPaidAmount (e.g. the room charge collected at Check-In)
        // is subtracted here only — never from Subtotal/RoomChargesTotal,
        // which keep showing the full current charges for the billing
        // statement — so a charge already collected is never billed to
        // the guest a second time.
        var totalDue = subtotal - alreadyPaidAmount;

        return new BillingBreakdown
        {
            BaseRoomCharge = baseRoomCharge,
            DiscountRate = discountRatePercent,
            DiscountAmount = discountAmount,
            ExtensionCharge = extensionCharge,
            ExtraPersons = extraPersons,
            ExtraBeds = extraBeds,
            ExtraPersonCharge = extraPersonCharge,
            ExtraBedCharge = extraBedCharge,
            ExtraHoursCharge = extraHoursCharge,
            OtherManualCharges = otherManualCharges,
            RoomChargesTotal = roomChargesTotal,
            Subtotal = subtotal,
            AlreadyPaidAmount = alreadyPaidAmount,
            TotalDue = totalDue
        };
    }
}
