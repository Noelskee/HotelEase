using HotelEase.Data;
using HotelEase.Models;
using Microsoft.EntityFrameworkCore;

namespace HotelEase.Services;

public class ReservationService : IReservationService
{
    private readonly ApplicationDbContext _db;

    public ReservationService(ApplicationDbContext db)
    {
        _db = db;
    }

    public string GenerateReferenceNumber()
    {
        var now = DateTime.Now;
        // Keep the reference number within the 20-character limit of the
        // ReferenceNumber column (ALE-yyMMddHHmmss-XX = 18 chars).
        var timestamp = now.ToString("yyMMddHHmmss");
        var random = new Random();
        var suffix = random.Next(0, 100).ToString("D2");
        return $"ALE-{timestamp}-{suffix}";
    }

    // A room is available when it is physically usable AND has no active
    // reservation that overlaps the requested stay window. A future
    // reservation outside the requested dates does not block the room.
    private static bool Overlaps(DateTime startA, DateTime endA, DateTime startB, DateTime endB)
        => startA < endB && endA > startB;

    private static (DateTime Start, DateTime End) GetReservationWindow(Reservation r)
    {
        var start = r.ExpectedCheckIn ?? r.CheckInDate ?? DateTime.MinValue;
        var end = r.ExpectedCheckOut ?? r.CheckOutDate ?? start.AddDays(1);
        if (end <= start)
            end = start.AddDays(1);
        return (start, end);
    }

    private static bool IsTerminal(ReservationStatus status)
        => status is ReservationStatus.Cancelled
            or ReservationStatus.CheckedOut
            or ReservationStatus.Completed
            or ReservationStatus.NoShow;

    // SINGLE SOURCE OF TRUTH for "which rooms may be offered for this stay".
    // Used by Booking, Walk-In, Check-In, Reschedule and Room Transfer so the
    // UI lists only selectable rooms. excludeReservationId lets a reservation
    // ignore its OWN booking (Check-In / Reschedule / Transfer), so the room it
    // already holds stays visible while other guests' rooms are hidden.
    public async Task<List<Room>> GetAvailableRoomsAsync(DateTime checkIn, DateTime checkOut, int? excludeReservationId = null)
    {
        if (checkOut <= checkIn)
            checkOut = checkIn.AddDays(1);

        // Maintenance rooms are physically out of service at all times.
        // For immediate stays (starting within 2 hours), occupied and cleaning rooms are unavailable.
        // For future stays, occupied/cleaning rooms can be booked in advance as current stays end
        // according to their reservation dates (checked against activeAssigned below).
        var isImmediate = checkIn <= DateTime.Now.AddHours(2);
        var candidateQuery = _db.Rooms
            .Include(r => r.RoomType)
                .ThenInclude(rt => rt!.RoomTypeAmenities)
                    .ThenInclude(rta => rta.Amenity)
            .Include(r => r.RoomType)
                .ThenInclude(rt => rt!.Images)
            .Where(r => r.Status != RoomStatus.Maintenance);

        if (isImmediate)
        {
            candidateQuery = candidateQuery.Where(r => r.Status == RoomStatus.Available || r.Status == RoomStatus.Reserved);
        }

        var candidateRooms = await candidateQuery
            .OrderBy(r => r.RoomNumber)
            .ToListAsync();

        var candidateIds = candidateRooms.Select(r => r.Id).ToHashSet();
        if (candidateIds.Count == 0)
            return candidateRooms;

        var activeAssigned = await _db.Reservations
            .Where(r => r.RoomId != null
                && candidateIds.Contains(r.RoomId.Value)
                && (r.Status != ReservationStatus.Cancelled && r.Status != ReservationStatus.CheckedOut && r.Status != ReservationStatus.Completed && r.Status != ReservationStatus.NoShow)
                && (!excludeReservationId.HasValue || r.Id != excludeReservationId.Value))
            .Select(r => new
            {
                r.RoomId,
                r.ExpectedCheckIn,
                r.ExpectedCheckOut,
                r.CheckInDate,
                r.CheckOutDate
            })
            .ToListAsync();

        var blockedRoomIds = activeAssigned
            .Where(r =>
            {
                var start = r.ExpectedCheckIn ?? r.CheckInDate ?? DateTime.MinValue;
                var end = r.ExpectedCheckOut ?? r.CheckOutDate ?? start.AddDays(1);
                if (end <= start) end = start.AddDays(1);
                return Overlaps(start, end, checkIn, checkOut);
            })
            .Select(r => r.RoomId!.Value)
            .ToHashSet();

        var available = candidateRooms
            .Where(r => !blockedRoomIds.Contains(r.Id))
            .ToList();

        // Unassigned active reservations consume one room slot only when their
        // requested stay overlaps the search window.
        var typeHolds = await _db.Reservations
            .Where(r => r.RoomId == null
                && r.PreferredRoomTypeId != null
                && (r.Status != ReservationStatus.Cancelled && r.Status != ReservationStatus.CheckedOut && r.Status != ReservationStatus.Completed && r.Status != ReservationStatus.NoShow)
                && (!excludeReservationId.HasValue || r.Id != excludeReservationId.Value))
            .Select(r => new
            {
                r.PreferredRoomTypeId,
                r.ExpectedCheckIn,
                r.ExpectedCheckOut,
                r.CheckInDate,
                r.CheckOutDate
            })
            .ToListAsync();

        var overlappingHolds = typeHolds
            .Where(r =>
            {
                var start = r.ExpectedCheckIn ?? r.CheckInDate ?? DateTime.MinValue;
                var end = r.ExpectedCheckOut ?? r.CheckOutDate ?? start.AddDays(1);
                if (end <= start) end = start.AddDays(1);
                return Overlaps(start, end, checkIn, checkOut);
            })
            .GroupBy(r => r.PreferredRoomTypeId!.Value)
            .ToDictionary(g => g.Key, g => g.Count());

        var result = new List<Room>();
        foreach (var group in available.GroupBy(r => r.RoomTypeId))
        {
            var hold = overlappingHolds.GetValueOrDefault(group.Key, 0);
            result.AddRange(group.Take(Math.Max(0, group.Count() - hold)));
        }

        return result.OrderBy(r => r.RoomNumber).ToList();
    }

    // Direct walk-in/check-in happens immediately, so the default window is
    // now through the next 24 hours. Callers that know the exact stay window
    // may supply it to get precise overlap checking.
    public async Task<List<Room>> GetAvailableRoomsForWalkInAsync(DateTime? checkIn = null, DateTime? checkOut = null)
    {
        var start = checkIn ?? DateTime.Now;
        var end = checkOut ?? start.AddHours(24);
        return await GetAvailableRoomsAsync(start, end);
    }

    public Task<int> GetAvailableCapacityForRoomTypeAsync(
        int roomTypeId, DateTime checkIn, DateTime checkOut, int? excludeReservationId = null)
        => GetAvailableCapacityForRoomTypeAsync(roomTypeId, checkIn, checkOut,
            excludeReservationId.HasValue ? new[] { excludeReservationId.Value } : Array.Empty<int>());

    // Overload used by Reschedule of a multi-room group: every reservation
    // being moved is excluded so it does not count against itself.
    public async Task<int> GetAvailableCapacityForRoomTypeAsync(
        int roomTypeId, DateTime checkIn, DateTime checkOut, IEnumerable<int> excludeReservationIds)
    {
        var excluded = excludeReservationIds.ToHashSet();
        var isImmediate = checkIn <= DateTime.Now.AddHours(2);
        var roomsQuery = _db.Rooms
            .Where(r => r.RoomTypeId == roomTypeId && r.Status != RoomStatus.Maintenance);
        if (isImmediate)
        {
            roomsQuery = roomsQuery.Where(r => r.Status == RoomStatus.Available || r.Status == RoomStatus.Reserved);
        }
        var rooms = await roomsQuery
            .Select(r => r.Id)
            .ToListAsync();

        if (rooms.Count == 0)
            return 0;

        var activeAssigned = await _db.Reservations
            .Where(r => r.RoomId != null
                && rooms.Contains(r.RoomId.Value)
                && (r.Status != ReservationStatus.Cancelled && r.Status != ReservationStatus.CheckedOut && r.Status != ReservationStatus.Completed && r.Status != ReservationStatus.NoShow)
                && !excluded.Contains(r.Id))
            .Select(r => new
            {
                RoomId = r.RoomId!.Value,
                r.ExpectedCheckIn,
                r.ExpectedCheckOut,
                r.CheckInDate,
                r.CheckOutDate
            })
            .ToListAsync();

        var blockedIds = activeAssigned
            .Where(r =>
            {
                var start = r.ExpectedCheckIn ?? r.CheckInDate ?? DateTime.MinValue;
                var end = r.ExpectedCheckOut ?? r.CheckOutDate ?? start.AddDays(1);
                if (end <= start) end = start.AddDays(1);
                return Overlaps(start, end, checkIn, checkOut);
            })
            .Select(r => r.RoomId)
            .ToHashSet();

        var available = rooms.Count - blockedIds.Count;

        var holds = await _db.Reservations
            .Where(r => r.RoomId == null
                && r.PreferredRoomTypeId == roomTypeId
                && (r.Status != ReservationStatus.Cancelled && r.Status != ReservationStatus.CheckedOut && r.Status != ReservationStatus.Completed && r.Status != ReservationStatus.NoShow)
                && !excluded.Contains(r.Id))
            .Select(r => new
            {
                r.ExpectedCheckIn,
                r.ExpectedCheckOut,
                r.CheckInDate,
                r.CheckOutDate
            })
            .ToListAsync();

        var overlappingHolds = holds.Count(r =>
        {
            var start = r.ExpectedCheckIn ?? r.CheckInDate ?? DateTime.MinValue;
            var end = r.ExpectedCheckOut ?? r.CheckOutDate ?? start.AddDays(1);
            if (end <= start) end = start.AddDays(1);
            return Overlaps(start, end, checkIn, checkOut);
        });

        return Math.Max(0, available - overlappingHolds);
    }

    // Determines whether a physical room can be selected for the requested
    // stay window. Any active reservation overlapping the requested window
    // blocks the room. Terminal reservations do not block it.
    public bool IsRoomAvailable(int roomId, DateTime checkIn, DateTime checkOut, int? excludeReservationId = null)
    {
        var room = _db.Rooms.AsNoTracking().FirstOrDefault(r => r.Id == roomId);
        if (room == null || room.Status == RoomStatus.Maintenance)
            return false;

        var isImmediate = checkIn <= DateTime.Now.AddHours(2);
        if (isImmediate && (room.Status == RoomStatus.Occupied || room.Status == RoomStatus.ForCleaning))
            return false;

        if (checkOut <= checkIn)
            checkOut = checkIn.AddDays(1);

        var reservations = _db.Reservations
            .Where(r => r.RoomId == roomId && (r.Status != ReservationStatus.Cancelled && r.Status != ReservationStatus.CheckedOut && r.Status != ReservationStatus.Completed && r.Status != ReservationStatus.NoShow));

        if (excludeReservationId.HasValue)
            reservations = reservations.Where(r => r.Id != excludeReservationId.Value);

        foreach (var reservation in reservations.ToList())
        {
            var (start, end) = GetReservationWindow(reservation);
            if (Overlaps(start, end, checkIn, checkOut))
                return false;
        }

        return true;
    }

}
