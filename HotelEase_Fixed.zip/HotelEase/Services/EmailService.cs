using System.Net;
using System.Net.Mail;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace HotelEase.Services;

// Reads hotel SMTP settings from appsettings.json ("Smtp" section). Until
// those are filled in with a real mail account, SendAsync just logs the
// message instead of sending it, so reservation submission never fails or
// blocks on email — set Smtp:Host in appsettings.json (or an environment
// variable / user-secret override) to start sending for real.
public class EmailService : IEmailService
{
    private readonly IConfiguration _config;
    private readonly ILogger<EmailService> _logger;

    public EmailService(IConfiguration config, ILogger<EmailService> logger)
    {
        _config = config;
        _logger = logger;
    }

    public async Task<bool> SendAsync(string toAddress, string subject, string htmlBody)
    {
        if (string.IsNullOrWhiteSpace(toAddress))
            return false;

        var host = _config["Smtp:Host"];
        if (string.IsNullOrWhiteSpace(host))
        {
            _logger.LogInformation(
                "Smtp:Host is not configured — skipping email send. Would have sent \"{Subject}\" to {To}.",
                subject, toAddress);
            return false;
        }

        var port = _config.GetValue<int?>("Smtp:Port") ?? 587;
        var enableSsl = _config.GetValue<bool?>("Smtp:EnableSsl") ?? true;
        var username = _config["Smtp:Username"];
        var password = _config["Smtp:Password"];
        var fromAddress = _config["Smtp:FromAddress"] ?? username ?? "no-reply@alemarbudgetel.example";
        var fromName = _config["Smtp:FromName"] ?? "Alemar Budgetel — HotelEase";

        try
        {
            using var message = new MailMessage
            {
                From = new MailAddress(fromAddress, fromName),
                Subject = subject,
                Body = htmlBody,
                IsBodyHtml = true
            };
            message.To.Add(toAddress);

            using var client = new SmtpClient(host, port)
            {
                EnableSsl = enableSsl,
                // Cap this well below the default 100s. If the SMTP host on
                // the hosting provider is unreachable or misconfigured, the
                // reservation submit button must not appear to hang for a
                // minute-plus waiting on a mail server that isn't there.
                Timeout = 8000
            };
            if (!string.IsNullOrWhiteSpace(username))
            {
                client.Credentials = new NetworkCredential(username, password);
            }

            await client.SendMailAsync(message);
            return true;
        }
        catch (Exception ex)
        {
            // Never let a mail failure break the reservation flow.
            _logger.LogWarning(ex, "Failed to send email \"{Subject}\" to {To}.", subject, toAddress);
            return false;
        }
    }
}
