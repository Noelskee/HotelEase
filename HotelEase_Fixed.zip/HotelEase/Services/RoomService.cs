using HotelEase.Data;
using HotelEase.Models;

namespace HotelEase.Services;

public class RoomService : IRoomService
{
    private readonly ApplicationDbContext _db;

    public RoomService(ApplicationDbContext db)
    {
        _db = db;
    }

    public async Task UpdateRoomStatusAsync(int roomId, RoomStatus newStatus, int updatedByUserId, string? notes = null)
    {
        var room = await _db.Rooms.FindAsync(roomId)
            ?? throw new InvalidOperationException("Room not found.");

        var oldStatus = room.Status;
        room.Status = newStatus;

        _db.AuditLogs.Add(new AuditLog
        {
            Action = "update_room_status",
            EntityType = "Room",
            EntityId = roomId,
            UserId = updatedByUserId,
            Details = $"{oldStatus} → {newStatus}" + (notes != null ? $" | {notes}" : string.Empty),
            CreatedAt = DateTime.UtcNow
        });

        await _db.SaveChangesAsync();
    }
}
