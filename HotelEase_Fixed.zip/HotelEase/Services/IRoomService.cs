using HotelEase.Models;

namespace HotelEase.Services;

public interface IRoomService
{
    Task UpdateRoomStatusAsync(int roomId, RoomStatus newStatus, int updatedByUserId, string? notes = null);
}
