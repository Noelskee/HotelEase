using System.ComponentModel.DataAnnotations;

namespace HotelEase.Models
{
    public enum RoomStatus { Available, Reserved, Occupied, ForCleaning, Maintenance }

    public class Room
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Room Type")]
        public int RoomTypeId { get; set; }
        public RoomType? RoomType { get; set; }

        [Required, StringLength(10)]
        [Display(Name = "Room Number")]
        public string RoomNumber { get; set; } = string.Empty;

        [StringLength(10)]
        public string? Floor { get; set; }

        [Required]
        public RoomStatus Status { get; set; } = RoomStatus.Available;

        [StringLength(500)]
        public string? Description { get; set; }

        [StringLength(500)]
        [Display(Name = "Image URL")]
        public string? ImageUrl { get; set; }

        // Navigation added for the Reservation module and the housekeeping
        // audit log (each room-status change is recorded via RoomService).
        public ICollection<Reservation> Reservations { get; set; } = new List<Reservation>();

    }
}
