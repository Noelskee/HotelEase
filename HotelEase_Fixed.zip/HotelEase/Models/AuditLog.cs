using System.ComponentModel.DataAnnotations;

namespace HotelEase.Models;

/// <summary>
/// Immutable audit trail of sensitive operations.
/// UserId is the FK source of truth; UserName is intentionally retained as a
/// historical snapshot so the log remains readable if the User row is later renamed/deleted.
/// </summary>
public class AuditLog
{
    public int Id { get; set; }

    [MaxLength(100)]
    public string Action { get; set; } = string.Empty;

    [MaxLength(100)]
    public string EntityType { get; set; } = string.Empty;

    public int? EntityId { get; set; }

    [MaxLength(500)]
    public string? Details { get; set; }

    public int? UserId { get; set; }
    public User? User { get; set; }

    /// <summary>Historical display name snapshot (not a second live identity).</summary>
    [MaxLength(100)]
    public string? UserName { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
