using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HotelEase.Models;

public enum ReservationStatus
{
    Pending,
    Confirmed,
    Reserved,
    CheckedIn,
    CheckedOut,
    Completed,
    Cancelled,
    NoShow
}

public enum PaymentStatus
{
    Unpaid,
    PartiallyPaid,
    Paid
}

// "Reservation Type" in the UI — how the reservation was made. Kept as the
// C# name ReservationType/Type for schema/back-compat. Staff new reservations
// use Phone or Walk-In only; Online is created via the public web module.
// Direct Walk-In (immediate check-in) also uses WalkIn.
public enum ReservationType
{
    Online,
    WalkIn,
    Phone,
    TravelAgency,
    FrontDesk
}

public static class ReservationTypeExtensions
{
    // Human-readable "Reservation Type" label.
    // Staff types: Phone, Walk-In. Online stays Online. Legacy FrontDesk/TravelAgency map to Walk-In.
    public static string BookingSourceLabel(this ReservationType type) => type switch
    {
        ReservationType.Online => "Online",
        ReservationType.WalkIn => "Walk-In",
        ReservationType.Phone => "Phone",
        ReservationType.FrontDesk => "Walk-In",
        ReservationType.TravelAgency => "Walk-In",
        _ => type.ToString()
    };
}

public enum StayType
{
    Hourly,
    Nightly
}

public class Reservation
{
    public int Id { get; set; }

    [Required, MaxLength(30)]
    [Display(Name = "Reference No.")]
    public string ReferenceNumber { get; set; } = string.Empty;

    [Required]
    [Display(Name = "Guest")]
    public int GuestId { get; set; }

    // Physical room may be chosen at booking (online/walk-in room-number
    // selection) or left null until Check-In (type-only / TBA holds).
    // PreferredRoomTypeId is always the booked type; RoomId is the concrete
    // room when already assigned.
    [Display(Name = "Room")]
    public int? RoomId { get; set; }

    [Display(Name = "Preferred Room Type")]
    public int? PreferredRoomTypeId { get; set; }

    public RoomType? PreferredRoomType { get; set; }

    // Date model (normalized intent):
    //   ExpectedCheckIn / ExpectedCheckOut = scheduled stay window (primary for availability)
    //   ActualCheckIn / ActualCheckOut     = real timestamps at front desk
    //   CheckInDate / CheckOutDate         = legacy date-only mirrors still used by some
    //                                       availability indexes and older screens; kept in sync
    //                                       with Expected* where the code already does so.
    // Do not introduce additional parallel date columns.
    [DataType(DataType.Date)]
    [Display(Name = "Check-In Date")]
    public DateTime? CheckInDate { get; set; }

    [DataType(DataType.Date)]
    [Display(Name = "Check-Out Date")]
    public DateTime? CheckOutDate { get; set; }

    [Required]
    [Display(Name = "Stay Type")]
    public StayType StayType { get; set; } = StayType.Hourly;

    [Required]
    [Display(Name = "Number of Guests")]
    /// <summary>Party size for this booking. Prefer Adults + Children; GuestCount should equal Adults + Children.</summary>
    public int GuestCount { get; set; } = 1;

    [Display(Name = "Adults")]
    [Range(1, 20, ErrorMessage = "Adults must be between 1 and 20.")]
    public int Adults { get; set; } = 1;

    [Display(Name = "Children")]
    [Range(0, 20, ErrorMessage = "Children must be between 0 and 20.")]
    public int Children { get; set; } = 0;

    // Duration-based pricing support for Alemar Budgetel short stays.
    [Required]
    [Display(Name = "Duration")]
    [Range(1, 24, ErrorMessage = "Duration must be 3, 12, or 24 hours.")]
    public int DurationHours { get; set; } = 24;

    [Display(Name = "Number of Nights")]
    [Range(1, 30, ErrorMessage = "Number of nights must be between 1 and 30.")]
    public int NumberOfNights { get; set; } = 1;

    [Display(Name = "Extra Persons")]
    [Range(0, 20, ErrorMessage = "Extra persons must be between 0 and 20.")]
    public int ExtraPersons { get; set; } = 0;

    [Display(Name = "Extra Beds")]
    [Range(0, 10, ErrorMessage = "Extra beds must be between 0 and 10.")]
    public int ExtraBeds { get; set; } = 0;

    // How many rooms of this type the guest asked for on the online form.
    // Only one physical Room (RoomId, above) is actually assigned/reserved
    // automatically; if this is more than 1, front desk assigns the
    // additional physical rooms manually (see Reservation/Details).
    [Required, Range(1, 10)]
    [Display(Name = "Rooms")]
    public int RoomsRequested { get; set; } = 1;

    [Required]
    public ReservationStatus Status { get; set; } = ReservationStatus.Pending;

    [Required]
    [Display(Name = "Payment Status")]
    public PaymentStatus PaymentStatus { get; set; } = PaymentStatus.Unpaid;

    // Reservation Type — how this reservation was made (Phone, Walk-In, Online).
    // Direct Walk-In and in-person future bookings use WalkIn; phone bookings use Phone;
    // public web bookings use Online.
    [Required]
    [Display(Name = "Reservation Type")]
    public ReservationType Type { get; set; } = ReservationType.Online;

    [Display(Name = "Expected Check-In")]
    public DateTime? ExpectedCheckIn { get; set; }

    [Display(Name = "Actual Check-In")]
    public DateTime? ActualCheckIn { get; set; }

    [Display(Name = "Expected Check-Out")]
    public DateTime? ExpectedCheckOut { get; set; }

    [Display(Name = "Actual Check-Out")]
    public DateTime? ActualCheckOut { get; set; }

    [MaxLength(200)]
    [Display(Name = "Special Requests")]
    public string? SpecialRequests { get; set; }

    // Payment reference for online reservations
    [MaxLength(100)]
    [Display(Name = "Payment Reference")]
    public string? PaymentReference { get; set; }

    public bool IsPaymentVerified { get; set; } = false;

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public int? CreatedByUserId { get; set; }

    [MaxLength(500)]
    public string? CancellationReason { get; set; }

    // Pre-check-in extra hours recorded by front-desk staff on Confirmed
    // reservations before the guest arrives. These are carried into the
    // Transaction at Check-In so the guest is billed for them up front.
    [Display(Name = "Extra Hours")]
    public int ExtraHours { get; set; } = 0;

    [Display(Name = "Extra Hour Rate (₱/hour)")]
    [Column(TypeName = "decimal(10,2)")]
    public decimal ExtraHourRate { get; set; } = 0;

    [Display(Name = "Extra Hours Charge (₱)")]
    [Column(TypeName = "decimal(10,2)")]
    public decimal ExtraHoursCharge { get; set; } = 0;

    [Display(Name = "Extra Charge (₱)")]
    [Column(TypeName = "decimal(10,2)")]
    public decimal ExtraCharge { get; set; } = 0;

    [Display(Name = "Extended Hours")]
    public int ExtendedHours { get; set; } = 0;

    [Display(Name = "Extended Nights")]
    public int ExtendedNights { get; set; } = 0;

    [Display(Name = "Extension Charge (₱)")]
    [Column(TypeName = "decimal(10,2)")]
    public decimal ExtensionCharge { get; set; } = 0;

    [MaxLength(500), Display(Name = "Extra Hours Notes")]
    public string? ExtraHoursNotes { get; set; }

    // Ages of any children on this reservation (children don't count toward
    // room occupancy — they stay free — but their ages are still recorded).
    // Stored as a comma-separated list, e.g. "3,7", one entry per child.
    [MaxLength(200)]
    [Display(Name = "Children's Ages")]
    public string? ChildrenAges { get; set; }

    // Navigation
    public Guest Guest { get; set; } = null!;
    public Room Room { get; set; } = null!;
    public User? CreatedByUser { get; set; }
    public Transaction? Transaction { get; set; }

    // True when the guest chose a nightly stay. Drives the "Stay" badge, the
    // contextual Add Extra Hours/Days action, and the nightly fixed
    // check-out policy.
    [NotMapped]
    public bool IsNightlyStay => StayType == StayType.Nightly;

    // Remaining time before expected check-out. Used on the reservation
    // details page while the guest is checked in.
    [NotMapped]
    public TimeSpan? RemainingTime =>
        Status == ReservationStatus.CheckedIn && ExpectedCheckOut.HasValue
            ? (ExpectedCheckOut.Value - DateTime.Now) > TimeSpan.Zero
                ? ExpectedCheckOut.Value - DateTime.Now
                : TimeSpan.Zero
            : null;

    // Check-out policy for nightly stays: 12:00 PM on the departure day.
    public static readonly TimeSpan NightlyCheckoutTime = TimeSpan.FromHours(12);
}
