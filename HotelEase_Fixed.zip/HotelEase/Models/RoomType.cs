using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HotelEase.Models
{
    public class RoomType
    {
        public int Id { get; set; }

        [Required, StringLength(100)]
        public string Name { get; set; } = string.Empty;

        // The original BaseRate column represents the nightly base rate. It is also
        // used as the 24-hour duration rate for hourly stays, preserving existing
        // code paths that read BaseRate. The UI label is restored to "Base Rate / Night".
        [Required]
        [Display(Name = "Base Rate / Night")]
        [Column(TypeName = "decimal(10,2)")]
        [Range(0, 1000000, ErrorMessage = "Base Rate must be a positive amount.")]
        public decimal BaseRate { get; set; }

        [NotMapped]
        [Display(Name = "Base Rate / Night")]
        public decimal RateNightly => BaseRate;

        [NotMapped]
        [Obsolete("24-hour rate was removed in Alemar Budgetel; use RateNightly or BaseRate.")]
        public decimal Rate24Hours => BaseRate;

        // Alemar Budgetel short-stay duration rates.
        [Display(Name = "3 Hours Rate")]
        [Column(TypeName = "decimal(10,2)")]
        [Range(0, 1000000, ErrorMessage = "Rate must be a positive amount.")]
        public decimal Rate3Hours { get; set; }

        [Display(Name = "12 Hours Rate")]
        [Column(TypeName = "decimal(10,2)")]
        [Range(0, 1000000, ErrorMessage = "Rate must be a positive amount.")]
        public decimal Rate12Hours { get; set; }

        [StringLength(500)]
        public string? Description { get; set; }

        [Required]
        [Display(Name = "Max Occupancy")]
        public int MaxOccupancy { get; set; } = 2;

        // Original ExtraHourRate column represents the extra-hour rate for 24-hour
        // (and 12-hour) stays. Use ExtraHourRate24Hours alias in new code.
        [Display(Name = "Extra Hour Rate (Nightly/12H) (₱/hour)")]
        [Column(TypeName = "decimal(10,2)")]
        [Range(0, 1000000, ErrorMessage = "Extra Hour Rate must be a positive amount.")]
        public decimal ExtraHourRate { get; set; } = 0;

        [NotMapped]
        [Display(Name = "Extra Hour Rate (Nightly/12H) (₱/hour)")]
        public decimal ExtraHourRate24Hours => ExtraHourRate;

        [Display(Name = "Extra Hour Rate 3H (₱/hour)")]
        [Column(TypeName = "decimal(10,2)")]
        [Range(0, 1000000, ErrorMessage = "Extra Hour Rate must be a positive amount.")]
        public decimal ExtraHourRate3Hours { get; set; } = 0;

        [StringLength(500)]
        [Display(Name = "Image URL")]
        public string? ImageUrl { get; set; }

        public ICollection<Room> Rooms { get; set; } = new List<Room>();

        // Hol_RoomAmenities — one row per (RoomType, Amenity).
        public ICollection<RoomTypeAmenity> RoomTypeAmenities { get; set; } = new List<RoomTypeAmenity>();

        // tbl_RoomNo — one row per room number assigned to this room type.
        public ICollection<RoomNoEntry> RoomNos { get; set; } = new List<RoomNoEntry>();

        // Room type images for the online reservation gallery.
        public ICollection<RoomTypeImage> Images { get; set; } = new List<RoomTypeImage>();

        // Comma-separated amenity names, derived from RoomTypeAmenities. Kept as "Amenities"
        // (read-only, not mapped to a column) so existing views/JS that display a CSV string
        // keep working unchanged. Requires RoomTypeAmenities.Amenity to be Included by the query.
        [NotMapped]
        public string Amenities =>
            string.Join(", ", RoomTypeAmenities
                .Where(rta => rta.Amenity != null)
                .OrderBy(rta => rta.Amenity!.Name)
                .Select(rta => rta.Amenity!.Name));

        // Consultation rate card defaults (used only when DB rate is still 0).
        // 3h: Single 250 | Standard/Double 300 | Deluxe 350 | Super Deluxe 380 | Super Duper 400
        // 24h/nightly: Single 800 | Standard/Double 1200 | Deluxe 1300 | Super Deluxe 1400 | Super Duper 1900
        private (decimal R3, decimal R12, decimal Nightly) DefaultRatesForName()
        {
            var n = (Name ?? "").Trim().ToUpperInvariant();
            if (n.Contains("SUPER DUPER") || n.Contains("SUPERDUPER")) return (400, 1150, 1900);
            if (n.Contains("SUPER DELUXE") || n.Contains("SUPERDELUXE")) return (380, 890, 1400);
            if (n.Contains("DELUXE")) return (350, 825, 1300);
            if (n.Contains("DOUBLE") || n.Contains("STANDARD")) return (300, 750, 1200);
            if (n.Contains("SINGLE")) return (250, 525, 800);
            return (250, 525, 800); // safe fallback
        }

        /// <summary>
        /// Duration-based price. If DB Rate3Hours/Rate12Hours/BaseRate is 0
        /// (common after schema add before seeder backfill), uses consultation defaults
        /// so Walk-In / Online never show ₱0.00 for known room types.
        /// </summary>
        public decimal GetRateForDuration(int hours)
        {
            var d = DefaultRatesForName();
            var r3 = Rate3Hours > 0 ? Rate3Hours : d.R3;
            var r12 = Rate12Hours > 0 ? Rate12Hours : d.R12;
            var nightly = BaseRate > 0 ? BaseRate : d.Nightly;
            return hours switch
            {
                <= 3 => r3,
                <= 12 => r12,
                _ => nightly
            };
        }

        /// <summary>
        /// Extra-hour rate for stay extensions. Uses DB values when set;
        /// otherwise Alemar consultation defaults by room type name.
        /// </summary>
        public decimal GetExtraHourRateForDuration(int hours)
        {
            if (hours <= 3 && ExtraHourRate3Hours > 0)
                return ExtraHourRate3Hours;
            if (hours > 3 && ExtraHourRate > 0)
                return ExtraHourRate;

            // Alemar-aligned defaults when DB extra-hour rates are still 0
            var n = (Name ?? "").Trim().ToUpperInvariant();
            decimal def3;
            decimal def12or24;
            if (n.Contains("SUPER DUPER") || n.Contains("SUPERDUPER"))
            { def3 = 150m; def12or24 = 100m; }
            else if (n.Contains("SUPER DELUXE") || n.Contains("SUPERDELUXE"))
            { def3 = 130m; def12or24 = 90m; }
            else if (n.Contains("DELUXE"))
            { def3 = 120m; def12or24 = 80m; }
            else if (n.Contains("DOUBLE") || n.Contains("STANDARD"))
            { def3 = 100m; def12or24 = 70m; }
            else if (n.Contains("SINGLE"))
            { def3 = 80m; def12or24 = 50m; }
            else
            { def3 = 100m; def12or24 = 70m; }

            return hours <= 3 ? def3 : def12or24;
        }

        public string GetDurationLabel(int hours) => hours switch
        {
            <= 3 => "3 Hours",
            <= 12 => "12 Hours",
            _ => "Nightly"
        };

        // URL of the primary image, or first uploaded image, or legacy ImageUrl.
        [NotMapped]
        public string? PrimaryImageUrl =>
            Images?.OrderByDescending(i => i.IsPrimary)
                   .ThenBy(i => i.DisplayOrder)
                   .ThenBy(i => i.Id)
                   .Select(i => i.ImageUrl)
                   .FirstOrDefault()
            ?? ImageUrl;
    }
}
