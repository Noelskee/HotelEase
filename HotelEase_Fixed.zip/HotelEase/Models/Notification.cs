using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HotelEase.Models;

/// <summary>
/// Staff notification feed (online bookings, cancellations, etc.).
/// ReservationId is an optional FK — not every notification is reservation-scoped.
/// </summary>
public class Notification
{
    public int Id { get; set; }

    [Required, MaxLength(40)]
    public string Type { get; set; } = string.Empty;

    [Required, MaxLength(300)]
    public string Message { get; set; } = string.Empty;

    [MaxLength(200)]
    public string? Link { get; set; }

    /// <summary>Optional FK to the related reservation (configured in DbContext).</summary>
    public int? ReservationId { get; set; }

    [ForeignKey(nameof(ReservationId))]
    public Reservation? Reservation { get; set; }

    public bool IsRead { get; set; } = false;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
