using System.ComponentModel.DataAnnotations;

namespace HotelEase.Models
{
    // Hol_Amenities — master list of amenity names (e.g. "Wifi", "Hot Shower").
    public class Amenity
    {
        public int Id { get; set; }

        [Required, StringLength(40)]
        public string Name { get; set; } = string.Empty;

        public ICollection<RoomTypeAmenity> RoomTypeAmenities { get; set; } = new List<RoomTypeAmenity>();
    }
}
