using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HotelEase.Models;

public enum DiscountType
{
    None,
    SeniorCitizen,
    PWD
}

public enum InvoiceStatus { Draft, Issued, Paid }

public class Transaction
{
    public int Id { get; set; }

    [Required]
    public int ReservationId { get; set; }

    // Actual times (may differ from reservation dates)
    [Required]
    [Display(Name = "Actual Check-In")]
    public DateTime ActualCheckIn { get; set; }

    [Display(Name = "Actual Check-Out")]
    public DateTime? ActualCheckOut { get; set; }

    [Required, Column(TypeName = "decimal(10,2)")]
    [Display(Name = "Rate per Night (₱)")]
    public decimal RatePerNight { get; set; }

    [Required]
    [Display(Name = "Number of Nights")]
    public int NumberOfNights { get; set; }

    // Duration in hours for Alemar Budgetel short-stay pricing.
    [Display(Name = "Duration (Hours)")]
    public int DurationHours { get; set; } = 3;

    [Required, Column(TypeName = "decimal(10,2)")]
    [Display(Name = "Subtotal (₱)")]
    public decimal Subtotal { get; set; }

    // Extra hours recorded at check-in (e.g. early check-in) and/or check-out
    // (e.g. late check-out), billed at the room type's ExtraHourRate.
    [Display(Name = "Extra Hours")]
    public int ExtraHours { get; set; } = 0;

    [Column(TypeName = "decimal(10,2)")]
    [Display(Name = "Extra Hour Rate (₱/hour)")]
    public decimal ExtraHourRate { get; set; } = 0;

    [Column(TypeName = "decimal(10,2)")]
    [Display(Name = "Extra Hours Charge (₱)")]
    public decimal ExtraHoursCharge { get; set; } = 0;

    [Column(TypeName = "decimal(10,2)")]
    [Display(Name = "Extension Charge (₱)")]
    public decimal ExtensionCharge { get; set; } = 0;

    // Discount per RA 9994 (Senior) / RA 10754 (PWD)
    [Required]
    [Display(Name = "Discount Type")]
    public DiscountType DiscountType { get; set; } = DiscountType.None;

    [Column(TypeName = "decimal(5,2)")]
    [Display(Name = "Discount Rate (%)")]
    public decimal DiscountRate { get; set; } = 0;

    [Column(TypeName = "decimal(10,2)")]
    [Display(Name = "Discount Amount (₱)")]
    public decimal DiscountAmount { get; set; } = 0;

    [Column(TypeName = "decimal(10,2)")]
    [Display(Name = "Total Amount (₱)")]
    public decimal TotalAmount { get; set; }

    [MaxLength(100)]
    public string? AdditionalChargesType { get; set; }

    

    [Column(TypeName = "decimal(10,2)")]
    public decimal AdditionalCharges { get; set; } = 0;

    [Column(TypeName = "decimal(10,2)")]
    [Display(Name = "Final Amount Due (₱)")]
    public decimal FinalAmount { get; set; }

    [MaxLength(100)]
    [Display(Name = "Payment Method")]
    public string? PaymentMethod { get; set; }

    // GCash (or bank transfer) reference number typed in by front-desk
    // staff at Check-In. Recording only — nothing verifies this against
    // GCash or the bank, it's just kept on file for reconciliation.
    [MaxLength(100)]
    [Display(Name = "Payment Reference")]
    public string? PaymentReference { get; set; }

    // Relative path (under wwwroot) to a staff-uploaded screenshot/photo of
    // the guest's GCash or bank transfer confirmation. Documentation/audit
    // trail only — this does NOT verify with GCash or the bank that the
    // funds actually landed; it just records what the staff was shown.
    // Only ever set when PaymentMethod is GCash.
    [MaxLength(300)]
    [Display(Name = "Payment Proof")]
    public string? PaymentProofPath { get; set; }

    // Staff attestation checkbox: "I saw the guest's GCash/bank confirmation
    // screen before recording this." Required alongside the proof upload
    // for GCash payments collected at check-in.
    [Display(Name = "Payment Verified by Staff")]
    public bool PaymentVerifiedByStaff { get; set; } = false;

    // Cash tendered by the guest and the change given back. Only meaningful
    // when PaymentMethod is Cash; recorded at whichever step (check-in and/or
    // check-out) actually collected payment.
    [Column(TypeName = "decimal(10,2)")]
    [Display(Name = "Amount Tendered (₱)")]
    public decimal? AmountTendered { get; set; }

    [Column(TypeName = "decimal(10,2)")]
    [Display(Name = "Change (₱)")]
    public decimal? ChangeAmount { get; set; }

    public bool IsPaid { get; set; } = false;

    // Payment collected at Check-Out to settle a REMAINING balance (e.g.
    // damage charges) when the room
    // itself was already paid in full at Check-In. Kept separate from
    // PaymentMethod/AmountTendered/ChangeAmount above (which always
    // record the original Check-In payment) so neither record overwrites
    // the other — the receipt can show both. Null/0 when nothing
    // additional was owed at Check-Out.
    [MaxLength(100)]
    [Display(Name = "Check-Out Settlement Payment Method")]
    public string? CheckOutPaymentMethod { get; set; }

    [MaxLength(100)]
    [Display(Name = "Check-Out Settlement Reference")]
    public string? CheckOutPaymentReference { get; set; }

    // Same proof/attestation pair as PaymentProofPath/PaymentVerifiedByStaff
    // above, but for the Check-Out settlement payment (e.g. damage charges
    // settled via GCash).
    [MaxLength(300)]
    [Display(Name = "Check-Out Payment Proof")]
    public string? CheckOutPaymentProofPath { get; set; }

    [Display(Name = "Check-Out Payment Verified by Staff")]
    public bool CheckOutPaymentVerifiedByStaff { get; set; } = false;

    [Column(TypeName = "decimal(10,2)")]
    [Display(Name = "Check-Out Amount Tendered (₱)")]
    public decimal? CheckOutAmountTendered { get; set; }

    [Column(TypeName = "decimal(10,2)")]
    [Display(Name = "Check-Out Change (₱)")]
    public decimal? CheckOutChangeAmount { get; set; }

    // Snapshot of the exact amount actually collected from the guest at
    // Check-In (room charge, at check-in-time rates/extras).
    // Never touched afterward by ExtendStay/CheckOut, so it
    // stays a reliable "already paid" figure even as those actions keep
    // recomputing TotalAmount/FinalAmount for the running total. Used at
    // Check-Out to avoid re-billing a room charge the guest already paid.
    [Column(TypeName = "decimal(10,2)")]
    [Display(Name = "Amount Paid at Check-In (₱)")]
    public decimal AmountPaidAtCheckIn { get; set; } = 0;

    [MaxLength(30)]
    [Display(Name = "Invoice No.")]
    public string? InvoiceNumber { get; set; }

    [Required]
    [Display(Name = "Invoice Status")]
    public InvoiceStatus InvoiceStatus { get; set; } = InvoiceStatus.Draft;

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public int? CheckedInByUserId { get; set; }
    public int? CheckedOutByUserId { get; set; }

    // Navigation
    public Reservation Reservation { get; set; } = null!;
    public User? CheckedInByUser { get; set; }
    public User? CheckedOutByUser { get; set; }
}
