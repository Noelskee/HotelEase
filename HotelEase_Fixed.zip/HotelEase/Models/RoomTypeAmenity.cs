using System.ComponentModel.DataAnnotations;

namespace HotelEase.Models
{
    /// <summary>
    /// Many-to-many junction: RoomType ↔ Amenity.
    /// Composite PK (RoomTypeId, AmenityId).
    /// Amenity.Name is the authoritative name; <see cref="Name"/> is a denormalized
    /// cache kept in sync for display convenience only (not a second source of truth).
    /// </summary>
    public class RoomTypeAmenity
    {
        public int RoomTypeId { get; set; }
        public RoomType? RoomType { get; set; }

        public int AmenityId { get; set; }
        public Amenity? Amenity { get; set; }

        /// <summary>
        /// Denormalized copy of Amenity.Name for display without join.
        /// Always prefer Amenity.Name when the navigation is loaded.
        /// </summary>
        [StringLength(40)]
        public string Name { get; set; } = string.Empty;
    }
}
