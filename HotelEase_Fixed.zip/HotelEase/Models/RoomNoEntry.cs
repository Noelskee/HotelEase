using System.ComponentModel.DataAnnotations;

namespace HotelEase.Models
{
    /// <summary>
    /// Catalog of planned room numbers per RoomType (admin room-type form helper).
    /// Physical inventory and live status live in <see cref="Room"/> (Room.RoomNumber UNIQUE).
    /// RoomNos is NOT a second source of truth for occupancy; Room is authoritative.
    /// Table name in DB: RoomNo (composite key RoomTypeId + RoomNo).
    /// </summary>
    public class RoomNoEntry
    {
        [Display(Name = "Room Type")]
        public int RoomTypeId { get; set; }
        public RoomType? RoomType { get; set; }

        [Required, StringLength(10)]
        [Display(Name = "Room No")]
        public string RoomNo { get; set; } = string.Empty;
    }
}
