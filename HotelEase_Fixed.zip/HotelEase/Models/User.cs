using System.ComponentModel.DataAnnotations;

namespace HotelEase.Models;

public enum UserRole
{
    Admin,
    FrontDesk,
    Housekeeping
}

public class User
{
    public int Id { get; set; }

    [Required, MaxLength(50)]
    public string Username { get; set; } = string.Empty;

    [Required]
    public string PasswordHash { get; set; } = string.Empty;

    [Required, MaxLength(100)]
    public string FullName { get; set; } = string.Empty;

    [MaxLength(100)]
    public string? Email { get; set; }

    [Required]
    public UserRole Role { get; set; }

    public bool IsActive { get; set; } = true;

    /// <summary>
    /// When true, staff must change password before accessing any other page.
    /// Set on admin-created accounts (default password = email).
    /// </summary>
    public bool MustChangePassword { get; set; } = false;

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public DateTime? LastLoginAt { get; set; }
}
