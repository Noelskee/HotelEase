using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HotelEase.Models;

public class RoomTypeImage
{
    public int Id { get; set; }

    [Required]
    public int RoomTypeId { get; set; }
    public RoomType RoomType { get; set; } = null!;

    [Required, StringLength(500)]
    public string ImageUrl { get; set; } = string.Empty;

    [StringLength(255)]
    public string? FileName { get; set; }

    [StringLength(500)]
    public string? Caption { get; set; }

    public bool IsPrimary { get; set; } = false;

    public int DisplayOrder { get; set; } = 0;

    public DateTime UploadedAt { get; set; } = DateTime.UtcNow;
}