using System.ComponentModel.DataAnnotations;

namespace HotelEase.Models
{
    public class Guest
    {
        public int Id { get; set; }

        [Required, StringLength(100)]
        [Display(Name = "Full Name")]
        public string FullName { get; set; } = string.Empty;

        [Required, StringLength(20)]
        [Display(Name = "Contact Number")]
        public string ContactNumber { get; set; } = string.Empty;

        [Required, StringLength(60)]
        public string Nationality { get; set; } = string.Empty;

        /// <summary>
        /// Denormalized last-known party size for guest-profile display only.
        /// Authoritative guest count for a stay is Reservation.Adults + Reservation.Children
        /// (and Reservation.GuestCount). Updated when creating/editing reservations.
        /// </summary>
        [Required]
        [Display(Name = "Number of Guests")]
        [Range(1, 20, ErrorMessage = "Number of guests must be between 1 and 20.")]
        public int NumberOfGuests { get; set; } = 1;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        // Soft-deletion / archive support: archived guests are hidden from the
        // main Guest Management list but their records (are
        // preserved and can be restored later.
        public bool IsArchived { get; set; } = false;

        public DateTime? ArchivedAt { get; set; }

        // Marks the single hidden "Deleted Guest" placeholder record (see
        // GuestController.DeletePermanently). Reservations/Transactions that
        // already generated revenue get reassigned here instead of being
        // deleted, so permanently deleting a guest never removes revenue
        // from the Dashboard. This flag keeps the placeholder out of both
        // the active Guest Management list and the Archived list.
        public bool IsSystemRecord { get; set; } = false;

        // ---- Added for the Reservation module ----
        // Optional fields not used by the Walk-In flow (FrontDeskController),
        // which still only sets FullName/ContactNumber/Nationality/NumberOfGuests
        // above. Reservation/Guest-record-management screens populate these.

        [StringLength(100)]
        [EmailAddress]
        public string? Email { get; set; }

        [StringLength(50)]
        [Display(Name = "Government ID Type")]
        public string? IdType { get; set; }

        [StringLength(100)]
        [Display(Name = "Government ID Number")]
        public string? IdNumber { get; set; }

        [Display(Name = "Senior Citizen")]
        public bool IsSeniorCitizen { get; set; } = false;

        [Display(Name = "PWD")]
        public bool IsPwd { get; set; } = false;

        [StringLength(50)]
        [Display(Name = "Senior/PWD ID Number")]
        public string? DiscountIdNumber { get; set; }

        public ICollection<Reservation> Reservations { get; set; } = new List<Reservation>();
    }
}
