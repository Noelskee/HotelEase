using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using HotelEase.Models;

namespace HotelEase.ViewModels;

public class CheckOutViewModel
{
    public int ReservationId { get; set; }
    public int TransactionId { get; set; }

    [ValidateNever]
    public Reservation Reservation { get; set; } = null!;

    [ValidateNever]
    public Transaction Transaction { get; set; } = null!;

    [Required, Display(Name = "Actual Check-Out Date & Time")]
    public DateTime ActualCheckOut { get; set; } = DateTime.Now;

    // Multi-select other charge types applied at check-out.
    public List<string> SelectedChargeTypes { get; set; } = new();

    [Display(Name = "Other Charges (₱)")]
    public decimal AdditionalCharges { get; set; } = 0;

    [MaxLength(100), Display(Name = "Payment Method")]
    public string? PaymentMethod { get; set; }

    [MaxLength(100), Display(Name = "Reference Number")]
    public string? PaymentReference { get; set; }

    [Display(Name = "Amount Tendered (₱)")]
    [Range(0, double.MaxValue)]
    public decimal? AmountTendered { get; set; }

    // Final billing
    public int DurationHours { get; set; } = 24;
    public int ExtraPersons { get; set; }
    public int ExtraBeds { get; set; }
    public int ExtraHours { get; set; }
    public decimal ExtraHoursCharge { get; set; }

    /// <summary>
    /// Remaining room/extension/extra charges still owed.
    /// </summary>
    public decimal ChargeBalance { get; set; }

    /// <summary>
    /// Cash the guest must pay at checkout for remaining charges.
    /// </summary>
    public decimal AmountDueFromGuest { get; set; }

    /// <summary>
    /// Legacy alias used by some views/JS: net the guest pays (same as AmountDueFromGuest).
    /// </summary>
    public decimal FinalAmount
    {
        get => AmountDueFromGuest;
        set => AmountDueFromGuest = value;
    }

    public decimal? ChangeAmount { get; set; }
    public string? DiscountLegalBasis { get; set; }

    public bool AlreadyPaid { get; set; }
    public string? PaidMethod { get; set; }
    public string? PaidReference { get; set; }

    public static readonly Dictionary<string, decimal> AvailableCharges = new()
    {
        // Broken amenities / fixtures folded into Damages
        { "Damages", 500m }
    };

}
