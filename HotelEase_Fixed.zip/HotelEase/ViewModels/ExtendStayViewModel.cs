using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using HotelEase.Models;

namespace HotelEase.ViewModels;

public class ExtendStayViewModel
{
    public int ReservationId { get; set; }

    [ValidateNever]
    public Reservation Reservation { get; set; } = null!;

    [Display(Name = "Guest")]
    public string GuestName { get; set; } = string.Empty;

    [Display(Name = "Room")]
    public string RoomInfo { get; set; } = string.Empty;

    [Display(Name = "Stay Type")]
    public bool IsNightlyStay { get; set; }

    [Display(Name = "Current Expected Check-Out")]
    public DateTime? CurrentExpectedCheckOut { get; set; }

    [Display(Name = "Rate per Hour / Night")]
    public decimal Rate { get; set; }

    [Display(Name = "Extension")]
    [Range(1, 999, ErrorMessage = "Extension value must be at least 1.")]
    public int ExtensionValue { get; set; } = 1;

    [Display(Name = "Extension Charge (₱)")]
    public decimal ExtensionCharge { get; set; }

    [MaxLength(500), Display(Name = "Notes")]
    public string? Notes { get; set; }

    public List<int> HourlyOptions { get; set; } = new() { 1, 2, 3, 12, 24 };
    public List<int> NightlyOptions { get; set; } = new() { 1, 2, 3 };

    // ── Group extend support ──────────────────────────────────────────────
    // When the reservation belongs to a multi-room group (same base reference),
    // these list the CheckedIn siblings so the front desk can extend one or
    // more rooms together under a single action.
    public bool IsGroup { get; set; }

    public string? GroupBaseReference { get; set; }

    /// <summary>
    /// Sibling rooms available for group extend (CheckedIn only).
    /// </summary>
    public List<GroupExtendRoomItem> GroupRooms { get; set; } = new();

    /// <summary>
    /// IDs of rooms the user selected to extend. Posted back from the form.
    /// </summary>
    public List<int> SelectedReservationIds { get; set; } = new();

    /// <summary>
    /// When true (default), a room with a conflicting future booking is
    /// automatically moved to another available room of the same type, then
    /// extended. When false, conflicting rooms are skipped only.
    /// </summary>
    [Display(Name = "Auto-resolve conflicts (move to another room of the same type)")]
    public bool AutoResolveConflicts { get; set; } = true;

    /// <summary>
    /// Front desk must explicitly confirm before a checked-in guest is moved
    /// to a different room because another booking holds the current room.
    /// </summary>
    public bool ConfirmRoomMove { get; set; }
}

/// <summary>
/// One room line in a multi-room group extend screen.
/// </summary>
public class GroupExtendRoomItem
{
    public int ReservationId { get; set; }
    public string ReferenceNumber { get; set; } = string.Empty;
    public string RoomLabel { get; set; } = string.Empty;
    public DateTime? CurrentExpectedCheckOut { get; set; }
    public decimal Rate { get; set; }
    public bool IsNightlyStay { get; set; }
    public bool Selected { get; set; } = true;

    /// <summary>
    /// Set after conflict check — true when another reservation overlaps the
    /// proposed extension window for this physical room.
    /// </summary>
    public bool HasConflict { get; set; }

    public string? ConflictMessage { get; set; }

    /// <summary>
    /// Filled when auto-resolve moved this stay to a different physical room.
    /// </summary>
    public string? ResolvedToRoom { get; set; }
}
