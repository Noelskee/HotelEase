using System.ComponentModel.DataAnnotations;
using HotelEase.Models;

namespace HotelEase.ViewModels;

public class GuestCreateEditViewModel
{
    public int? Id { get; set; }

    [Required, MaxLength(150), Display(Name = "Full Name")]
    public string FullName { get; set; } = string.Empty;

    [EmailAddress, MaxLength(100)]
    public string? Email { get; set; }

    [Required, MaxLength(20), Display(Name = "Contact Number")]
    public string ContactNumber { get; set; } = string.Empty;

    [MaxLength(100)]
    public string? Nationality { get; set; } = "Filipino";

    [MaxLength(50), Display(Name = "Government ID Type")]
    public string? IdType { get; set; }

    [MaxLength(100), Display(Name = "Government ID Number")]
    public string? IdNumber { get; set; }

    [Display(Name = "Senior Citizen")]
    public bool IsSeniorCitizen { get; set; }

    [Display(Name = "PWD")]
    public bool IsPwd { get; set; }

    [MaxLength(50), Display(Name = "Senior/PWD ID Number")]
    public string? DiscountIdNumber { get; set; }
}

public class GuestDetailsViewModel
{
    public Guest Guest { get; set; } = null!;
    public List<Reservation> ReservationHistory { get; set; } = new();

    // Alias used by the view
    public List<Reservation> Reservations => ReservationHistory;
}

public class GuestListViewModel
{
    public List<Guest> Guests { get; set; } = new();
    public string? Search { get; set; }
}
