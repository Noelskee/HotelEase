using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using HotelEase.Models;

namespace HotelEase.ViewModels;

public class ReservationExtraHoursViewModel
{
    public int ReservationId { get; set; }

    [ValidateNever]
    public Reservation Reservation { get; set; } = null!;

    [Display(Name = "Guest")]
    public string GuestName { get; set; } = string.Empty;

    [Display(Name = "Room")]
    public string RoomInfo { get; set; } = string.Empty;

    [Display(Name = "Actual Check-In")]
    public DateTime? ActualCheckIn { get; set; }

    [Display(Name = "Duration")]
    public int DurationHours { get; set; }

    [Display(Name = "Extra Hour Rate (₱/hour)")]
    public decimal ExtraHourRate { get; set; }

    // True for Nightly stays (spans more than one night / 25+ hours) — the
    // Add Extra Hours/Days form shows a Days input instead of Hours, but the
    // value is still stored here in hours (Days * 24) so billing/checkout
    // math (which works in hours) doesn't need to change.
    public bool IsNightlyStay { get; set; }

    [Display(Name = "Extra Hours")]
    [Required(ErrorMessage = "Extra Hours is required.")]
    [Range(1, 720, ErrorMessage = "Extra Hours must be between 1 and 720.")]
    public int ExtraHours { get; set; }

    [Display(Name = "Total Extra Charge (₱)")]
    public decimal ExtraHoursCharge { get; set; }

    [MaxLength(500), Display(Name = "Notes")]
    public string? Notes { get; set; }
}
