using System.ComponentModel.DataAnnotations;
using System.Text.Json;
using HotelEase.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace HotelEase.ViewModels;

// Backs the staff-side Reservation/Manage view (filter/search list of reservations).
public class ReservationListViewModel
{
    public List<Reservation> Reservations { get; set; } = new();
    public string? StatusFilter { get; set; }
    public string? Search { get; set; }
    public DateTime? DateFilter { get; set; }

    // Status summary counts (clickable filter cards — replaces date inputs).
    public int PendingCount { get; set; }
    public int ConfirmedCount { get; set; }
    public int CheckedInCount { get; set; }
    public int CheckedOutCount { get; set; }
    public int CancelledCount { get; set; }
}

// Backs Reservation/Create — staff booking a Normal or Advance reservation for
// a guest who is NOT physically at the desk yet (as opposed to Walk-In, which
// is FrontDesk/WalkIn and always pays + checks in immediately). This is
// always created as Status = Pending, Payment = Unpaid. Whether it becomes a
// "Normal" (pay later, at Check-In) or "Advance/Prepaid" (pay now) reservation
// is decided afterwards on the Reservation Details page — Confirm Reservation
// leaves it Unpaid, Pay Now marks it Paid — not on this form.
public class CreateReservationViewModel
{
    // Reservation Type: Phone (called in) or Walk-In (in-person future booking).
    // Online is handled by the public OnlineReservation module. Direct immediate
    // Walk-In check-in is handled by FrontDesk/WalkIn (also Type=WalkIn).
    [Required]
    [Display(Name = "Reservation Type")]
    public ReservationType BookingSource { get; set; } = ReservationType.Phone;

    [Required, StringLength(100)]
    [Display(Name = "Guest Full Name")]
    public string GuestFullName { get; set; } = string.Empty;

    [Required, StringLength(20)]
    [Display(Name = "Contact Number")]
    public string GuestContactNumber { get; set; } = string.Empty;

    [StringLength(100), EmailAddress]
    public string? GuestEmail { get; set; }

    [Required, StringLength(60)]
    public string GuestNationality { get; set; } = "Filipino";

    // Collected at check-in only (not during booking).
    [StringLength(60)]
    [Display(Name = "Government ID Type")]
    public string GuestIdType { get; set; } = string.Empty;

    [StringLength(100)]
    [Display(Name = "ID Number")]
    public string GuestIdNumber { get; set; } = string.Empty;

    [Display(Name = "Senior Citizen / PWD Discount")]
    public bool ApplyDiscount { get; set; }

    // Optional when multi-room cards drive the booking (SelectedRoomsJson).
    [Display(Name = "Room Type")]
    public int PreferredRoomTypeId { get; set; }

    [Display(Name = "Number of Rooms")]
    [Range(1, 5, ErrorMessage = "Maximum of 5 rooms per reservation.")]
    public int RoomsRequested { get; set; } = 1;

    [Display(Name = "Room")]
    public int? RoomId { get; set; }

    [Required]
    [Display(Name = "Stay Type")]
    public StayType StayType { get; set; } = StayType.Nightly;

    [Range(3, 12, ErrorMessage = "Duration must be 3 or 12 hours.")]
    [Display(Name = "Duration (Hours)")]
    public int DurationHours { get; set; } = 3;

    [Range(1, 30, ErrorMessage = "Number of nights must be between 1 and 30.")]
    [Display(Name = "Number of Nights")]
    public int NumberOfNights { get; set; } = 1;

    [Required]
    [Display(Name = "Check-In Date")]
    [DataType(DataType.Date)]
    public DateTime CheckInDate { get; set; } = DateTime.Today;

    [Display(Name = "Expected Arrival Time")]
    public string? ExpectedCheckInTime { get; set; } = "14:00";

    [Range(1, 20)]
    [Display(Name = "Adults")]
    public int Adults { get; set; } = 1;

    [Range(0, 20)]
    [Display(Name = "Children")]
    public int Children { get; set; } = 0;

    [Range(1, 40)]
    [Display(Name = "Number of Guests")]
    public int GuestCount { get; set; } = 1;

    [StringLength(200)]
    [Display(Name = "Special Requests")]
    public string? SpecialRequests { get; set; }

    // ── Multi-room selection (mirrors WalkIn SelectedRoomsJson pattern) ──
    // JSON array of CreateRoomSelection objects carried in a hidden field.
    public string SelectedRoomsJson { get; set; } = "[]";

    public List<CreateRoomSelection> SelectedRooms
    {
        get
        {
            if (string.IsNullOrWhiteSpace(SelectedRoomsJson)) return new();
            try
            {
                return JsonSerializer.Deserialize<List<CreateRoomSelection>>(
                    SelectedRoomsJson,
                    new JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? new();
            }
            catch (JsonException) { return new(); }
        }
    }

    // Populated by the controller for redisplay on validation errors.
    public List<SelectListItem> AvailableRooms { get; set; } = new();
    public List<RoomRateOption> RoomRates { get; set; } = new();
    public List<SelectListItem> NationalityOptions { get; set; } = new();
    public List<SelectListItem> BookingSourceOptions { get; set; } = new();
    // Available room cards (mirrors WalkIn pattern for UI consistency).
    public List<AvailableRoomCardOption> AvailableRoomCards { get; set; } = new();
    public List<SelectListItem> RoomTypeOptions { get; set; } = new();
    public string RoomTypeRatesJson { get; set; } = "[]";

    // Payment at booking time — default "0" = pay at check-in (no downpayment on new reservation)
    // PayMode: "50" | "100" | "custom" | "0" (pay at check-in)
    public string PayMode { get; set; } = "0";
    // Nullable so empty form field does not produce "The value '' is invalid."
    public decimal? CustomDownpayment { get; set; }
    public string? PaymentMethod { get; set; }
    public string? PaymentReference { get; set; }
}

public class CreateRoomSelection
{
    public int RoomId { get; set; }
    public string RoomNumber { get; set; } = string.Empty;
    public string RoomTypeName { get; set; } = string.Empty;
    public int MaxOccupancy { get; set; }
    public decimal StayRate { get; set; }
    public string DurationLabel { get; set; } = string.Empty;
    public string StayType { get; set; } = "Hourly";
    public int DurationHours { get; set; } = 3;
    public int NumberOfNights { get; set; } = 1;
    public int Adults { get; set; } = 1;
    public int Children { get; set; } = 0;
    public string? ChildrenAges { get; set; }
}

public class AvailableRoomCardOption
{
    public int Id { get; set; }
    public string RoomNumber { get; set; } = string.Empty;
    public int RoomTypeId { get; set; }
    public string RoomTypeName { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public decimal Rate3Hours { get; set; }
    public decimal Rate12Hours { get; set; }
    public decimal Rate24Hours { get; set; }
    public decimal RateNightly { get; set; }
    public decimal StayRate { get; set; }
    public string DurationLabel { get; set; } = string.Empty;
    public int MaxOccupancy { get; set; }
    public string Amenities { get; set; } = string.Empty;
    /// <summary>Display status: Available, Reserved, For Cleaning, Occupied</summary>
    public string Status { get; set; } = "Available";
    /// <summary>False when Reserved / For Cleaning / Occupied — still shown but not selectable.</summary>
    public bool IsSelectable { get; set; } = true;
}

// Structured per-room rate data for CreateReservationViewModel's live price
// preview (Room/Room Type Management is the single source of truth for all
// of these — see RoomType.GetRateForDuration/BaseRate).
public class RoomRateOption
{
    public int RoomId { get; set; }
    public decimal Rate3Hours { get; set; }
    public decimal Rate12Hours { get; set; }
    public decimal Rate24Hours { get; set; }
    public decimal RateNightly { get; set; }
}

// Backs Reservation/Pay — collecting an advance/prepaid payment on a
// Pending or Confirmed reservation that is not yet Paid. Distinct from
// ReservationController.Confirm, which never touches PaymentStatus, and
// from FrontDeskController.CheckIn, which collects payment for guests who
// did NOT prepay. Paying here also confirms the reservation if it was still
// Pending (see business rule §3 — Payment confirms an advance reservation).
public class PayReservationViewModel
{
    public int ReservationId { get; set; }
    public Reservation? Reservation { get; set; }
    public decimal AmountDue { get; set; }

    [Required(ErrorMessage = "Please select a payment method.")]
    [Display(Name = "Payment Method")]
    public string PaymentMethod { get; set; } = string.Empty;

    [Display(Name = "Reference Number")]
    public string? PaymentReference { get; set; }

    [Display(Name = "Amount Paid")]
    public decimal? AmountPaid { get; set; }
}

public class ReservationCreateViewModel
{
    // Tracks which wizard step the user is on so server-side validation
    // errors can return to the correct step instead of resetting to step 1.
    public int CurrentStep { get; set; } = 1;

    // Personal Information
    [Required, MaxLength(150), Display(Name = "Full Name")]
    public string GuestFullName { get; set; } = string.Empty;

    [Required, MaxLength(20), Display(Name = "Contact Number")]
    public string GuestContactNumber { get; set; } = string.Empty;

    [Required, EmailAddress, MaxLength(100), Display(Name = "Email Address")]
    public string? GuestEmail { get; set; }

    [Required, MaxLength(100), Display(Name = "Nationality")]
    public string? GuestNationality { get; set; } = "Filipino";

    // Collected at front-desk check-in only (not during online booking).
    [MaxLength(50), Display(Name = "Government ID Type")]
    public string? IdType { get; set; }

    [MaxLength(100), Display(Name = "Government ID Number")]
    public string? IdNumber { get; set; }

    [Display(Name = "Senior Citizen Discount")]
    public bool IsSeniorCitizen { get; set; }

    [Display(Name = "PWD Discount")]
    public bool IsPwd { get; set; }

    // Reservation Information
    // Stay Type toggle — mirrors the Walk-In wizard: "Nightly" uses the
    // check-in/check-out date range below; "Hourly" bills a single 3, 12,
    // or 24 hour block starting at check-in (see DurationHours).
    [Required, Display(Name = "Stay Type")]
    public string StayType { get; set; } = "Nightly";

    [Display(Name = "Duration")]
    [Range(3, 12, ErrorMessage = "Duration must be 3 or 12 hours.")]
    public int DurationHours { get; set; } = 3;

    [Required, DataType(DataType.Date), Display(Name = "Check-in Date")]
    public DateTime CheckInDate { get; set; } = DateTime.Today;

    [Display(Name = "Expected Arrival Time")]
    public string? ExpectedCheckInTime { get; set; } = "14:00";

    [Required, DataType(DataType.Date), Display(Name = "Check-out Date")]
    public DateTime CheckOutDate { get; set; } = DateTime.Today.AddDays(1);

    // Optional room-type filter for the Step 1 search (0/null = all types),
    // same as the Walk-In wizard's RoomTypeId filter.
    [Display(Name = "Room Type")]
    public int? RoomTypeId { get; set; }

    // Legacy single-room field; filled from the first SelectedRooms entry on save.
    [Display(Name = "Selected Room")]
    public int RoomId { get; set; }

    // Multi-room cart (same pattern as Walk-In). Guest can select several
    // specific room numbers; carried as JSON in a hidden field.
    public string SelectedRoomsJson { get; set; } = "[]";

    public List<OnlineRoomSelection> SelectedRooms
    {
        get
        {
            if (string.IsNullOrWhiteSpace(SelectedRoomsJson)) return new();
            try
            {
                return System.Text.Json.JsonSerializer.Deserialize<List<OnlineRoomSelection>>(
                    SelectedRoomsJson,
                    new System.Text.Json.JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? new();
            }
            catch (System.Text.Json.JsonException) { return new(); }
        }
    }

    public class OnlineRoomSelection
    {
        public int RoomId { get; set; }
        public string RoomNumber { get; set; } = string.Empty;
        public string RoomTypeName { get; set; } = string.Empty;
        public int MaxOccupancy { get; set; }
        public decimal StayRate { get; set; }
        public string DurationLabel { get; set; } = string.Empty;
        public string StayType { get; set; } = "Nightly";
        public int DurationHours { get; set; } = 3;
        public int NumberOfNights { get; set; } = 1;
    }

    [Display(Name = "Adults")]
    [Range(1, 20, ErrorMessage = "Adults must be between 1 and 20.")]
    public int Adults { get; set; } = 1;

    [Display(Name = "Children")]
    [Range(0, 20, ErrorMessage = "Children must be between 0 and 20.")]
    public int Children { get; set; } = 0;

    [Display(Name = "Children's Ages")]
    [MaxLength(100)]
    public string? ChildrenAges { get; set; }

    // Total guest count, derived the same way as the Walk-In wizard
    // (Adults + Children) — there's no separate "Guests" field to keep in
    // sync with these two.
    public int GuestCount => Adults + Children;

    // Derived from SelectedRooms.Count when multi-select is used.
    [Range(1, 5, ErrorMessage = "Maximum of 5 rooms per reservation."), Display(Name = "Rooms")]
    public int RoomsRequested { get; set; } = 1;

    // Optional per-room guest breakdown (legacy); usually one Adults/Children for the booking.
    public List<RoomBookingItem> RoomBookings { get; set; } = new()
    {
        new RoomBookingItem { RoomIndex = 0, Adults = 1, Children = 0 }
    };

    [Display(Name = "Extra Persons")]
    [Range(0, 20, ErrorMessage = "Extra persons must be between 0 and 20.")]
    public int ExtraPersons { get; set; } = 0;

    [Display(Name = "Extra Beds")]
    [Range(0, 10, ErrorMessage = "Extra beds must be between 0 and 10.")]
    public int ExtraBeds { get; set; } = 0;

    [MaxLength(200), Display(Name = "Special Requests")]
    public string? SpecialRequests { get; set; }

    public class RoomBookingItem
    {
        public int RoomIndex { get; set; }

        [Range(1, 5, ErrorMessage = "Maximum of 5 rooms per reservation.")]
        public int RoomsRequested { get; set; } = 1;

        [Display(Name = "Adults")]
        [Range(1, 20, ErrorMessage = "Adults must be between 1 and 20.")]
        public int Adults { get; set; } = 1;

        [Display(Name = "Children")]
        [Range(0, 20, ErrorMessage = "Children must be between 0 and 20.")]
        public int Children { get; set; } = 0;

        /// <summary>Comma-separated ages (1–12) for this room only.</summary>
        [MaxLength(100)]
        public string? ChildrenAges { get; set; }

        public int TotalGuests => Adults + Children;
    }

    /// <summary>
    /// JSON of per-room occupancy from online Step 1.
    /// Format: [{ "roomIndex":0, "adults":1, "children":2, "childrenAges":"5,10" }, ...]
    /// </summary>
    public string RoomOccupancyJson { get; set; } = "[]";

    // Payment section shown only on the final confirmation step.
    [Display(Name = "Payment Method")]
    [MaxLength(20)]
    public string? PaymentMethod { get; set; }

    [Display(Name = "GCash Payment Proof")]
    public IFormFile? PaymentProofImage { get; set; }

    public ReservationType Type { get; set; } = ReservationType.Online;

    // Dropdown options for the Step 1 room-type filter.
    public List<SelectListItem> RoomTypeOptions { get; set; } = new();

    // Cards rendered in the Available Rooms step of the wizard (same shape
    // as the Walk-In wizard's AvailableRoomCards).
    public List<AvailableRoomCard> AvailableRoomCards { get; set; } = new();

    public class AvailableRoomCard
    {
        public int Id { get; set; }
        public string RoomNumber { get; set; } = string.Empty;
        public string RoomTypeName { get; set; } = string.Empty;
        public decimal StayRate { get; set; }
        public string DurationLabel { get; set; } = string.Empty;
        public int MaxOccupancy { get; set; }
        public string Amenities { get; set; } = string.Empty;
        public string? ImageUrl { get; set; }
    }

    // Pricing summary populated by the controller for display.
    public decimal RatePerNight { get; set; }
    public int NumberOfNights => StayType == "Hourly" ? 1 : Math.Max(1, (CheckOutDate - CheckInDate).Days);
    public decimal Subtotal => RatePerNight * NumberOfNights;
    public decimal DiscountAmount { get; set; }
    public decimal EstimatedTotal => Subtotal - DiscountAmount;
    public decimal DiscountPercent { get; set; }
}

// Guest self-service cancellation request.
public class CancelReservationViewModel
{
    [Required, MaxLength(20), Display(Name = "Reference Number")]
    public string ReferenceNumber { get; set; } = string.Empty;

    [Required, MaxLength(20), Display(Name = "Contact Number")]
    public string ContactNumber { get; set; } = string.Empty;

    // Populated when a matching eligible reservation is found.
    public Reservation? Reservation { get; set; }
    public bool Found { get; set; }
    public string? ErrorMessage { get; set; }
}

// Availability search inputs shown on the public Rooms page. Mirrors the
// Create wizard's Step 1 search (Stay Type toggle + duration/dates + guest
// count) so both entry points to the booking flow behave the same way.
public class RoomAvailabilitySearchViewModel
{
    [Display(Name = "Stay Type")]
    public string StayType { get; set; } = "Nightly";

    [Required, DataType(DataType.Date), Display(Name = "Check-in Date")]
    public DateTime CheckInDate { get; set; } = DateTime.Today;

    [Required, DataType(DataType.Date), Display(Name = "Check-out Date")]
    public DateTime CheckOutDate { get; set; } = DateTime.Today.AddDays(1);

    [Display(Name = "Duration")]
    public int DurationHours { get; set; } = 3;

    [Display(Name = "Adults")]
    [Range(1, 20, ErrorMessage = "Adults must be between 1 and 20.")]
    public int Adults { get; set; } = 1;

    [Display(Name = "Children")]
    [Range(0, 20, ErrorMessage = "Children must be between 0 and 20.")]
    public int Children { get; set; } = 0;

    /// <summary>Comma-separated ages for each child (e.g. "5,8"). Free of charge; does not count toward max occupancy.</summary>
    [Display(Name = "Children's Ages")]
    public string? ChildrenAges { get; set; }

    /// <summary>Total people for display. Occupancy checks use Adults only.</summary>
    public int GuestCount => Adults + Children;

    // The moment the stay actually ends, used for availability checks and
    // pricing — for Hourly stays this is derived from check-in + duration
    // rather than the (hidden) check-out date field.
    public DateTime EffectiveCheckOutDate => StayType == "Hourly"
        ? CheckInDate.AddHours(DurationHours)
        : CheckOutDate;
}

// A room type card enriched with date-aware availability data.
public class RoomTypeAvailabilityViewModel
{
    public RoomType RoomType { get; set; } = null!;
    public int AvailableRoomCount { get; set; }
    public int TotalRoomCount { get; set; }
    public bool IsAvailableForDates { get; set; }
    public string StayType { get; set; } = "Nightly";
    public DateTime CheckInDate { get; set; }
    public DateTime CheckOutDate { get; set; }
    public int DurationHours { get; set; }
    public int GuestCount { get; set; }
    public int Adults { get; set; } = 1;
    public int Children { get; set; } = 0;
    public string? ChildrenAges { get; set; }
    public int NumberOfNights => Math.Max(1, (CheckOutDate - CheckInDate).Days);
    public decimal EstimatedTotalForOneRoom => StayType == "Hourly"
        ? RoomType.GetRateForDuration(DurationHours)
        : RoomType.BaseRate * NumberOfNights;

    // Adults only count toward max occupancy (same as online reservation / Front Desk).
    // Children are free and do not affect whether the room type can accommodate the party.
    public bool AccommodatesGuests => Adults <= RoomType.MaxOccupancy;
    public bool CanBook => IsAvailableForDates && AccommodatesGuests;
}

// Public booking form: personal info + government ID + discount + specific
// room number (cascading from room type) + dates + pricing preview. No
// account required; staff confirm the booking afterwards.
//
// Mirrors the staff Walk-In wizard's operation: Step 1 search (stay type +
// dates/duration + guest count + optional room type filter) -> Step 2 pick
// an available room card -> Step 3 guest info + discount -> Step 4 review
// & confirm.

public class ReservationStatusLookupViewModel
{
    [Required, MaxLength(40), Display(Name = "Reservation Reference Number")]
    public string ReferenceNumber { get; set; } = string.Empty;

    // Optional — contact is displayed on the status result, not required to look up.
    [MaxLength(20), Display(Name = "Contact Number")]
    public string? ContactNumber { get; set; }
}

// Staff: change check-in / check-out dates for Pending / Confirmed / Reserved.
public class RescheduleReservationViewModel
{
    public int ReservationId { get; set; }
    public string ReferenceNumber { get; set; } = string.Empty;
    public string GuestName { get; set; } = string.Empty;
    public string RoomInfo { get; set; } = string.Empty;
    public string CurrentStaySummary { get; set; } = string.Empty;
    public bool IsNightly { get; set; } = true;
    public int DurationHours { get; set; } = 3;

    [Required]
    [Display(Name = "New Check-In")]
    [DataType(DataType.DateTime)]
    public DateTime NewCheckIn { get; set; }

    [Required]
    [Display(Name = "New Check-Out")]
    [DataType(DataType.DateTime)]
    public DateTime NewCheckOut { get; set; }

    [Display(Name = "Reason / notes")]
    [MaxLength(300)]
    public string? Notes { get; set; }
}

