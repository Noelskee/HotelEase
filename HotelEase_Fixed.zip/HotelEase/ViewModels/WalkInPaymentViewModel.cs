using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using HotelEase.Models;

namespace HotelEase.ViewModels;

public class WalkInPaymentViewModel
{
    public List<int> ReservationIds { get; set; } = new();

    [ValidateNever]
    public List<Reservation> Reservations { get; set; } = new();

    public decimal TotalAmount { get; set; }

    [Required, MaxLength(100), Display(Name = "Payment Method")]
    public string? PaymentMethod { get; set; }

    [MaxLength(100), Display(Name = "Reference Number")]
    public string? PaymentReference { get; set; }

    [Display(Name = "Amount Tendered (₱)")]
    [Range(0, double.MaxValue)]
    public decimal? AmountTendered { get; set; }

    [Display(Name = "Change (₱)")]
    public decimal? ChangeAmount { get; set; }

    [Required, Display(Name = "Actual Check-In Date & Time")]
    public DateTime ActualCheckIn { get; set; } = DateTime.Now;

    public string ReservationIdsCsv => string.Join(",", ReservationIds);
}
