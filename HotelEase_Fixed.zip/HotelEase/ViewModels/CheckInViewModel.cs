using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using HotelEase.Models;

namespace HotelEase.ViewModels;

public class CheckInViewModel
{
    public int ReservationId { get; set; }

    [ValidateNever]
    public Reservation Reservation { get; set; } = null!;

    [Required, Display(Name = "Actual Check-In Date & Time")]
    public DateTime ActualCheckIn { get; set; } = DateTime.Now;

    // Assigned at check-in (not at reservation). Required when the
    // reservation has no RoomId yet. For single-room bookings this is enough;
    // multi-room groups use GroupRoomAssignments below.
    [Display(Name = "Assign Room")]
    public int? AssignedRoomId { get; set; }

    public List<Microsoft.AspNetCore.Mvc.Rendering.SelectListItem> AvailableRoomsForAssignment { get; set; } = new();
    public string? PreferredRoomTypeName { get; set; }

    /// <summary>
    /// Shown at the top of the Check-In page when the room booked for a guest
    /// is still held by someone else (e.g. an in-house guest who extended).
    /// </summary>
    public List<string> RoomConflictNotices { get; set; } = new();

    /// <summary>
    /// One entry per reservation in a multi-room group so staff can pick a
    /// distinct physical room for each (online multi-room bookings arrive
    /// with RoomId null on every sibling).
    /// </summary>
    public List<GroupRoomAssignmentItem> GroupRoomAssignments { get; set; } = new();

    // Billing preview (read-only)
    public decimal RatePerNight { get; set; }
    public int NumberOfNights { get; set; }
    public int DurationHours { get; set; } = 24;
    public decimal Subtotal { get; set; }
    public decimal DiscountAmount { get; set; }
    public int ExtraPersons { get; set; }
    public int ExtraBeds { get; set; }
    public decimal TotalAmount { get; set; }
    public decimal FinalAmount { get; set; }
    public string? DiscountLegalBasis { get; set; }

    // Payment status and balance information used to prevent duplicate payment.
    public PaymentStatus PaymentStatus { get; set; } = PaymentStatus.Unpaid;
    public decimal AmountPaid { get; set; }
    public decimal RemainingBalance { get; set; }
    public bool IsAlreadyPaid { get; set; }

    // ── Guest verification (same fields as Booking / Walk-In) ──────────────
    // Pre-filled from the reservation guest; staff re-verify at the desk.
    [Required, StringLength(100)]
    [Display(Name = "Guest Full Name")]
    public string GuestFullName { get; set; } = string.Empty;

    [Required, StringLength(20)]
    [Display(Name = "Contact Number")]
    public string GuestContactNumber { get; set; } = string.Empty;

    [StringLength(100), EmailAddress]
    [Display(Name = "Email")]
    public string? GuestEmail { get; set; }

    [Required, StringLength(60)]
    [Display(Name = "Nationality")]
    public string GuestNationality { get; set; } = "Filipino";

    public List<Microsoft.AspNetCore.Mvc.Rendering.SelectListItem> NationalityOptions { get; set; } = new();

    [Required, StringLength(60)]
    [Display(Name = "Government ID Type")]
    public string IdType { get; set; } = string.Empty;

    [Required, StringLength(100)]
    [Display(Name = "ID Number")]
    public string IdNumber { get; set; } = string.Empty;

    [Display(Name = "Senior Citizen")]
    public bool IsSeniorCitizen { get; set; }

    [Display(Name = "PWD")]
    public bool IsPwd { get; set; }

    [StringLength(50)]
    [Display(Name = "Senior/PWD ID Number")]
    public string? DiscountIdNumber { get; set; }

    // Payment collected at check-in — cash, GCash, or bank transfer only
    // (no credit cards accepted, per the front-desk interview).
    [MaxLength(100), Display(Name = "Payment Method")]
    public string? PaymentMethod { get; set; }

    // Typed in by front-desk staff when Payment Method is GCash — recording
    // only, for reconciliation later.
    [MaxLength(100), Display(Name = "Reference Number")]
    public string? PaymentReference { get; set; }

    [Display(Name = "Amount Tendered (₱)")]
    [Range(0, double.MaxValue)]
    public decimal? AmountTendered { get; set; }

    public decimal? ChangeAmount { get; set; }
}

public class GroupRoomAssignmentItem
{
    public int ReservationId { get; set; }
    public string ReferenceNumber { get; set; } = string.Empty;
    public string PreferredRoomTypeName { get; set; } = "Any";
    public int? PreferredRoomTypeId { get; set; }
    public int? AssignedRoomId { get; set; }
    public List<Microsoft.AspNetCore.Mvc.Rendering.SelectListItem> AvailableRooms { get; set; } = new();
}
