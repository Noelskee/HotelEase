using System.ComponentModel.DataAnnotations;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace HotelEase.ViewModels
{
    public enum WalkInStayType
    {
        Hourly,
        Nightly
    }

    // Drives the streamlined Walk-In Check-In form. A Guest + a WalkIn-type
    // Reservation is created with Status = Pending and PaymentStatus = Unpaid,
    // then the payment step immediately checks the guest in and sets the room
    // to Occupied. The UI shows one continuous front-desk workflow.
    public class WalkInViewModel : IValidatableObject
    {
        [Required]
        [Display(Name = "Stay Type")]
        public WalkInStayType StayType { get; set; } = WalkInStayType.Hourly;

        // Hourly durations: 3 or 12 hours only. Full-day stays use Overnight (Nightly).
        [Display(Name = "Duration (Hours)")]
        [Range(3, 12, ErrorMessage = "Duration must be 3 or 12 hours.")]
        public int DurationHours { get; set; } = 3;

        // Walk-ins always start now. Check-out is calculated from the selected
        // Stay Type: Hourly uses DurationHours; Nightly uses Check-out Date
        // (nights = Check-out Date − Check-in Date) at the standard checkout time.
        [Display(Name = "Check-in Date & Time")]
        [DataType(DataType.DateTime)]
        public DateTime? CheckInDateTime { get; set; }

        [Display(Name = "Check-out Date & Time")]
        [DataType(DataType.DateTime)]
        public DateTime? CheckOutDateTime { get; set; }

        // Calculated/internal: nights = Check-out Date − Check-in Date for Nightly.
        // Not a user-facing input for nightly stays.
        [Display(Name = "Number of Nights")]
        [Range(1, 30, ErrorMessage = "Number of nights must be between 1 and 30.")]
        public int NumberOfNights { get; set; } = 1;

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (StayType == WalkInStayType.Hourly && DurationHours is not (3 or 12))
                yield return new ValidationResult("Hourly duration must be 3 or 12 hours (use Overnight for full day).", new[] { nameof(DurationHours) });

            if (StayType == WalkInStayType.Nightly)
            {
                if (CheckInDateTime.HasValue && CheckOutDateTime.HasValue)
                {
                    var nights = (CheckOutDateTime.Value.Date - CheckInDateTime.Value.Date).Days;
                    if (nights < 1)
                        yield return new ValidationResult("Check-out date must be after check-in date for overnight stays.", new[] { nameof(CheckOutDateTime) });
                }
                else if (NumberOfNights < 1 || NumberOfNights > 30)
                {
                    yield return new ValidationResult("Number of nights must be between 1 and 30.", new[] { nameof(NumberOfNights) });
                }
            }
        }

        // Legacy single-room field. No longer required directly — it is
        // populated from the first entry of SelectedRooms right before
        // saving, so the rest of the pipeline (Guest/Reservation creation)
        // doesn't need to change for the common single-room case.
        [Display(Name = "Room")]
        public int RoomId { get; set; }

        public List<SelectListItem> AvailableRooms { get; set; } = new();

        // ── Multi-room booking (Step 3: Room List) ─────────────────────
        // Rooms the walk-in guest has "Booked" from the Available Rooms
        // step. Carried between wizard steps (and across a Step-1 search
        // reload) as JSON in a hidden field, since there is no server-side
        // session/cart — QloApps' "Book Now" flow without an actual
        // shopping cart. Parsed into SelectedRooms for rendering/posting.
        public string SelectedRoomsJson { get; set; } = "[]";

        public List<WalkInRoomSelection> SelectedRooms
        {
            get
            {
                if (string.IsNullOrWhiteSpace(SelectedRoomsJson)) return new();
                try
                {
                    return JsonSerializer.Deserialize<List<WalkInRoomSelection>>(
                        SelectedRoomsJson,
                        new JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? new();
                }
                catch (JsonException)
                {
                    return new();
                }
            }
        }

        public class WalkInRoomSelection
        {
            public int RoomId { get; set; }
            public string RoomNumber { get; set; } = string.Empty;
            public string RoomTypeName { get; set; } = string.Empty;

            public int MaxOccupancy { get; set; }
            // RatePerNight is the unit price. StayRate is always the complete
            // room charge for the selected stay (RatePerNight × nights for
            // Nightly, or the flat duration rate for Hourly).
            public decimal RatePerNight { get; set; }
            public decimal StayRate { get; set; }
            public string DurationLabel { get; set; } = string.Empty;

            // Per-room occupancy (posted via SelectedRoomsJson from the Rooms step).
            public int Adults { get; set; } = 1;
            public int Children { get; set; } = 0;
            public string? ChildrenAges { get; set; }

            // Stay type and duration, inherited from the Step 1 search
            // criteria — Step 1 is the single source of truth for these
            // values, and every room in a walk-in transaction shares them.
            public string StayType { get; set; } = "Hourly";
            public int DurationHours { get; set; } = 3;
            public int NumberOfNights { get; set; } = 1;

            // Server-derived walk-in window copied into the created Reservation.
            // Actual check-in is always DateTime.Now; the browser cannot choose
            // a different check-in date/time for a direct walk-in.
            public DateTime? CheckInDateTime { get; set; }
            public DateTime? CheckOutDateTime { get; set; }
        }

        // Search-step filters (not persisted — only narrow which rooms show
        // up in the Available Rooms step of the wizard).
        [Display(Name = "Room Type")]
        public int? RoomTypeId { get; set; }

        public List<SelectListItem> RoomTypeOptions { get; set; } = new();

        public List<SelectListItem> NationalityOptions { get; set; } = new();

        // Cards rendered in the Available Rooms section.
        public List<AvailableRoomCard> AvailableRoomCards { get; set; } = new();

        public class AvailableRoomCard
        {
            public int Id { get; set; }
            public string RoomNumber { get; set; } = string.Empty;
            public int RoomTypeId { get; set; }
            public string RoomTypeName { get; set; } = string.Empty;
            public string Description { get; set; } = string.Empty;
            public decimal StayRate { get; set; }
            public decimal Rate3Hours { get; set; }
            public decimal Rate12Hours { get; set; }
            public decimal Rate24Hours { get; set; }
            // Per-night rate from Room Type Management. The UI multiplies this
            // by NumberOfNights for the selected stay total.
            public decimal RateNightly { get; set; }
            public string DurationLabel { get; set; } = string.Empty;
            public int MaxOccupancy { get; set; }
            public string Amenities { get; set; } = string.Empty;
            public string Status { get; set; } = "Available";
            public bool IsSelectable { get; set; } = true;
        }

        [Required, StringLength(100)]
        [Display(Name = "Full Name")]
        public string GuestFullName { get; set; } = string.Empty;

        [Required, StringLength(20)]
        [Display(Name = "Contact Number")]
        public string GuestContactNumber { get; set; } = string.Empty;

        [StringLength(100)]
        [EmailAddress]
        [Display(Name = "Email")]
        public string? GuestEmail { get; set; }

        [Required, StringLength(60)]
        [Display(Name = "Nationality")]
        public string GuestNationality { get; set; } = "Filipino";

        // Required for Walk-In because guest is checking in immediately.
        [Required, StringLength(60)]
        [Display(Name = "Government ID Type")]
        public string IdType { get; set; } = string.Empty;

        [Required, StringLength(100)]
        [Display(Name = "ID Number")]
        public string IdNumber { get; set; } = string.Empty;

        // Discount eligibility (Philippine law: RA 9994 / RA 10754). Applied
        // at check-in time on the Billing Preview. A single checkbox in the
        // UI drives IsSeniorCitizen; IsPwd is kept for Guest-record parity
        // with other screens but is not rendered here (see WalkIn.cshtml).
        [Range(1, 20)]
        [Display(Name = "Adults")]
        public int Adults { get; set; } = 1;

        [Range(0, 20)]
        [Display(Name = "Children")]
        public int Children { get; set; } = 0;

        /// <summary>Comma-separated ages when Children &gt; 0 (e.g. "7,9").</summary>
        [Display(Name = "Children's Ages")]
        [MaxLength(50)]
        public string? ChildrenAges { get; set; }

        [Display(Name = "Senior Citizen / PWD Discount")]
        public bool IsSeniorCitizen { get; set; } = false;

        public bool IsPwd { get; set; } = false;

        // Extra persons / beds (same rates as booking check-in: ₱300 / ₱400)
        [Display(Name = "Extra Persons")]
        [Range(0, 20)]
        public int ExtraPersons { get; set; }

        [Display(Name = "Extra Beds")]
        [Range(0, 10)]
        public int ExtraBeds { get; set; }

        // Payment fields captured on the same page so the front-desk can
        // collect payment and check the guest in with one click.
        [Display(Name = "Payment Method")]
        public string? PaymentMethod { get; set; }

        [Display(Name = "Amount Tendered")]
        [Range(0, 1000000, ErrorMessage = "Amount tendered must be non-negative.")]
        public decimal? AmountTendered { get; set; }

        [Display(Name = "Payment Reference")]
        public string? PaymentReference { get; set; }

    }
}
