using HotelEase.Models;

namespace HotelEase.ViewModels;

public class DashboardViewModel
{
    // Room counts
    public int TotalRooms { get; set; }
    public int AvailableRooms { get; set; }
    public int OccupiedRooms { get; set; }
    /// <summary>Sum of GuestCount for CheckedIn reservations (not room count).</summary>
    public int InHouseGuestCount { get; set; }
    public int ReservedRooms { get; set; }
    public int ForCleaningRooms { get; set; }

    // Today's stats
    public int TodayArrivals { get; set; }
    public int TodayDepartures { get; set; }
    public int PendingReservations { get; set; }

    // Revenue today
    public decimal TodayRevenue { get; set; }

    // Recent reservations
    public List<Reservation> RecentReservations { get; set; } = new();

    // Rooms needing attention
    public List<Room> RoomsForCleaning { get; set; } = new();

    // ---- Dashboard redesign additions ----

    // Occupancy rate, as a whole-number percentage (0-100)
    public double OccupancyRate => TotalRooms > 0 ? Math.Round(OccupiedRooms * 100.0 / TotalRooms, 0) : 0;

    // Per-status percentages of total rooms, pre-computed so the view never
    // needs to divide/round itself.
    public double AvailablePct => TotalRooms > 0 ? Math.Round(AvailableRooms * 100.0 / TotalRooms, 0) : 0;
    public double OccupiedPct => TotalRooms > 0 ? Math.Round(OccupiedRooms * 100.0 / TotalRooms, 0) : 0;
    public double ReservedPct => TotalRooms > 0 ? Math.Round(ReservedRooms * 100.0 / TotalRooms, 0) : 0;
    public double ForCleaningPct => TotalRooms > 0 ? Math.Round(ForCleaningRooms * 100.0 / TotalRooms, 0) : 0;

    // Today's arrivals / departures, listed out (not just counted)
    public List<Reservation> TodayArrivalsList { get; set; } = new();
    public List<Reservation> TodayDeparturesList { get; set; } = new();
    public List<Reservation> InHouseGuests { get; set; } = new();
    // All pre-arrival bookings (Pending / Confirmed / Reserved) — not limited to today
    public List<Reservation> AdvanceReservations { get; set; } = new();

    // 7-day trend, computed from real reservation/transaction history —
    // occupancy is derived from rooms actually checked-in that overlap each
    // day, revenue is summed from transactions closed on that day.
    public List<DashboardTrendPoint> WeeklyTrend { get; set; } = new();

    // Pre-serialized JSON for the Chart.js widget, built in the controller
    // (System.Text.Json) so the view only ever does @Html.Raw on a value
    // that is already known-safe JSON — no string.Join/ternary chains in
    // the .cshtml itself.
    public string WeeklyTrendLabelsJson { get; set; } = "[]";
    public string WeeklyTrendOccupancyJson { get; set; } = "[]";
    public string WeeklyTrendRevenueJson { get; set; } = "[]";
    public string TrendRangeLabel { get; set; } = "";

    // Pre-computed sub-counts for the stat card captions (keeps the view
    // free of inline LINQ/lambdas).
    public int TodayArrivalsAlreadyCheckedIn { get; set; }
    public int TodayDeparturesAlreadyCheckedOut { get; set; }
}

public class DashboardTrendPoint
{
    public DateTime Date { get; set; }
    public double OccupancyRate { get; set; }
    public decimal Revenue { get; set; }
}
