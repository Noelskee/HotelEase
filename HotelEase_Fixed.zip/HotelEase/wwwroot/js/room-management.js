// Room Management page — all client-side logic for the Rooms and Room Types
// tabs (edit/delete Room modals, create/edit/delete Room Type modals, the
// amenity tag-pill input, and the Add Room No. pill input).
//
// This file expects three server-rendered globals to already be declared by
// an inline <script> block in Views/Room/Index.cshtml, loaded BEFORE this file:
//   - allRoomsData          : [{ id, roomNumber, floor }, ...] for every room
//   - roomOwnership         : { "101": roomTypeId, ... } room number -> owning type
//   - existingRoomTypeNames : ["single", "double", ...] lowercase, for validation
//   - existingRoomTypeIds   : [1, 2, ...] parallel to existingRoomTypeNames

// ══════════════════════════ ROOM (Rooms tab) ══════════════════════════

// Floor and Room Number are no longer user-editable in the Edit Room modal —
// they're carried through as hidden fields (set once in openEditModal) so the
// existing values round-trip on save without exposing an editable control.

function submitRoomEdit(event) {
    return true;
}

function toggleEditRtDropdown() {
    document.getElementById('editRtDropdownList').classList.toggle('d-none');
}

function selectEditRoomType(el) {
    const name      = el.dataset.name;
    const amenities = el.dataset.amenities;

    document.getElementById('editRoomTypeId').value = el.dataset.id;
    document.getElementById('editRtTriggerText').innerHTML =
        `<span class="fw-medium text-dark">${name}</span>`;
    document.getElementById('editRtDropdownList').classList.add('d-none');

    renderAmenityPreview(amenities);
}

document.addEventListener('click', function (e) {
    const wrap = document.getElementById('editRtDropdownWrap');
    if (wrap && !wrap.contains(e.target))
        document.getElementById('editRtDropdownList').classList.add('d-none');
});

function renderAmenityPreview(amenities) {
    const wrap = document.getElementById('editAmenWrap');
    const div  = document.getElementById('editAmenDisplay');
    if (amenities && amenities.trim()) {
        div.innerHTML = amenities.split(',').map(a =>
            `<span class="badge me-1 mb-1" style="background:var(--primary);color:#fff;font-weight:400;font-size:.72rem">${a.trim()}</span>`
        ).join('');
        wrap.style.display = '';
    } else {
        div.innerHTML = '<span class="text-muted small">No amenities defined for this room type.</span>';
        wrap.style.display = '';
    }
}

function getEditModal() { return bootstrap.Modal.getOrCreateInstance(document.getElementById('editModal')); }
function getRoomDeleteModal() { return bootstrap.Modal.getOrCreateInstance(document.getElementById('roomDeleteModal')); }

function openRoomDeleteModal(id, roomNumber) {
    document.getElementById('roomDeleteId').value   = id;
    document.getElementById('roomDeleteName').textContent = roomNumber;
    getRoomDeleteModal().show();
}

async function openEditModal(id) {
    const res = await fetch(`/Room/GetRoom?id=${id}`);
    if (!res.ok) return;
    const d = await res.json();

    document.getElementById('editId').value          = d.id;
    document.getElementById('editRoomTypeId').value  = d.roomTypeId;
    document.getElementById('editFloor').value       = d.floor ?? '';
    document.getElementById('editRoomNumber').value  = d.roomNumber;
    document.getElementById('editStatus').value      = d.status;
    document.getElementById('editDescription').value = d.description ?? '';
    document.getElementById('modalRoomTitle').textContent = d.roomNumber;

    document.getElementById('editRtTriggerText').innerHTML =
        `<span class="fw-medium text-dark">${d.roomTypeName ?? ''}</span>`;

    renderAmenityPreview(d.amenities ?? '');
    getEditModal().show();
}

// ══════════════════════════ ROOM TYPE (Room Types tab) ══════════════════════════

function getRtCreateModal() { return bootstrap.Modal.getOrCreateInstance(document.getElementById('rtCreateModal')); }
function getRtEditModal() { return bootstrap.Modal.getOrCreateInstance(document.getElementById('rtEditModal')); }
function getRtDeleteModal() { return bootstrap.Modal.getOrCreateInstance(document.getElementById('rtDeleteModal')); }

// Only letters, spaces, & ' and - are accepted — keeps the field to actual amenity names.
const AMENITY_PATTERN = /^[A-Za-z&'\-\s]{2,40}$/;

const tags = { rtCreate: [], rtEdit: [] };

function renderTags(scope) {
    const wrap  = document.getElementById(scope + 'TagWrap');
    const input = document.getElementById(scope + 'TagInput');
    wrap.querySelectorAll('.amenity-tag').forEach(t => t.remove());
    tags[scope].forEach((tag, i) => {
        const pill = document.createElement('span');
        pill.className = 'amenity-tag';
        pill.innerHTML = `${tag}<button type="button" class="remove-tag" onclick="removeTag('${scope}',${i})" title="Remove">&times;</button>`;
        wrap.insertBefore(pill, input);
    });
    syncPresetButtons(scope);
}

function removeTag(scope, idx) {
    tags[scope].splice(idx, 1);
    renderTags(scope);
}

function showAmenError(scope, msg) {
    const el = document.getElementById(scope + 'AmenError');
    if (!el) return;
    el.textContent = msg;
    el.style.color = '#dc3545';
    if (msg) setTimeout(() => { if (el.textContent === msg) el.textContent = ''; }, 2500);
}

function addTag(scope, value) {
    const val = value.trim().replace(/,+$/, '').trim();
    if (!val) return;
    if (!AMENITY_PATTERN.test(val)) {
        showAmenError(scope, `"${val}" doesn't look like a valid amenity — use letters only (e.g. "Rain Shower").`);
        return;
    }
    if (!tags[scope].map(t => t.toLowerCase()).includes(val.toLowerCase())) {
        tags[scope].push(val);
        renderTags(scope);
    }
}

function handleTagKey(e, scope) {
    if (e.key === 'Enter' || e.key === ',') {
        e.preventDefault();
        addTag(scope, e.target.value);
        e.target.value = '';
    } else if (e.key === 'Backspace' && e.target.value === '' && tags[scope].length) {
        tags[scope].pop();
        renderTags(scope);
    }
}

function syncPresetButtons(scope) {
    const modalId = scope === 'rtCreate' ? 'rtCreateModal' : 'rtEditModal';
    document.querySelectorAll(`#${modalId} .preset-btn`).forEach(btn => {
        const isActive = tags[scope].map(t => t.toLowerCase()).includes(btn.textContent.trim().toLowerCase());
        btn.classList.toggle('active', isActive);
    });
}

function togglePreset(btn, scope) {
    const label = btn.textContent.trim();
    const idx   = tags[scope].map(t => t.toLowerCase()).indexOf(label.toLowerCase());
    if (idx === -1) { tags[scope].push(label); }
    else            { tags[scope].splice(idx, 1); }
    renderTags(scope);
}

const roomLists = { rtCreate: [], rtEdit: [] };

function renderRoomList(scope) {
    const box = document.getElementById(scope + 'RoomList');
    box.innerHTML = '';
    if (!roomLists[scope].length) {
        box.innerHTML = '<div class="text-muted small px-1 py-1">No rooms added yet.</div>';
    } else {
        roomLists[scope].forEach(num => {
            const pill = document.createElement('span');
            pill.className = 'room-num-tag';
            pill.innerHTML = `${num}<button type="button" class="remove-room" onclick="removeRoomNumber('${scope}','${num}')" title="Remove">&times;</button>`;
            box.appendChild(pill);
        });
    }
    document.getElementById(scope + 'RoomIdsHidden').value = roomLists[scope].join(',');
}

function addRoomNumber(scope) {
    const input = document.getElementById(scope + 'RoomInput');
    const err   = document.getElementById(scope + 'RoomError');
    const raw   = input.value.trim();
    err.textContent = '';
    if (!raw) return;
    if (!/^[0-9]{1,6}$/.test(raw)) {
        err.textContent = 'Room number must be digits only (e.g. 101).';
        return;
    }
    if (roomLists[scope].includes(raw)) {
        err.textContent = `Room ${raw} is already in the list.`;
        input.value = '';
        return;
    }
    const editingId = scope === 'rtEdit' ? Number(document.getElementById('rtEditId').value) : null;
    if (roomOwnership[raw] !== undefined && roomOwnership[raw] !== editingId) {
        err.textContent = `Room ${raw} already belongs to another room type.`;
        return;
    }
    roomLists[scope].push(raw);
    renderRoomList(scope);
    input.value = '';
    input.focus();
}

function removeRoomNumber(scope, num) {
    roomLists[scope] = roomLists[scope].filter(n => n !== num);
    renderRoomList(scope);
}

function syncAmenities(scope) {
    const input = document.getElementById(scope + 'TagInput');
    if (input.value.trim()) { addTag(scope, input.value); input.value = ''; }
    document.getElementById(scope + 'AmenitiesHidden').value = tags[scope].join(', ');
}

// Flags keyboard-mashed names like "hsrtshrthrt" or "gdgsehshergerg" while still
// allowing real room-type words (Single, Deluxe, Presidential Suite, etc.).
// A name is treated as gibberish if any word (3+ letters) has no vowel at all,
// or has a run of 4+ consecutive consonants — real English words almost never do.
function isGibberishName(name) {
    const words = name.trim().split(/\s+/);
    for (const w of words) {
        if (w.length < 3) continue;
        if (!/[aeiou]/i.test(w)) return true;
        if (/[^aeiou\s'-]{4,}/i.test(w)) return true;
    }
    return false;
}

function submitRtCreate(event) {
    const rawName = document.getElementById('rtCreateName').value.trim();
    const name = rawName.toLowerCase();
    if (isGibberishName(rawName)) {
        event.preventDefault();
        document.getElementById('rtCreateNameError').textContent = 'That doesn\'t look like a real room type name.';
        return false;
    }
    if (existingRoomTypeNames.includes(name)) {
        event.preventDefault();
        document.getElementById('rtCreateNameError').textContent = 'A room type with this name already exists.';
        return false;
    }
    syncAmenities('rtCreate');
    return true;
}

function submitRtEdit(event) {
    const editingId = document.getElementById('rtEditId').value;
    const rawName = document.getElementById('rtEditName').value.trim();
    const name = rawName.toLowerCase();
    if (isGibberishName(rawName)) {
        event.preventDefault();
        document.getElementById('rtEditNameError').textContent = 'That doesn\'t look like a real room type name.';
        return false;
    }
    const isDuplicate = existingRoomTypeNames.some((n, i) => n === name && String(existingRoomTypeIds[i]) !== editingId);
    if (isDuplicate) {
        event.preventDefault();
        document.getElementById('rtEditNameError').textContent = 'A room type with this name already exists.';
        return false;
    }
    syncAmenities('rtEdit');
    return true;
}

function openRtCreateModal() {
    tags['rtCreate'] = [];
    renderTags('rtCreate');
    document.getElementById('rtCreateTagInput').value = '';
    document.getElementById('rtCreateNameError').textContent = '';
    roomLists['rtCreate'] = [];
    renderRoomList('rtCreate');
    document.getElementById('rtCreateRoomInput').value = '';
    document.getElementById('rtCreateRoomError').textContent = '';
    getRtCreateModal().show();
}

async function openRtEditModal(id) {
    const res = await fetch(`/RoomType/GetDetails?id=${id}`);
    if (!res.ok) return;
    const d = await res.json();

    document.getElementById('rtEditId').value           = d.id;
    document.getElementById('rtEditIdDisplay').value    = d.id;
    document.getElementById('rtEditName').value          = d.name;
    document.getElementById('rtEditRate3Hours').value    = d.rate3Hours ?? 0;
    document.getElementById('rtEditRate12Hours').value   = d.rate12Hours ?? 0;
    document.getElementById('rtEditBaseRate').value       = d.baseRate;
    document.getElementById('rtEditMaxOccupancy').value  = d.maxOccupancy;
    document.getElementById('rtEditExtraHourRate3Hours').value = d.extraHourRate3Hours ?? 0;
    document.getElementById('rtEditExtraHourRate').value = d.extraHourRate ?? 0;
    document.getElementById('rtEditDescription').value   = d.description ?? '';
    document.getElementById('rtEditTagInput').value      = '';

    tags['rtEdit'] = d.amenities
        ? d.amenities.split(',').map(a => a.trim()).filter(a => a)
        : [];
    renderTags('rtEdit');

    const assignedNumbers = (d.roomNumbers || []).map(String);
    roomLists['rtEdit'] = assignedNumbers.slice();
    renderRoomList('rtEdit');
    document.getElementById('rtEditRoomInput').value = '';
    document.getElementById('rtEditRoomError').textContent = '';

    getRtEditModal().show();
}

function openRtDeleteModal(id, name, roomCount) {
    document.getElementById('rtDeleteId').value          = id;
    document.getElementById('rtDeleteName').textContent  = name;
    const warn = document.getElementById('rtDeleteWarn');
    const btn  = document.getElementById('rtDeleteBtn');
    if (roomCount > 0) {
        warn.textContent = `This type has ${roomCount} room(s) assigned and cannot be deleted.`;
        warn.style.color = '#dc3545';
        btn.disabled = true;
    } else {
        warn.textContent = 'This action cannot be undone.';
        warn.style.color = '';
        btn.disabled = false;
    }
    getRtDeleteModal().show();
}

// ══════════════════════════ ROOM TYPE IMAGES ══════════════════════════

function getRtImagesModal() { return bootstrap.Modal.getOrCreateInstance(document.getElementById('rtImagesModal')); }
let currentImageRoomTypeId = null;
let rtImagesToken = document.querySelector('input[name="__RequestVerificationToken"]')?.value ?? '';

function openRtImagesModal(id, name) {
    rtImagesToken = document.querySelector('input[name="__RequestVerificationToken"]')?.value ?? rtImagesToken;
    currentImageRoomTypeId = id;
    document.getElementById('rtImagesTypeName').textContent = name;
    document.getElementById('rtImagesGrid').innerHTML = '<div class="col-12 text-center text-muted py-4"><i class="fas fa-spinner fa-spin me-2"></i>Loading…</div>';
    document.getElementById('rtImagesStatus').textContent = '';
    getRtImagesModal().show();
    loadRoomTypeImages(id);
}

async function loadRoomTypeImages(roomTypeId) {
    try {
        const res = await fetch(`/RoomTypeImage/List?roomTypeId=${roomTypeId}`);
        if (!res.ok) throw new Error('Could not load images');
        const images = await res.json();
        renderRoomTypeImages(images);
    } catch (err) {
        document.getElementById('rtImagesGrid').innerHTML = `<div class="col-12 text-center text-danger py-4">${err.message}</div>`;
    }
}

function renderRoomTypeImages(images) {
    const grid = document.getElementById('rtImagesGrid');
    grid.innerHTML = '';
    if (!images.length) {
        grid.innerHTML = '<div class="col-12 text-muted text-center py-4">No images uploaded yet.</div>';
        return;
    }
    images.forEach(img => {
        const col = document.createElement('div');
        col.className = 'col-sm-6 col-md-4';
        col.innerHTML = `
            <div class="rt-img-card ${img.isPrimary ? 'primary' : ''}" data-id="${img.id}">
                <div class="rt-img-overlay">
                    ${!img.isPrimary ? `<button type="button" class="btn btn-sm btn-link p-0" title="Set as primary" onclick="setPrimaryImage(${img.id})"><i class="fas fa-star"></i></button>` : ''}
                    <button type="button" class="btn btn-sm btn-link p-0" title="Delete" onclick="deleteImage(${img.id})"><i class="fas fa-trash"></i></button>
                </div>
                <img src="${img.imageUrl}" alt="${img.fileName ?? 'Room image'}" />
                <input type="text" class="form-control" value="${img.caption ?? ''}" placeholder="Caption (optional)" onchange="updateCaption(${img.id}, this.value)" />
                ${img.isPrimary ? '<span class="badge-primary"><i class="fas fa-star me-1"></i>Primary</span>' : ''}
            </div>
        `;
        grid.appendChild(col);
    });
}

function peso(n) { return '₱' + Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }

async function setPrimaryImage(id) {
    const form = new FormData();
    form.append('id', id);
    const res = await fetch('/RoomTypeImage/SetPrimary', {
        method: 'POST',
        body: form,
        headers: { 'RequestVerificationToken': rtImagesToken }
    });
    if (res.ok) loadRoomTypeImages(currentImageRoomTypeId);
}

async function updateCaption(id, caption) {
    const form = new FormData();
    form.append('id', id);
    form.append('caption', caption);
    await fetch('/RoomTypeImage/UpdateCaption', {
        method: 'POST',
        body: form,
        headers: { 'RequestVerificationToken': rtImagesToken }
    });
}

async function deleteImage(id) {
    if (!confirm('Delete this image?')) return;
    const form = new FormData();
    form.append('id', id);
    const res = await fetch('/RoomTypeImage/Delete', {
        method: 'POST',
        body: form,
        headers: { 'RequestVerificationToken': rtImagesToken }
    });
    if (res.ok) loadRoomTypeImages(currentImageRoomTypeId);
}

(function () {
    const dropzone = document.getElementById('rtImagesDropzone');
    const fileInput = document.getElementById('rtImagesFileInput');
    const statusEl = document.getElementById('rtImagesStatus');
    if (!dropzone || !fileInput) return;

    dropzone.addEventListener('click', () => fileInput.click());
    dropzone.addEventListener('dragover', e => { e.preventDefault(); dropzone.classList.add('dragover'); });
    dropzone.addEventListener('dragleave', () => dropzone.classList.remove('dragover'));
    dropzone.addEventListener('drop', e => {
        e.preventDefault();
        dropzone.classList.remove('dragover');
        if (currentImageRoomTypeId) uploadImages(e.dataTransfer.files);
    });
    fileInput.addEventListener('change', () => {
        if (currentImageRoomTypeId) uploadImages(fileInput.files);
    });

    async function uploadImages(files) {
        statusEl.textContent = 'Uploading…';
        const form = new FormData();
        form.append('roomTypeId', currentImageRoomTypeId);
        for (const f of files) form.append('files', f);
        const res = await fetch('/RoomTypeImage/Upload', {
            method: 'POST',
            body: form,
            headers: { 'RequestVerificationToken': rtImagesToken }
        });
        statusEl.textContent = '';
        if (res.ok) {
            loadRoomTypeImages(currentImageRoomTypeId);
        } else {
            statusEl.textContent = 'Upload failed. Please try again.';
            statusEl.className = 'small mb-3 text-danger';
        }
    }
})();
