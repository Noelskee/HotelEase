/* guest-management.js — drives all guest modals */
'use strict';

// ── Edit Guest modal ─────────────────────────────────────────────────────────
document.addEventListener('click', function (e) {
    const btn = e.target.closest('[data-action="editGuest"]');
    if (!btn) return;

    document.getElementById('editGuestId').value          = btn.dataset.id;
    document.getElementById('editGuestFullName').value    = btn.dataset.fullname;
    document.getElementById('editGuestContact').value     = btn.dataset.contact;
    document.getElementById('editGuestNationality').value = btn.dataset.nationality;
    document.getElementById('editGuestCount').value       = btn.dataset.count;

    const modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('editGuestModal'));
    modal.show();
});

// ── Archive Guest modal ──────────────────────────────────────────────────────
document.addEventListener('click', function (e) {
    const btn = e.target.closest('[data-action="archiveGuest"]');
    if (!btn) return;

    document.getElementById('archiveGuestId').value  = btn.dataset.id;
    document.getElementById('archiveGuestName').textContent = btn.dataset.fullname;

    const modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('archiveGuestModal'));
    modal.show();
});
