// Auto-dismiss alerts after 5 s
document.addEventListener('DOMContentLoaded', function () {
    setTimeout(() => {
        document.querySelectorAll('.alert.alert-success, .alert.alert-info').forEach(el => {
            const bsAlert = new bootstrap.Alert(el);
            bsAlert.close();
        });
    }, 5000);
});

// Room rate calculator for reservation form
function calculateBilling() {
    const roomSelect = document.getElementById('RoomId');
    const checkIn    = document.getElementById('CheckInDate');
    const checkOut   = document.getElementById('CheckOutDate');
    if (!roomSelect || !checkIn || !checkOut) return;

    const rate = parseFloat(roomSelect.options[roomSelect.selectedIndex]?.dataset?.rate || 0);
    const from = new Date(checkIn.value);
    const to   = new Date(checkOut.value);
    const nights = Math.max(0, Math.ceil((to - from) / (1000 * 60 * 60 * 24)));
    const isSenior = document.getElementById('IsSeniorCitizen')?.checked;
    const isPwd    = document.getElementById('IsPwd')?.checked;

    const total    = rate * nights;
    const discount = (isSenior || isPwd) ? total * 0.20 : 0;
    const amountDue = total - discount;

    const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
    set('calcNights', nights);
    set('calcRate', '₱' + rate.toLocaleString('en-PH', {minimumFractionDigits:2}));
    set('calcTotal', '₱' + total.toLocaleString('en-PH', {minimumFractionDigits:2}));
    set('calcDiscount', '₱' + discount.toLocaleString('en-PH', {minimumFractionDigits:2}));
    set('calcAmountDue', '₱' + amountDue.toLocaleString('en-PH', {minimumFractionDigits:2}));
}

document.addEventListener('DOMContentLoaded', () => {
    ['RoomId','CheckInDate','CheckOutDate','IsSeniorCitizen','IsPwd'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('change', calculateBilling);
    });
    calculateBilling();
});

// Change calculation for billing
function calcChange() {
    const total = parseFloat(document.getElementById('billingTotal')?.dataset?.total || 0);
    const paid  = parseFloat(document.getElementById('AmountPaid')?.value || 0);
    const change = Math.max(0, paid - total);
    const el = document.getElementById('changeDisplay');
    if (el) el.textContent = '₱' + change.toLocaleString('en-PH', {minimumFractionDigits:2});
}
document.addEventListener('DOMContentLoaded', () => {
    const paid = document.getElementById('AmountPaid');
    if (paid) paid.addEventListener('input', calcChange);
});
