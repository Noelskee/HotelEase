using HotelEase.Data;
using HotelEase.Filters;
using HotelEase.Services;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Database
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// RequireLoginFilter runs on every action by default; controllers/actions
// carrying [AllowAnonymous] (Account login, Home, OnlineReservation public booking)
// are exempt. All staff modules additionally use [RequireRole(...)] for RBAC.
// Guest, Room, and RoomType are no longer anonymous.
//
// CamelCase JSON so JS can read d.baseRate, d.roomTypeName, etc.
var mvcBuilder = builder.Services.AddControllersWithViews(options =>
    {
        options.Filters.Add<RequireLoginFilter>();
    })
    .AddJsonOptions(o =>
        o.JsonSerializerOptions.PropertyNamingPolicy =
            System.Text.Json.JsonNamingPolicy.CamelCase);

// In Development, recompile Razor views (.cshtml) on the fly so edits show up
// with just a browser refresh — no need to stop/rebuild/restart the app.
if (builder.Environment.IsDevelopment())
{
    mvcBuilder.AddRazorRuntimeCompilation();
}

builder.Services.AddScoped<IBillingService, BillingService>();
builder.Services.AddScoped<IReservationService, ReservationService>();
builder.Services.AddScoped<IRoomService, RoomService>();
builder.Services.AddScoped<IEmailService, EmailService>();
builder.Services.AddScoped<IAuditService, AuditService>();

// Required: registers the in-memory distributed cache that Session uses as
// its backing store. Without this, session values written during login are
// silently lost on the next request — UserId is always null.
builder.Services.AddDistributedMemoryCache();

builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(
        builder.Configuration.GetValue<int>("AppSettings:SessionTimeoutMinutes", 60));
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
    options.Cookie.SameSite = SameSiteMode.Lax;
    options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
});

builder.Services.AddHttpContextAccessor();

// Allow AJAX posts (room type images, etc.) to send the antiforgery token in a header.
builder.Services.AddAntiforgery(options =>
{
    options.HeaderName = "RequestVerificationToken";
});

var app = builder.Build();

// Auto-migrate / create schema, then seed staff accounts.
// Handles the common local case where LocalDB exists but tables were never
// created (SqlException: Invalid object name 'Users').
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    var logger = scope.ServiceProvider.GetRequiredService<ILoggerFactory>().CreateLogger("Startup");

    void EnsureSchema()
    {
        try
        {
            db.Database.Migrate();
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Migrate() failed.");
        }

        // Detect missing Users table (or empty broken schema).
        var usersTableExists = false;
        try
        {
            usersTableExists = db.Database.ExecuteSqlRaw(
                "SELECT CASE WHEN OBJECT_ID(N'[dbo].[Users]', N'U') IS NULL THEN 0 ELSE 1 END") >= 0
                && db.Users != null;
            // ExecuteSqlRaw returns rows affected (-1 for SELECT). Probe with ADO instead:
            usersTableExists = false;
            var conn = db.Database.GetDbConnection();
            if (conn.State != System.Data.ConnectionState.Open) conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT CASE WHEN OBJECT_ID(N'[dbo].[Users]', N'U') IS NULL THEN 0 ELSE 1 END";
            var result = cmd.ExecuteScalar();
            usersTableExists = Convert.ToInt32(result) == 1;
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Could not probe Users table.");
            usersTableExists = false;
        }

        if (!usersTableExists)
        {
            logger.LogWarning("Users table missing — applying EnsureCreated() to build schema from the model.");
            // EnsureCreated is a no-op if *any* table already exists; if the DB is
            // empty it creates the full model. If history is wrong, clear it first.
            try
            {
                db.Database.ExecuteSqlRaw("IF OBJECT_ID(N'[dbo].[__EFMigrationsHistory]', N'U') IS NOT NULL DELETE FROM [__EFMigrationsHistory];");
            }
            catch { /* ignore */ }

            try
            {
                db.Database.Migrate();
            }
            catch (Exception ex2)
            {
                logger.LogWarning(ex2, "Second Migrate() failed; EnsureCreated fallback.");
                db.Database.EnsureCreated();
            }

            // Re-probe
            try
            {
                var conn = db.Database.GetDbConnection();
                if (conn.State != System.Data.ConnectionState.Open) conn.Open();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT CASE WHEN OBJECT_ID(N'[dbo].[Users]', N'U') IS NULL THEN 0 ELSE 1 END";
                if (Convert.ToInt32(cmd.ExecuteScalar()) != 1)
                    db.Database.EnsureCreated();
            }
            catch
            {
                db.Database.EnsureCreated();
            }
        }

        // Notifications table (online reservation bell) — create if missing.
        try
        {
            db.Database.ExecuteSqlRaw(@"
IF OBJECT_ID(N'[dbo].[Notifications]', N'U') IS NULL
BEGIN
    CREATE TABLE [Notifications] (
        [Id] int NOT NULL IDENTITY,
        [Type] nvarchar(40) NOT NULL,
        [Message] nvarchar(300) NOT NULL,
        [Link] nvarchar(200) NULL,
        [ReservationId] int NULL,
        [IsRead] bit NOT NULL,
        [CreatedAt] datetime2 NOT NULL,
        CONSTRAINT [PK_Notifications] PRIMARY KEY ([Id])
    );
END
");
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Could not ensure Notifications table.");
        }
    }

    EnsureSchema();
    try
    {
        // Fully-qualified so CS0103 cannot occur even if using directives differ
        // across environments / partial restores from zip.
        HotelEase.Data.DbSeeder.Seed(db);
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "DbSeeder.Seed failed.");
        throw;
    }

    // Ensure AuditLogs table exists (new feature; safe if already present)
    try
    {
        db.Database.ExecuteSqlRaw(@"
IF OBJECT_ID(N'[dbo].[AuditLogs]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[AuditLogs] (
        [Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        [Action] NVARCHAR(100) NOT NULL,
        [EntityType] NVARCHAR(100) NOT NULL,
        [EntityId] INT NULL,
        [Details] NVARCHAR(500) NULL,
        [UserId] INT NULL,
        [UserName] NVARCHAR(100) NULL,
        [CreatedAt] DATETIME2 NOT NULL
    );
END");
    }
    catch (Exception ex)
    {
        logger.LogWarning(ex, "Could not ensure AuditLogs table.");
    }

    // Adults / Children on Reservations (guest breakdown)
    try
    {
        db.Database.ExecuteSqlRaw(@"
IF COL_LENGTH('Reservations', 'Adults') IS NULL
    ALTER TABLE [dbo].[Reservations] ADD [Adults] INT NOT NULL CONSTRAINT DF_Reservations_Adults DEFAULT 1;
IF COL_LENGTH('Reservations', 'Children') IS NULL
    ALTER TABLE [dbo].[Reservations] ADD [Children] INT NOT NULL CONSTRAINT DF_Reservations_Children DEFAULT 0;
");
    }
    catch (Exception ex)
    {
        logger.LogWarning(ex, "Could not ensure Adults/Children columns on Reservations.");
    }

    // MustChangePassword on Users — force staff to change temp password on first login
    try
    {
        db.Database.ExecuteSqlRaw(@"
IF COL_LENGTH('Users', 'MustChangePassword') IS NULL
    ALTER TABLE [dbo].[Users] ADD [MustChangePassword] BIT NOT NULL CONSTRAINT DF_Users_MustChangePassword DEFAULT 0;
");
    }
    catch (Exception ex)
    {
        logger.LogWarning(ex, "Could not ensure MustChangePassword column on Users.");
    }
} // end using (scope)

// Ensure the room type image upload folder exists.
// WebRootPath can be null in some host setups (e.g. missing wwwroot at startup);
// fall back to ContentRootPath/wwwroot so Path.Combine never gets a null segment.
var webRoot = app.Environment.WebRootPath
    ?? Path.Combine(app.Environment.ContentRootPath ?? Directory.GetCurrentDirectory(), "wwwroot");
var uploadsPath = Path.Combine(webRoot, "uploads", "roomtypes");
if (!Directory.Exists(uploadsPath))
    Directory.CreateDirectory(uploadsPath);

// Private payment-proof storage (outside wwwroot — not directly web-accessible).
var contentRoot = app.Environment.ContentRootPath ?? Directory.GetCurrentDirectory();
var paymentProofsPath = Path.Combine(contentRoot, "App_Data", "payment-proofs");
if (!Directory.Exists(paymentProofsPath))
    Directory.CreateDirectory(paymentProofsPath);

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseSession();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
